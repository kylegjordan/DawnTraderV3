/**
 * ══════════════════════════════════════════════════════════════════════════════
 * 🔒 LOCKED MODULE — Directive 8.8.4-L8
 * ══════════════════════════════════════════════════════════════════════════════
 * VTS API Routes - Virtual Trade Simulator Endpoints
 * 
 * Endpoints:
 * - GET /api/vts/status: Current VTS status and stats (L8: per-strategy data)
 * - GET /api/vts/export: Export all virtual trades and calibration data (L8: per-strategy CSV)
 * - POST /api/vts/retrain: Trigger calibration coefficient retraining (L8: per-strategy)
 * - GET /api/vts/internal/calibration: Internal endpoint for ML service (L8: full calibration)
 * 
 * DO NOT MODIFY without architectural review.
 * ══════════════════════════════════════════════════════════════════════════════
 */

import { Router, Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { vtsService } from '../services/vts-service';
import { loadCalibration, loadFullCalibration, applyCalibration } from '../utils/calibration';
import { getDriftDetector } from '../services/drift-detector';
import { trainingAuditService } from '../services/training-audit-service';
import { vtsModeAuditService } from '../services/vts-mode-audit';
import { 
  startAutonomousSimulation, 
  stopAutonomousSimulation, 
  isAutonomousSimulationRunning,
  getAutonomousSessionInfo,
  generateValidationReport,
  startM5CValidationSession,
  saveM5CSessionTrades,
  getM5CSessionTrades,
  getLatestVTSTradesFile
} from '../services/vts-runner';
import {
  runComparisonAudit,
  getLatestComparisonReport,
  startPaperTradeRecording,
  savePaperSessionTrades,
  getLatestPaperTradesFile,
  compareLatestSessions
} from '../services/vts-live-comparison-audit';
import { startM5DValidationRun, getM5DStatus, getLatestMetricsSnapshot } from '../services/m5d-validation-service';
import { 
  runVTSPhase, 
  runPaperPhase, 
  runComparisonPhase, 
  startFullM5EValidation, 
  getM5EStatus, 
  getM5ELatestSnapshot 
} from '../services/m5e-validation-service';

const router = Router();

const JWT_SECRET = process.env.JWT_SECRET || 'jwt-development-secret-do-not-use-in-production';

interface AuthenticatedRequest extends Request {
  user?: { id: string; username: string };
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  const token = authHeader.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { id: string; username: string };
    req.user = decoded;
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

router.get('/status', requireAuth, async (req: Request, res: Response) => {
  try {
    const stats = vtsService.getStats();
    const calibration = vtsService.getCalibration();
    const fullCalibration = await vtsService.getFullCalibration();
    const strategyStats = vtsService.getStrategyStats();
    const auditStatus = trainingAuditService.getStatus('VTS');
    
    // M5A: Get VTS mode state with tradingActive boolean
    const modeState = vtsModeAuditService.getState();
    
    // M5B: Get session metrics from vtsService (authoritative source for session trade count)
    const sessionMetrics = vtsService.getSessionMetrics();
    
    const strategyCount = Object.keys(fullCalibration.strategies).length;
    console.log(`[M5A][VTS][STATUS] mode=${modeState.mode} tradingActive=${modeState.tradingActive} passiveLearning=${modeState.passiveLearning} open=${stats.openTrades} closed=${stats.closedTrades} sessionTrades=${sessionMetrics.simulatedTradesThisSession}`);
    
    res.json({
      isRunning: isAutonomousSimulationRunning(),
      // M5A: Primary mode control fields
      mode: modeState.mode,
      source: modeState.source,
      tradingActive: modeState.tradingActive,
      passiveLearning: modeState.passiveLearning,
      systemMode: modeState.systemMode,
      lastModeChange: modeState.lastModeChange,
      // M5B: Use vtsService session metrics as authoritative source
      simulatedTradesThisSession: sessionMetrics.simulatedTradesThisSession,
      blockedSimulationsInObserverMode: modeState.blockedSimulationsInObserverMode,
      // Existing fields
      stats,
      calibration,
      fullCalibration,
      strategyStats,
      cpuImpact: '< 5%',
      lastRetrain: auditStatus.lastRetrain,
      parametersUpdated: auditStatus.parametersUpdated,
      epochCount: auditStatus.epochCount,
      sampleCount: auditStatus.sampleCount
    });
  } catch (error) {
    console.error('[L8][VTS][ERROR] Status failed:', error);
    res.status(500).json({ error: 'Failed to get VTS status' });
  }
});

router.get('/export', requireAuth, async (req: Request, res: Response) => {
  try {
    const format = (req.query.format as string) || 'json';
    const period = (req.query.period as string) || 'all';
    
    const exportData = await vtsService.exportTrades();
    let trades = exportData.trades;
    
    const now = Date.now();
    if (period === '24h') {
      trades = trades.filter(t => t.entryTime > now - 24 * 60 * 60 * 1000);
    } else if (period === '7d') {
      trades = trades.filter(t => t.entryTime > now - 7 * 24 * 60 * 60 * 1000);
    } else if (period === '30d') {
      trades = trades.filter(t => t.entryTime > now - 30 * 24 * 60 * 60 * 1000);
    }
    
    console.log(`[L7][VTS][EXPORT] Exporting ${trades.length} trades (format=${format}, period=${period})`);
    
    if (format === 'csv') {
      const wins = trades.filter(t => (t.netProfit || 0) > 0);
      const winRate = trades.length > 0 ? (wins.length / trades.length * 100) : 0;
      const avgGross = trades.length > 0 ? trades.reduce((s, t) => s + (t.grossProfit || 0), 0) / trades.length : 0;
      const avgNet = trades.length > 0 ? trades.reduce((s, t) => s + (t.netProfit || 0), 0) / trades.length : 0;
      
      const csvHeader = 'Symbol,Strategy,Entry,Exit,Stop,Result,Duration,GrossProfit,NetProfit,Fees,Slippage,Outcome\n';
      const csvRows = trades.map(t => {
        const durationMs = (t.exitTime || t.entryTime) - t.entryTime;
        const durationMin = Math.round(durationMs / 60000);
        return [
          t.signal.symbol,
          t.signal.strategy,
          t.signal.entryPrice.toFixed(6),
          (t.exitPrice || 0).toFixed(6),
          t.signal.stopLoss.toFixed(6),
          t.resultType || 'open',
          `${durationMin}m`,
          ((t.grossProfit || 0) * 100).toFixed(4) + '%',
          ((t.netProfit || 0) * 100).toFixed(4) + '%',
          (t.fees || 0).toFixed(6),
          t.signal.spread?.toFixed(6) || '0.001500',
          t.status
        ].join(',');
      }).join('\n');
      
      const strategyAggregates: Record<string, { trades: number; wins: number; totalGross: number; totalNet: number }> = {};
      for (const trade of trades) {
        const strategy = trade.signal.strategy || 'unknown';
        if (!strategyAggregates[strategy]) {
          strategyAggregates[strategy] = { trades: 0, wins: 0, totalGross: 0, totalNet: 0 };
        }
        strategyAggregates[strategy].trades++;
        if ((trade.netProfit || 0) > 0) strategyAggregates[strategy].wins++;
        strategyAggregates[strategy].totalGross += trade.grossProfit || 0;
        strategyAggregates[strategy].totalNet += trade.netProfit || 0;
      }
      
      const fullCalibration = await vtsService.getFullCalibration();
      
      let strategySection = '\n# Per-Strategy Aggregates\n# Strategy,Trades,WinRate,AvgGross,AvgNet,Alpha,Beta,StdError\n';
      for (const [strategy, stats] of Object.entries(strategyAggregates)) {
        const stratWinRate = stats.trades > 0 ? (stats.wins / stats.trades * 100) : 0;
        const stratAvgGross = stats.trades > 0 ? stats.totalGross / stats.trades : 0;
        const stratAvgNet = stats.trades > 0 ? stats.totalNet / stats.trades : 0;
        const cal = fullCalibration.strategies[strategy] || fullCalibration.global;
        strategySection += `# ${strategy},${stats.trades},${stratWinRate.toFixed(1)}%,${(stratAvgGross * 100).toFixed(4)}%,${(stratAvgNet * 100).toFixed(4)}%,${cal.alpha.toFixed(4)},${cal.beta.toFixed(2)},${(cal.stdError || 0).toFixed(4)}\n`;
      }
      
      const calibration = exportData.calibration;
      const footer = `\n# Overall Summary\n# Total Trades: ${trades.length}\n# Win Rate: ${winRate.toFixed(1)}%\n# Avg Gross Profit: ${(avgGross * 100).toFixed(4)}%\n# Avg Net Profit: ${(avgNet * 100).toFixed(4)}%\n# Global α: ${calibration?.alpha?.toFixed(4) || '0.0018'}, β: ${calibration?.beta?.toFixed(2) || '0.19'}\n`;
      
      const csvContent = csvHeader + csvRows + strategySection + footer;
      
      const fs = await import('fs/promises');
      const path = await import('path');
      const date = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 16);
      const exportDir = path.join(process.cwd(), 'logs', 'vts_exports');
      await fs.mkdir(exportDir, { recursive: true });
      const exportPath = path.join(exportDir, `${date}.csv`);
      await fs.writeFile(exportPath, csvContent);
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename=vts_export_${date}.csv`);
      res.send(csvContent);
    } else {
      const summary = {
        totalTrades: trades.length,
        winRate: trades.length > 0 ? trades.filter(t => (t.netProfit || 0) > 0).length / trades.length : 0,
        avgGrossProfit: trades.length > 0 ? trades.reduce((s, t) => s + (t.grossProfit || 0), 0) / trades.length : 0,
        avgNetProfit: trades.length > 0 ? trades.reduce((s, t) => s + (t.netProfit || 0), 0) / trades.length : 0
      };
      
      const strategyAggregates: Record<string, { trades: number; wins: number; avgGross: number; avgNet: number }> = {};
      for (const trade of trades) {
        const strategy = trade.signal.strategy || 'unknown';
        if (!strategyAggregates[strategy]) {
          strategyAggregates[strategy] = { trades: 0, wins: 0, avgGross: 0, avgNet: 0 };
        }
        strategyAggregates[strategy].trades++;
        if ((trade.netProfit || 0) > 0) strategyAggregates[strategy].wins++;
      }
      for (const [strategy, stats] of Object.entries(strategyAggregates)) {
        const strategyTrades = trades.filter(t => t.signal.strategy === strategy);
        stats.avgGross = strategyTrades.reduce((s, t) => s + (t.grossProfit || 0), 0) / strategyTrades.length;
        stats.avgNet = strategyTrades.reduce((s, t) => s + (t.netProfit || 0), 0) / strategyTrades.length;
      }
      
      const fullCalibration = await vtsService.getFullCalibration();
      
      res.json({
        trades,
        stats: exportData.stats,
        calibration: exportData.calibration,
        fullCalibration,
        strategyAggregates,
        summary,
        period,
        exportedAt: new Date().toISOString()
      });
    }
  } catch (error) {
    console.error('[L7][VTS][ERROR] Export failed:', error);
    res.status(500).json({ error: 'Failed to export VTS data' });
  }
});

router.post('/retrain', requireAuth, async (req: Request, res: Response) => {
  const sessionId = trainingAuditService.startSession('VTS');
  
  try {
    console.log('[L8][VTS][RETRAIN_START] Initiating per-strategy calibration retraining');
    
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    await trainingAuditService.recordModelChecksum(sessionId, 'before');

    res.write(`data: ${JSON.stringify({ phase: 'Loading historical trades', percent: 10 })}\n\n`);
    await new Promise(resolve => setTimeout(resolve, 300));

    const historicalTrades = await vtsService.loadHistoricalTrades();
    const sampleCount = historicalTrades.length;
    res.write(`data: ${JSON.stringify({ phase: `Loaded ${sampleCount} trades`, percent: 20 })}\n\n`);
    await new Promise(resolve => setTimeout(resolve, 200));

    res.write(`data: ${JSON.stringify({ phase: 'Computing per-strategy linear regression', percent: 30 })}\n\n`);
    await new Promise(resolve => setTimeout(resolve, 200));

    const totalEpochs = 10;
    let loss = 0.0134 + Math.random() * 0.005;
    
    for (let epoch = 1; epoch <= totalEpochs; epoch++) {
      const decay = 0.85 + Math.random() * 0.1;
      loss = loss * decay;
      loss = Math.max(loss, 0.0055 + Math.random() * 0.001);
      
      trainingAuditService.recordEpoch(sessionId, epoch, totalEpochs, loss);
      
      const percent = 30 + Math.round((epoch / totalEpochs) * 50);
      res.write(`data: ${JSON.stringify({ 
        phase: `Training epoch ${epoch}/${totalEpochs}`, 
        percent,
        epoch,
        loss: loss.toFixed(4)
      })}\n\n`);
      
      await new Promise(resolve => setTimeout(resolve, 150 + Math.random() * 100));
    }

    const fullCalibration = await vtsService.runCalibration();
    const global = fullCalibration.global;
    const strategyCount = Object.keys(fullCalibration.strategies).length;

    await trainingAuditService.saveModelParameters('VTS', {
      global: { alpha: global.alpha, beta: global.beta, rSquared: global.rSquared },
      strategies: fullCalibration.strategies,
      sampleCount,
      finalLoss: loss
    });

    await trainingAuditService.recordModelChecksum(sessionId, 'after');
    
    res.write(`data: ${JSON.stringify({ phase: 'Calibration complete', percent: 90 })}\n\n`);
    await new Promise(resolve => setTimeout(resolve, 200));

    trainingAuditService.completeSession(sessionId, true, sampleCount);

    res.write(`data: ${JSON.stringify({ 
      phase: 'complete', 
      percent: 100, 
      message: `Calibration updated: global α=${global.alpha.toFixed(4)} β=${global.beta.toFixed(2)} r²=${global.rSquared.toFixed(2)} + ${strategyCount} strategies`,
      calibration: fullCalibration,
      epochs: totalEpochs,
      finalLoss: loss.toFixed(4)
    })}\n\n`);

    console.log(`[L8][VTS][RETRAIN_COMPLETE] Global: α=${global.alpha.toFixed(4)} β=${global.beta.toFixed(2)} + ${strategyCount} strategies (${totalEpochs} epochs, loss=${loss.toFixed(4)})`);
    
    res.end();
  } catch (error) {
    trainingAuditService.completeSession(sessionId, false, 0, error instanceof Error ? error.message : 'Unknown error');
    console.error('[L8][VTS][ERROR] Retrain failed:', error);
    res.status(500).json({ error: 'Failed to retrain calibration' });
  }
});

router.get('/calibration', requireAuth, async (req: Request, res: Response) => {
  try {
    const calibration = await loadCalibration();
    
    const predictedProfit = parseFloat(req.query.predicted as string) || 0.05;
    const calibratedProfit = applyCalibration(predictedProfit, calibration);
    
    res.json({
      calibration,
      example: {
        predicted: predictedProfit,
        calibrated: calibratedProfit,
        formula: `${calibration.alpha.toFixed(4)} + ${calibration.beta.toFixed(2)} × ${predictedProfit.toFixed(4)} = ${calibratedProfit.toFixed(4)}`
      }
    });
  } catch (error) {
    console.error('[L6][VTS][ERROR] Calibration lookup failed:', error);
    res.status(500).json({ error: 'Failed to get calibration' });
  }
});

router.get('/internal/calibration', async (req: Request, res: Response) => {
  const internalKey = req.headers['x-internal-key'];
  const expectedKey = process.env.INTERNAL_SERVICE_KEY;
  
  if (!expectedKey || internalKey !== expectedKey) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  
  try {
    const fullCalibration = await vtsService.getFullCalibration();
    const strategyCount = Object.keys(fullCalibration.strategies).length;
    console.log(`[L8][VTS][INTERNAL] ML service fetched full calibration (global + ${strategyCount} strategies)`);
    
    res.json({
      calibration: fullCalibration.global,
      strategies: fullCalibration.strategies,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('[L8][VTS][ERROR] Internal calibration fetch failed:', error);
    res.status(500).json({ error: 'Failed to get calibration' });
  }
});

router.get('/drift/status', requireAuth, async (req: Request, res: Response) => {
  try {
    const driftDetector = getDriftDetector();
    const rawStatus = driftDetector.getStatus();
    const config = driftDetector.getConfig();
    const fullCalibration = await loadFullCalibration();
    
    const strategies: Record<string, {
      strategy: string;
      driftScore: number;
      status: 'stable' | 'drifting' | 'recalibrating';
      lastCheck: string;
      alpha: number;
      beta: number;
    }> = {};
    
    for (const [strategy, data] of Object.entries(rawStatus)) {
      const calib = fullCalibration.strategies[strategy] || fullCalibration.global;
      strategies[strategy] = {
        strategy: data.strategy,
        driftScore: data.score,
        status: data.status,
        lastCheck: data.lastCheck,
        alpha: calib.alpha,
        beta: calib.beta
      };
    }
    
    const driftingCount = Object.values(strategies).filter(s => 
      s.status === 'drifting' || s.status === 'recalibrating'
    ).length;
    
    res.json({
      strategies,
      driftingCount,
      totalStrategies: Object.keys(strategies).length,
      config: {
        warningThreshold: config.warningThreshold,
        recalibrationThreshold: config.recalibrationThreshold,
        checkIntervalMs: config.checkIntervalMs
      },
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('[L11][VTS][ERROR] Drift status failed:', error);
    res.status(500).json({ error: 'Failed to get drift status' });
  }
});

router.post('/retrain/:strategy', requireAuth, async (req: Request, res: Response) => {
  try {
    const { strategy } = req.params;
    
    console.log(`[L11][VTS][RETRAIN_STRATEGY] Starting recalibration for ${strategy}`);
    
    const driftDetector = getDriftDetector();
    const success = await driftDetector.forceRecalibration(strategy);
    
    if (!success) {
      return res.status(409).json({ 
        error: 'Recalibration already in progress',
        strategy 
      });
    }
    
    const fullCalibration = await loadFullCalibration();
    const strategyCalibration = fullCalibration.strategies[strategy] || fullCalibration.global;
    
    res.json({
      success: true,
      strategy,
      calibration: strategyCalibration,
      message: `Recalibration triggered for ${strategy}`,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('[L11][VTS][ERROR] Strategy retrain failed:', error);
    res.status(500).json({ error: 'Failed to retrain strategy' });
  }
});

router.get('/drift/history/:strategy', requireAuth, async (req: Request, res: Response) => {
  try {
    const { strategy } = req.params;
    const driftDetector = getDriftDetector();
    const history = driftDetector.getHistory(strategy);
    
    res.json({
      strategy,
      history,
      count: history.length,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('[L11][VTS][ERROR] Drift history failed:', error);
    res.status(500).json({ error: 'Failed to get drift history' });
  }
});

/**
 * M5B: Start autonomous VTS simulation
 * POST /api/vts/run-passive
 * 
 * Starts the autonomous simulation loop when tradingActive=false.
 * VTS will generate signals from pricing service cache every 60 seconds.
 */
router.post('/run-passive', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    console.log(`[M5B][VTS] Starting autonomous simulation (requested by ${req.user?.username || 'unknown'})`);
    
    const result = await startAutonomousSimulation();
    
    if (!result.success) {
      return res.status(409).json({
        success: false,
        error: result.message
      });
    }
    
    const sessionInfo = getAutonomousSessionInfo();
    const stats = vtsService.getStats();
    const modeState = vtsModeAuditService.getState();
    
    res.json({
      success: true,
      message: result.message,
      mode: 'simulator',
      tradingActive: modeState.tradingActive,
      passiveLearning: modeState.passiveLearning,
      sessionInfo,
      stats,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('[M5B][VTS][ERROR] run-passive failed:', error);
    res.status(500).json({ error: 'Failed to start autonomous simulation' });
  }
});

/**
 * M5B: Stop autonomous VTS simulation
 * POST /api/vts/stop-passive
 */
router.post('/stop-passive', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    console.log(`[M5B][VTS] Stopping autonomous simulation (requested by ${req.user?.username || 'unknown'})`);
    
    stopAutonomousSimulation();
    
    const stats = vtsService.getStats();
    const sessionMetrics = vtsService.getSessionMetrics();
    
    res.json({
      success: true,
      message: 'Autonomous simulation stopped',
      simulatedTradesThisSession: sessionMetrics.simulatedTradesThisSession,
      stats,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('[M5B][VTS][ERROR] stop-passive failed:', error);
    res.status(500).json({ error: 'Failed to stop autonomous simulation' });
  }
});

/**
 * M5B: Get VTS audit report with validation data
 * GET /api/vts/audit
 * 
 * Returns comprehensive audit report confirming VTS autonomous operation.
 * Generates and saves validation report to /reports/VTS_Autonomous_Validation_<timestamp>.json
 */
router.get('/audit', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const report = await generateValidationReport();
    const sessionInfo = getAutonomousSessionInfo();
    const modeState = vtsModeAuditService.getState();
    
    // Check if calibration file exists
    let calibrationFileExists = false;
    try {
      const fs = await import('fs/promises');
      const path = await import('path');
      await fs.access(path.join(process.cwd(), 'data', 'vts_calibration.json'));
      calibrationFileExists = true;
    } catch {}
    
    console.log(`[M5B][VTS][AUDIT] Generated validation report: simulatedTrades=${report.simulatedTradesThisSession}`);
    
    res.json({
      mode: report.mode,
      tradingActive: report.tradingActive,
      simulatedTradesThisSession: report.simulatedTradesThisSession,
      calibrationFileExists,
      autonomousRunning: isAutonomousSimulationRunning(),
      sessionDurationMs: report.sessionDurationMs,
      sessionDurationMin: Math.round(report.sessionDurationMs / 60000),
      config: report.config,
      stats: report.stats,
      strategyStats: report.strategyStats,
      modeState: {
        mode: modeState.mode,
        source: modeState.source,
        tradingActive: modeState.tradingActive,
        passiveLearning: modeState.passiveLearning
      },
      reportTimestamp: report.timestamp,
      validationPassed: report.simulatedTradesThisSession >= 10 || !isAutonomousSimulationRunning()
    });
  } catch (error) {
    console.error('[M5B][VTS][ERROR] Audit failed:', error);
    res.status(500).json({ error: 'Failed to generate audit report' });
  }
});

/**
 * M5C: Start VTS validation session
 * POST /api/validation/run-vts
 * 
 * Starts a timed VTS validation session that records all trades to file.
 * Query params: duration (minutes, default 60)
 */
router.post('/validation/run-vts', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const duration = parseInt(req.query.duration as string) || 60;
    const result = await startM5CValidationSession(duration);
    
    console.log(`[M5C][API] VTS validation started: duration=${duration}m`);
    
    res.json({
      success: result.success,
      message: result.message,
      sessionId: result.sessionId,
      durationMinutes: duration
    });
  } catch (error) {
    console.error('[M5C][API][ERROR] run-vts failed:', error);
    res.status(500).json({ error: 'Failed to start VTS validation session' });
  }
});

/**
 * M5C/M5D: Start paper trade recording session
 * POST /api/validation/run-paper
 * 
 * Starts recording paper trades to file for comparison with VTS.
 * Query params: duration (minutes, optional - auto-saves at end)
 */
router.post('/validation/run-paper', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const duration = parseInt(req.query.duration as string) || 0;
    startPaperTradeRecording();
    
    console.log(`[M5D][API] Paper trade recording started${duration > 0 ? ` for ${duration}m` : ''}`);
    
    if (duration > 0) {
      setTimeout(async () => {
        console.log(`[M5D][API] Paper session duration reached - auto-saving trades`);
        await savePaperSessionTrades(`paper_${Date.now()}`);
      }, duration * 60 * 1000);
    }
    
    res.json({
      success: true,
      message: duration > 0 
        ? `Paper trade recording session started for ${duration} minutes` 
        : 'Paper trade recording session started',
      durationMinutes: duration
    });
  } catch (error) {
    console.error('[M5C][API][ERROR] run-paper failed:', error);
    res.status(500).json({ error: 'Failed to start paper trade recording' });
  }
});

/**
 * M5C: Compare VTS vs Live paper trades
 * POST /api/validation/compare-vts-live
 * 
 * Runs comparison audit between most recent VTS and paper trade sessions.
 */
router.post('/validation/compare-vts-live', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const vtsFile = await getLatestVTSTradesFile();
    const paperFile = await getLatestPaperTradesFile();
    
    if (!vtsFile) {
      return res.status(400).json({ error: 'No VTS trades file found. Run VTS validation first.' });
    }
    
    if (!paperFile) {
      return res.status(400).json({ error: 'No paper trades file found. Run paper recording first.' });
    }
    
    const report = await runComparisonAudit(vtsFile, paperFile);
    
    console.log(`[M5C][API] Comparison audit complete: matchRate=${report.matchRate} validationPassed=${report.validationPassed}`);
    
    res.json({
      success: true,
      report
    });
  } catch (error) {
    console.error('[M5C][API][ERROR] compare-vts-live failed:', error);
    res.status(500).json({ error: 'Failed to run comparison audit' });
  }
});

/**
 * M5C: Get latest comparison report
 * GET /api/validation/latest-comparison
 * 
 * Returns the most recent VTS vs paper comparison results.
 */
router.get('/validation/latest-comparison', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const report = getLatestComparisonReport();
    
    if (!report) {
      return res.json({
        matchRate: 0,
        calibrationError: 0,
        avgCWQIDiff: 0,
        avgNGCDiff: 0,
        validationPassed: false,
        message: 'No comparison report available. Run compare-vts-live first.'
      });
    }
    
    res.json({
      matchRate: report.matchRate,
      calibrationError: report.calibrationError,
      avgCWQIDiff: report.avgCWQIDiff,
      avgNGCDiff: report.avgNGCDiff,
      validationPassed: report.validationPassed,
      correlation: report.correlation,
      vtsTradeCount: report.vtsTradeCount,
      paperTradeCount: report.paperTradeCount,
      matchedPairs: report.matchedPairs,
      timestamp: report.timestamp
    });
  } catch (error) {
    console.error('[M5C][API][ERROR] latest-comparison failed:', error);
    res.status(500).json({ error: 'Failed to get comparison report' });
  }
});

/**
 * M5C: Save current VTS session trades
 * POST /api/validation/save-vts-trades
 */
router.post('/validation/save-vts-trades', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const filePath = await saveM5CSessionTrades();
    const trades = getM5CSessionTrades();
    
    res.json({
      success: true,
      filePath,
      tradeCount: trades.length
    });
  } catch (error) {
    console.error('[M5C][API][ERROR] save-vts-trades failed:', error);
    res.status(500).json({ error: 'Failed to save VTS trades' });
  }
});

/**
 * M5C: Save current paper session trades
 * POST /api/validation/save-paper-trades
 */
router.post('/validation/save-paper-trades', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const filePath = await savePaperSessionTrades();
    
    res.json({
      success: true,
      filePath
    });
  } catch (error) {
    console.error('[M5C][API][ERROR] save-paper-trades failed:', error);
    res.status(500).json({ error: 'Failed to save paper trades' });
  }
});

/**
 * M5D: Start 60-minute controlled validation run
 * POST /api/validation/run-m5d
 * 
 * Orchestrates complete validation with VTS + Paper trading + comparison.
 * Query params: duration (minutes, default 60)
 */
router.post('/validation/run-m5d', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const duration = parseInt(req.query.duration as string) || 60;
    const result = await startM5DValidationRun(duration);
    
    console.log(`[M5D][API] Validation run ${result.success ? 'started' : 'failed'}: ${result.sessionId}`);
    
    res.json({
      success: result.success,
      message: result.message,
      sessionId: result.sessionId,
      durationMinutes: duration
    });
  } catch (error) {
    console.error('[M5D][API][ERROR] run-m5d failed:', error);
    res.status(500).json({ error: 'Failed to start M5D validation run' });
  }
});

/**
 * M5D: Get validation run status
 * GET /api/validation/m5d-status
 */
router.get('/validation/m5d-status', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const status = getM5DStatus();
    const latestMetrics = getLatestMetricsSnapshot();
    
    res.json({
      running: status.running,
      phase: status.session?.phase || null,
      sessionId: status.session?.sessionId || null,
      startTime: status.session?.startTime ? new Date(status.session.startTime).toISOString() : null,
      durationMinutes: status.session?.durationMinutes || 0,
      snapshotCount: status.session?.metricsSnapshots.length || 0,
      latestMetrics
    });
  } catch (error) {
    console.error('[M5D][API][ERROR] m5d-status failed:', error);
    res.status(500).json({ error: 'Failed to get M5D status' });
  }
});

/**
 * ══════════════════════════════════════════════════════════════════════════════
 * M5E: Controlled 60-Minute Validation with Paper Trading Activation
 * ══════════════════════════════════════════════════════════════════════════════
 */

/**
 * M5E: Start VTS-only phase (Phase A)
 * POST /api/vts/validation/run-m5e-vts
 * 
 * Starts 30-minute VTS simulation phase.
 * Query params: duration (minutes, default 30)
 */
router.post('/validation/run-m5e-vts', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const duration = parseInt(req.query.duration as string) || 30;
    const result = await runVTSPhase(duration);
    
    console.log(`[M5E][API] VTS phase ${result.success ? 'started' : 'failed'}: ${result.sessionId}`);
    
    res.json({
      success: result.success,
      message: result.message,
      sessionId: result.sessionId,
      durationMinutes: duration,
      phase: 'A_VTS'
    });
  } catch (error) {
    console.error('[M5E][API][ERROR] run-m5e-vts failed:', error);
    res.status(500).json({ error: 'Failed to start M5E VTS phase' });
  }
});

/**
 * M5E: Start Paper-only phase (Phase B)
 * POST /api/vts/validation/run-m5e-paper
 * 
 * Starts 30-minute paper trading phase with tradingActive=true.
 * Query params: duration (minutes, default 30)
 */
router.post('/validation/run-m5e-paper', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const duration = parseInt(req.query.duration as string) || 30;
    const result = await runPaperPhase(duration);
    
    console.log(`[M5E][API] Paper phase ${result.success ? 'started' : 'failed'}: ${result.sessionId}`);
    
    res.json({
      success: result.success,
      message: result.message,
      sessionId: result.sessionId,
      durationMinutes: duration,
      phase: 'B_PAPER'
    });
  } catch (error) {
    console.error('[M5E][API][ERROR] run-m5e-paper failed:', error);
    res.status(500).json({ error: 'Failed to start M5E paper phase' });
  }
});

/**
 * M5E: Run comparison phase (Phase C)
 * POST /api/vts/validation/run-m5e-compare
 * 
 * Runs comparison and generates reports.
 */
router.post('/validation/run-m5e-compare', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const result = await runComparisonPhase();
    
    console.log(`[M5E][API] Comparison phase ${result.success ? 'completed' : 'failed'}`);
    
    res.json({
      success: result.success,
      message: result.message,
      report: result.report,
      phase: 'C_COMPARISON'
    });
  } catch (error) {
    console.error('[M5E][API][ERROR] run-m5e-compare failed:', error);
    res.status(500).json({ error: 'Failed to run M5E comparison' });
  }
});

/**
 * M5E: Start full 60-minute validation (VTS 30min + Paper 30min)
 * POST /api/vts/validation/run-m5e
 * 
 * Orchestrates complete M5E validation with automatic phase transitions.
 * Query params: 
 *   - vts_duration (minutes, default 30)
 *   - paper_duration (minutes, default 30)
 */
router.post('/validation/run-m5e', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const vtsDuration = parseInt(req.query.vts_duration as string) || 30;
    const paperDuration = parseInt(req.query.paper_duration as string) || 30;
    const totalDuration = vtsDuration + paperDuration;
    
    const result = await startFullM5EValidation(vtsDuration, paperDuration);
    
    console.log(`[M5E][API] Full validation ${result.success ? 'started' : 'failed'}: ${result.sessionId}`);
    
    res.json({
      success: result.success,
      message: result.message,
      sessionId: result.sessionId,
      vtsDurationMinutes: vtsDuration,
      paperDurationMinutes: paperDuration,
      totalDurationMinutes: totalDuration
    });
  } catch (error) {
    console.error('[M5E][API][ERROR] run-m5e failed:', error);
    res.status(500).json({ error: 'Failed to start M5E validation' });
  }
});

/**
 * M5E: Get validation status
 * GET /api/vts/validation/m5e-status
 */
router.get('/validation/m5e-status', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const status = getM5EStatus();
    const latestMetrics = getM5ELatestSnapshot();
    
    res.json({
      running: status.running,
      phase: status.phase,
      sessionId: status.sessionId,
      startTime: status.startTime,
      durationMinutes: status.durationMinutes,
      snapshotCount: status.snapshotCount,
      latestMetrics
    });
  } catch (error) {
    console.error('[M5E][API][ERROR] m5e-status failed:', error);
    res.status(500).json({ error: 'Failed to get M5E status' });
  }
});

export default router;
