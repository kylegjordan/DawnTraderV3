/**
 * Phase 41F-C: Health Monitoring API Routes
 * Directive 8.8.4-A4.R10R-4: System Health Endpoint
 * 
 * Provides HTTP and WebSocket access to engine health metrics
 */

import { Router } from 'express';
import { healthMonitor } from '../services/health-monitor.js';
import { systemHealth } from '../services/system-health.js';
import { getMLServiceStatus } from '../services/ml-service-client.js';
import { loadFullCalibration } from '../utils/calibration.js';
import { computeStrategyWeights, type StrategyWeightsBundle } from '../utils/strategyWeights.js';
import { computeExposureBias, getOverbiasedStrategies, type ExposureBiasBundle } from '../utils/strategyBias.js';
import { getDriftDetector, type StrategyDriftStatus } from '../services/drift-detector.js';
import { getMarketProfiler } from '../services/market-profiler.js';
import { getAdaptiveRegime } from '../services/adaptive-regime.js';
import { getRegimePerformanceTracker } from '../services/regime-performance.js';
import { getProactiveAllocator } from '../services/proactive-allocator.js';
import { getRewardEvaluator } from '../services/reward-evaluator.js';
import { getExperienceBuffer } from '../services/experience-buffer.js';
import { getActionExecutor } from '../services/action-executor.js';
import { getMACOCoordinator } from '../services/maco-coordinator.js';
import { getExplorationManager } from '../services/exploration-manager.js';
import { getPolicyConsensusEngine } from '../services/policy-consensus.js';
import { getDecisionConfidenceEngine } from '../services/decision-confidence-engine.js';
import { getAPRSLEEngine } from '../services/apr-sle-engine.js';
import { getPDCEngine } from '../services/pdc-engine.js';
import { getECSController } from '../services/ecs-controller.js';
import { getMOFOrchestrator } from '../services/mof-orchestrator.js';

export const healthRouter = Router();

/**
 * GET /api/health/engine
 * Returns latest heartbeat + ring buffer
 */
healthRouter.get('/engine', async (req, res) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    
    const response = {
      latest: healthMonitor.getLatest(),
      ringBuffer: healthMonitor.getRingBuffer(limit),
      recoveryActions: healthMonitor.getRecoveryActions(10),
    };

    res.json(response);
  } catch (error: any) {
    console.error('[41F-C][API] Error fetching engine health:', error.message);
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/health/summary
 * Returns reduced payload for widgets
 */
healthRouter.get('/summary', async (req, res) => {
  try {
    const summary = healthMonitor.getSummary();
    const latest = healthMonitor.getLatest();
    const recoveryActions = healthMonitor.getRecoveryActions(5);

    res.json({
      ...summary,
      timestamp: latest?.ts || new Date().toISOString(),
      recentRecoveries: recoveryActions.length,
    });
  } catch (error: any) {
    console.error('[41F-C][API] Error fetching health summary:', error.message);
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/health/recovery
 * Returns recent recovery actions
 */
healthRouter.get('/recovery', async (req, res) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    
    res.json({
      actions: healthMonitor.getRecoveryActions(limit),
    });
  } catch (error: any) {
    console.error('[41F-C][API] Error fetching recovery actions:', error.message);
    res.status(500).json({ error: error.message });
  }
});

/**
 * Phase 41F-F: GET /api/health/recovery/log
 * Returns recent recovery events (recovery actions + anomalies)
 */
healthRouter.get('/recovery/log', async (req, res) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
    
    const recoveries = healthMonitor.getRecoveryActions(limit);
    const anomalies = healthMonitor.getAnomalies(limit);

    res.json({
      ok: true,
      recoveries,
      anomalies,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('[41F-F][API] Error fetching recovery log:', error.message);
    res.status(500).json({ ok: false, error: error.message });
  }
});

/**
 * Phase 41F-F: POST /api/health/recovery/trigger
 * Manual recovery test (for fault injection)
 */
healthRouter.post('/recovery/trigger', async (req, res) => {
  try {
    const { component, reason } = req.body;

    console.log(`[41F-F][API] Manual recovery trigger requested: ${component} - ${reason}`);

    // Log a test recovery action
    const testRecovery = {
      timestamp: new Date().toISOString(),
      component: component || 'manual_test',
      issue: reason || 'Manual recovery test triggered',
      action: 'manual_trigger',
      success: true,
      details: { triggeredBy: 'api', endpoint: '/api/health/recovery/trigger' },
    };

    res.json({
      ok: true,
      message: 'Manual recovery trigger logged',
      recovery: testRecovery,
    });
  } catch (error: any) {
    console.error('[41F-F][API] Error triggering manual recovery:', error.message);
    res.status(500).json({ ok: false, error: error.message });
  }
});

/**
 * Phase 41F-F: GET /api/health/anomalies
 * Returns detected anomalies
 */
healthRouter.get('/anomalies', async (req, res) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
    const level = req.query.level as 'warning' | 'critical' | undefined;
    
    let anomalies = healthMonitor.getAnomalies(limit);
    
    // Filter by level if specified
    if (level) {
      anomalies = anomalies.filter(a => a.level === level);
    }

    res.json({
      ok: true,
      anomalies,
      count: anomalies.length,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('[41F-F][API] Error fetching anomalies:', error.message);
    res.status(500).json({ ok: false, error: error.message });
  }
});

/**
 * Phase 41F-G: POST /api/health/recovery/test
 * Execute or plan recovery action (supports dry-run mode)
 */
healthRouter.post('/recovery/test', async (req, res) => {
  try {
    const { component, metric, level, dryRun } = req.body;

    console.log(`[41F-G][API] Recovery test requested: ${component}.${metric} (${level}) dryRun=${dryRun}`);

    // Execute recovery (or dry-run)
    const result = await healthMonitor.executeRecovery(component, metric, level || 'critical', dryRun);

    res.json({
      ok: true,
      ...result,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('[41F-G][API] Error executing recovery test:', error.message);
    res.status(500).json({ ok: false, error: error.message });
  }
});

/**
 * Phase 41F-G: GET /api/health/circuit-breaker
 * Returns circuit breaker status
 */
healthRouter.get('/circuit-breaker', async (req, res) => {
  try {
    const status = healthMonitor.getCircuitBreakerStatus();
    
    res.json({
      ok: true,
      ...status,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('[41F-G][API] Error fetching circuit breaker status:', error.message);
    res.status(500).json({ ok: false, error: error.message });
  }
});

/**
 * Directive 8.8.4-A4.R10R-4: GET /api/health
 * Directive 8.8.4-L8: Extended with per-strategy VTS calibration health
 * Returns system health metrics (CPU, memory, lag, uptime) + ML service status + VTS per-strategy
 */
healthRouter.get('/', async (req, res) => {
  try {
    const metrics = systemHealth.getMetrics();
    const status = systemHealth.getStatus();
    
    const mlStatus = await getMLServiceStatus();
    
    interface StrategyHealth {
      name: string;
      alpha: number;
      beta: number;
      sampleSize: number;
      warning?: string;
    }
    
    let vtsHealth: {
      status: string;
      lastCalibration: string | null;
      alpha: number;
      beta: number;
      sampleSize: number;
      stdError: number;
      warning: string | null;
      strategies: StrategyHealth[];
    } = {
      status: 'unknown',
      lastCalibration: null,
      alpha: 0.0018,
      beta: 0.19,
      sampleSize: 0,
      stdError: 0,
      warning: null,
      strategies: []
    };
    
    try {
      const fullCalibration = await loadFullCalibration();
      const global = fullCalibration.global;
      const betaDeviation = Math.abs(global.beta - 1.0);
      const stdError = global.stdError || 0;
      
      let warning: string | null = null;
      if (betaDeviation > 0.3) {
        warning = `β deviation high: |β-1|=${betaDeviation.toFixed(2)}`;
      } else if (stdError > 0.05) {
        warning = `Standard error high: ${stdError.toFixed(4)}`;
      }
      
      const strategies: StrategyHealth[] = [];
      for (const [name, cal] of Object.entries(fullCalibration.strategies)) {
        const stratBetaDev = Math.abs(cal.beta - 1.0);
        const stratStdError = cal.stdError || 0;
        let stratWarning: string | undefined;
        
        if (cal.sampleCount < 10) {
          stratWarning = `Insufficient samples: ${cal.sampleCount}`;
        } else if (stratBetaDev > 0.3) {
          stratWarning = `β deviation high: |β-1|=${stratBetaDev.toFixed(2)}`;
        } else if (stratStdError > 0.05) {
          stratWarning = `Standard error high: ${stratStdError.toFixed(4)}`;
        }
        
        strategies.push({
          name,
          alpha: cal.alpha,
          beta: cal.beta,
          sampleSize: cal.sampleCount,
          warning: stratWarning
        });
      }
      
      vtsHealth = {
        status: global.sampleCount >= 10 ? 'ok' : 'insufficient_data',
        lastCalibration: global.timestamp || new Date(global.updated).toISOString(),
        alpha: global.alpha,
        beta: global.beta,
        sampleSize: global.sampleCount,
        stdError,
        warning,
        strategies
      };
    } catch (e) {
      vtsHealth.status = 'error';
    }
    
    // L9: Compute strategy weights for health display
    let strategyWeightsData: Record<string, number> = {};
    try {
      const weightsBundle = await computeStrategyWeights();
      strategyWeightsData = weightsBundle.weights;
    } catch (e) {
      console.log('[L9][HEALTH] Failed to compute strategy weights');
    }
    
    // L10: Compute exposure bias for health display
    let exposureBiasData: Record<string, { weight: number; multiplier: number; allocPercent: number }> = {};
    let exposureBiasWarnings: string[] = [];
    try {
      const biasBundle = await computeExposureBias();
      for (const [strategy, bias] of Object.entries(biasBundle.strategies)) {
        exposureBiasData[strategy] = {
          weight: bias.weight,
          multiplier: bias.multiplier,
          allocPercent: bias.allocPercent
        };
      }
      exposureBiasWarnings = getOverbiasedStrategies();
    } catch (e) {
      console.log('[L10][HEALTH] Failed to compute exposure bias');
    }
    
    // L11: Get strategy drift status
    let strategyDriftData: Record<string, { score: number; status: string }> = {};
    let driftingStrategies: string[] = [];
    try {
      const driftDetector = getDriftDetector();
      const driftStatus = driftDetector.getStatus();
      for (const [strategy, status] of Object.entries(driftStatus)) {
        strategyDriftData[strategy] = {
          score: status.score,
          status: status.status
        };
        if (status.status === 'drifting' || status.status === 'recalibrating') {
          driftingStrategies.push(strategy);
        }
      }
    } catch (e) {
      console.log('[L11][HEALTH] Failed to get drift status');
    }
    
    // L12: Get market regime status
    let marketRegimeData: {
      current: string;
      confidence: number;
      prev: string | null;
      last_switch: string | null;
      metrics: { volatility: number; trend: number; volume_z: number } | null;
      dominantStrategies: string[];
    } = {
      current: 'R1',
      confidence: 0,
      prev: null,
      last_switch: null,
      metrics: null,
      dominantStrategies: []
    };
    try {
      const profiler = getMarketProfiler();
      const profile = profiler.getCurrentProfile();
      const regime = getAdaptiveRegime();
      const adjustments = regime.getCurrentAdjustments();
      
      if (profile) {
        marketRegimeData = {
          current: profile.regime,
          confidence: profile.confidence,
          prev: profile.previousRegime,
          last_switch: profile.lastSwitch,
          metrics: {
            volatility: profile.metrics.volatility,
            trend: profile.metrics.trend,
            volume_z: profile.metrics.volume_z
          },
          dominantStrategies: adjustments?.dominantStrategies || []
        };
      }
    } catch (e) {
      console.log('[L12][HEALTH] Failed to get market regime');
    }
    
    res.json({
      ok: true,
      healthy: status.healthy,
      metrics: {
        cpu: metrics.cpu,
        memory: metrics.memory,
        lag: metrics.lag,
        uptime: metrics.uptime,
        heapUsed: metrics.heapUsed,
        heapTotal: metrics.heapTotal,
        rss: metrics.rss,
      },
      mlService: {
        status: mlStatus.status,
        cpu: mlStatus.cpuPercent,
        memoryMB: mlStatus.memoryMB,
        modelVersions: mlStatus.modelVersions,
      },
      vts: vtsHealth,
      strategyWeights: strategyWeightsData,
      exposureBias: {
        strategies: exposureBiasData,
        warnings: exposureBiasWarnings,
        total: Object.values(exposureBiasData).reduce((sum, b) => sum + b.allocPercent, 0).toFixed(1)
      },
      strategyDrift: {
        strategies: strategyDriftData,
        driftingStrategies,
        driftingCount: driftingStrategies.length
      },
      marketRegime: marketRegimeData,
      marketForecast: await getMarketForecastHealth(),
      reinforcementEngine: await getReinforcementEngineHealth(),
      maco: getMACOHealth(),
      decisionConfidence: getDCEHealth(),
      apr_sle: getAPRSLEHealth(),
      equityProtection: getEquityProtectionHealth(),
      issues: status.issues,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('[L9][API] Error fetching system health:', error.message);
    res.status(500).json({ ok: false, error: error.message });
  }
});

async function getMarketForecastHealth() {
  try {
    const pa = getProactiveAllocator();
    const rpt = getRegimePerformanceTracker();
    const prediction = pa.getPrediction();
    const topPerformer = rpt.getTopPerformer();
    
    if (!prediction) {
      return {
        current: 'R1',
        predicted_next: 'R1',
        confidence: 0.5,
        top_performer: null,
        forecast_horizon: '15m',
        transition_matrix: {},
        rpt_active: rpt.isRunningStatus(),
        pa_active: pa.isRunningStatus()
      };
    }
    
    const transitionMatrix: Record<string, number> = {};
    if (prediction.probabilities) {
      for (const [regime, prob] of Object.entries(prediction.probabilities)) {
        if (prob > 0.05) {
          transitionMatrix[`${prediction.current}→${regime}`] = prob;
        }
      }
    }
    
    return {
      current: prediction.current,
      predicted_next: prediction.predicted_next,
      confidence: prediction.confidence,
      top_performer: topPerformer?.regime || null,
      forecast_horizon: '15m',
      transition_matrix: transitionMatrix,
      rpt_active: rpt.isRunningStatus(),
      pa_active: pa.isRunningStatus()
    };
  } catch (e) {
    console.log('[L13][HEALTH] Failed to get market forecast');
    return {
      current: 'R1',
      predicted_next: 'R1',
      confidence: 0.5,
      top_performer: null,
      forecast_horizon: '15m',
      transition_matrix: {},
      error: 'Forecast unavailable'
    };
  }
}

async function getReinforcementEngineHealth() {
  try {
    const rewardEvaluator = getRewardEvaluator();
    const experienceBuffer = getExperienceBuffer();
    const actionExecutor = getActionExecutor();

    const policyState = actionExecutor.getPolicyState();
    const reStatus = rewardEvaluator.getStatus() as {
      isRunning: boolean;
      totalReward: number;
      averageReward: number;
    };
    const ebStatus = experienceBuffer.getStatus() as {
      isRunning: boolean;
      bufferSize: number;
    };

    return {
      status: reStatus.isRunning ? 'ACTIVE' : 'INACTIVE',
      reward_total: reStatus.totalReward,
      policy_confidence: policyState.confidence,
      dominant_strategy: policyState.dominantStrategy,
      last_update: policyState.lastUpdate,
      experience_buffer_size: ebStatus.bufferSize,
      source: policyState.source
    };
  } catch (e) {
    console.log('[L14][HEALTH] Failed to get reinforcement engine status');
    return {
      status: 'UNKNOWN',
      reward_total: 0,
      policy_confidence: 0.5,
      dominant_strategy: 'breakout',
      last_update: null,
      error: 'RL engine unavailable'
    };
  }
}

function getMACOHealth() {
  try {
    const coordinator = getMACOCoordinator();
    const exploration = getExplorationManager();
    const consensus = getPolicyConsensusEngine();

    const coordStatus = coordinator.getStatus();
    const exploreStatus = exploration.getStatus();
    const consensusStatus = consensus.getStatus();

    return {
      status: coordStatus.isRunning ? 'ACTIVE' : 'INACTIVE',
      agents_active: coordStatus.agentCount,
      global_reward: coordStatus.globalReward,
      mean_variance: coordStatus.meanVariance,
      exploration_rate: exploreStatus.epsilon,
      consensus_score: consensusStatus.consensusScore,
      last_sync: coordStatus.lastSync,
      coordinator_running: coordStatus.isRunning,
      exploration_running: exploreStatus.isRunning,
      consensus_running: consensusStatus.isRunning,
      liquidity_trap_agent: coordStatus.agentCount >= 9 ? 'ACTIVE' : 'INACTIVE'
    };
  } catch (e) {
    console.log('[L15][HEALTH] Failed to get MACO status');
    return {
      status: 'UNKNOWN',
      agents_active: 0,
      global_reward: 0,
      mean_variance: 0,
      exploration_rate: 0.15,
      consensus_score: 0.5,
      error: 'MACO unavailable'
    };
  }
}

function getDCEHealth() {
  try {
    const dce = getDecisionConfidenceEngine();
    const status = dce.getStatus();
    const topSignal = dce.getTopSignal();

    return {
      mean_index: status.meanDI,
      weight_profile: [
        status.weights.cwqi,
        status.weights.ngc,
        status.weights.mlConfidence,
        status.weights.regimeConfidence,
        status.weights.macoConsensus
      ],
      top_signal: topSignal ? `${topSignal.symbol}_${topSignal.strategy}` : null,
      liquidity_trap_agent: status.isRunning ? 'ACTIVE' : 'INACTIVE',
      recalibration_count: status.recalibrationCount,
      last_recalibration: status.lastRecalibration,
      is_running: status.isRunning
    };
  } catch (e) {
    console.log('[L16][HEALTH] Failed to get DCE status');
    return {
      mean_index: 0,
      weight_profile: [0.25, 0.20, 0.20, 0.15, 0.20],
      top_signal: null,
      liquidity_trap_agent: 'UNKNOWN',
      error: 'DCE unavailable'
    };
  }
}

function getAPRSLEHealth() {
  try {
    const engine = getAPRSLEEngine();
    const status = engine.getStatus();

    return {
      status: status.isRunning ? 'active' : 'inactive',
      mean_DI: status.meanDI,
      avg_tp_adj: `${status.avgTPAdjPct >= 0 ? '+' : ''}${status.avgTPAdjPct.toFixed(1)}%`,
      avg_sl_adj: `${status.avgSLAdjPct >= 0 ? '+' : ''}${status.avgSLAdjPct.toFixed(1)}%`,
      vol_comp: status.volCompensation,
      current_regime: status.currentRegime,
      di_slope: status.avgDISlope,
      last_recalibration: status.lastRecalibration,
      sample_count: status.sampleCount
    };
  } catch (e) {
    console.log('[L17][HEALTH] Failed to get APR-SLE status');
    return {
      status: 'unknown',
      mean_DI: 0.5,
      avg_tp_adj: '+0.0%',
      avg_sl_adj: '+0.0%',
      vol_comp: 1.0,
      error: 'APR-SLE unavailable'
    };
  }
}

function getEquityProtectionHealth() {
  try {
    const pdc = getPDCEngine();
    const ecs = getECSController();
    
    const pdcStatus = pdc.getStatus();
    const ecsStatus = ecs.getStatus();

    return {
      drawdownRiskScore: pdcStatus.metrics.drawdownRiskScore,
      equitySlope: pdcStatus.metrics.equitySlope,
      volRatio: pdcStatus.metrics.volRatio,
      DI_drift: pdcStatus.metrics.diDrift,
      containmentActive: pdcStatus.metrics.containmentActive,
      exposureMultiplier: ecsStatus.currentOutput.exposureMultiplier,
      lastRecalibration: pdcStatus.lastRecalibration
    };
  } catch (e) {
    console.log('[L18][HEALTH] Failed to get Equity Protection status');
    return {
      drawdownRiskScore: 0,
      equitySlope: 0,
      volRatio: 1.0,
      DI_drift: 0,
      containmentActive: false,
      exposureMultiplier: 1.0,
      error: 'Equity Protection unavailable'
    };
  }
}

function getMetaOptimizationHealth() {
  try {
    const mof = getMOFOrchestrator();
    const status = mof.getStatus();

    return {
      currentJ: status.currentJ,
      stabilityIndex: status.stabilityIndex,
      weightEntropy: status.weightEntropy,
      subsystemVariance: status.subsystemVariance,
      metaWeights: status.metaWeights,
      lambdaWeights: status.lambdaWeights,
      evolutionCount: status.evolutionCount,
      lastEvolution: status.lastEvolution,
      kpiCount: status.kpiCount
    };
  } catch (e) {
    console.log('[L19][HEALTH] Failed to get MOF status');
    return {
      currentJ: 0,
      stabilityIndex: 1.0,
      weightEntropy: 1.0,
      subsystemVariance: 0,
      metaWeights: { ara: 1, vts: 1, maco: 1, dce: 1, pdc: 1, ecs: 1 },
      lambdaWeights: { profit: 0.35, drawdown: 0.30, variance: 0.15, stability: 0.20 },
      evolutionCount: 0,
      lastEvolution: null,
      error: 'MOF unavailable'
    };
  }
}
