import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useWebSocket } from "@/hooks/use-websocket";
import { Filter, RefreshCw, TrendingUp, XCircle, CheckCircle2, Info, Clock } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

interface FilterBreakdown {
  failed_min_volume: number;
  failed_spread: number;
  failed_daily_range: number;
  failed_min_price: number;
  failed_stablecoin: number;
  failed_quote_currency: number;
  failed_blacklist: number;
  failed_whitelist: number;
  failed_history: number;
  failed_guardrail_risk: number;
  strategy_none_triggered: number;
}

interface TopCandidate {
  symbol: string;
  strategy?: string;
  confidence?: number;
}

interface FilterInsightsData {
  mode: string;
  universe_count: number;
  evaluated: number;
  eligible_count: number;
  ineligible_count: number;
  breakdown: FilterBreakdown;
  top_candidates: TopCandidate[];
  ts: string;
  nextScanAt?: string; // Phase 27.F.19b: Next scheduled scan time
}

interface FilterThresholds {
  minVolume?: string;
  minPrice?: string;
  maxPrice?: string;
  minMarketCap?: string;
  maxBidAskSpread?: string;
  rsiMin?: number;
  rsiMax?: number;
  volatilityMin?: string;
  volatilityMax?: string;
  minLiquidity?: string;
  excludeStablecoins?: boolean;
  allowRegulatedOnly?: boolean;
  minDailyRange?: string;
  allowedTradingPairs?: string[];
  minDataHistoryDays?: number;
}

interface FilterDiagnosticsResponse {
  pairsScanned: number;
  eligiblePairs: number;
  topFailureReason: string;
  failurePercent: number;
  timestamp?: string;
  thresholds?: FilterThresholds | null;
}

interface ScanMetricsResponse {
  scanCycleId: string;
  nextCycleAt: string;
  nextCycleInSec: number;
  lastBatch: {
    evaluated: number;
    eligible: number;
    ineligible: number;
    latencyMs: number;
  };
}

export function FilterInsights() {
  // WebSocket subscription for unified scan_tick events (~30s rotational scanner)
  const { messages: wsMessages } = useWebSocket();
  const [currentTime, setCurrentTime] = useState<number>(Date.now()); // Ticking state for countdown
  
  // Stage 2 Follow-Up: Track scan_tick data as single source of truth
  const [scanTickData, setScanTickData] = useState<{
    eligible: number;
    ineligible: number;
    evaluated: number;
    scanCycleId: string;
    timestamp: number;
  } | null>(null);

  // Query scan metrics from unified rotational scanner (~30s intervals)
  const { data: scanMetrics, isLoading: isLoadingMetrics } = useQuery<ScanMetricsResponse>({
    queryKey: ['/api/scan/metrics?mode=paper'],
    staleTime: 30 * 1000, // 30 seconds - matches unified scanner intervals
    refetchInterval: 30 * 1000, // Auto-refresh every 30 seconds
  });

  // Query filter insights from unified scanner (SECONDARY - for breakdown details only)
  // Stage 2 Follow-Up: This is NO LONGER the source of truth for eligible count
  const { data, isLoading, refetch, isFetching } = useQuery<FilterInsightsData>({
    queryKey: ['/api/paper-sim/diagnostics/scan?mode=paper&limit=9999&trace=false&strategies=all'],
    staleTime: 30 * 1000, // 30 seconds - matches unified scanner intervals
    refetchInterval: 30 * 1000, // Auto-refresh every 30 seconds
  });

  // Log when query data changes (for diagnostics only)
  useEffect(() => {
    if (data) {
      console.log(`[Stage-2][UI][FilterInsights] Diagnostic scan completed (SECONDARY):`, {
        eligible: data.eligible_count,
        ineligible: data.ineligible_count,
        timestamp: data.ts
      });
    }
  }, [data]);

  // Query for threshold values
  const { data: diagnosticsData } = useQuery<FilterDiagnosticsResponse>({
    queryKey: ['/api/filters/diagnostics'],
    staleTime: 30 * 1000, // 30 seconds - matches unified scanner intervals
    refetchInterval: 30 * 1000, // Auto-refresh every 30 seconds
  });

  // Stage 2 Follow-Up: Listen for scan_tick events and extract eligible count (single source of truth)
  // Accept both 'paper' and 'learning' modes (learning = passive observation when trading is inactive)
  useEffect(() => {
    const scanTickEvents = wsMessages.filter((msg: any) => 
      msg.type === 'scan_tick' && (msg.payload?.mode === 'paper' || msg.payload?.mode === 'learning')
    );
    if (scanTickEvents.length > 0) {
      const receiptTimestamp = Date.now();
      const latestEvent = scanTickEvents[scanTickEvents.length - 1];
      const payload = latestEvent.payload;
      
      console.log(`[Stage-2][UI] scan_tick received at ${receiptTimestamp}`, payload);
      console.log(`[Stage-2][EligiblePairs] source=websocket_scan_tick, count=${payload.eligible}, scanCycleId=${payload.scanCycleId}, mode=${payload.mode}`);
      
      // Update local state with scan_tick data (single source of truth)
      setScanTickData({
        eligible: payload.eligible,
        ineligible: payload.ineligible,
        evaluated: payload.evaluated,
        scanCycleId: payload.scanCycleId,
        timestamp: Date.now()
      });
      
      console.log('[FilterInsights] Received unified scan_tick, refreshing all data...');
      // Invalidate all queries on any scan_tick event
      queryClient.invalidateQueries({ queryKey: ['/api/scan/metrics?mode=paper'] });
      queryClient.invalidateQueries({ queryKey: ['/api/paper-sim/diagnostics/scan?mode=paper&limit=9999&trace=false&strategies=all'] });
      queryClient.invalidateQueries({ queryKey: ['/api/filters/diagnostics'] });
      console.log(`[Stage-2][UI] Queries invalidated at ${Date.now()}, Δt=${Date.now() - receiptTimestamp}ms`);
    }
  }, [wsMessages]);

  // Tick currentTime every second for live countdown
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(Date.now());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Phase 27.F.15.B: Helper to get threshold value for a filter
  const getThreshold = (filterKey: string): string | null => {
    if (!diagnosticsData?.thresholds) return null;
    
    const thresholds = diagnosticsData.thresholds;
    
    // Filters not currently implemented (require expensive operations or unavailable data)
    const notImplemented = ['failed_rsi', 'failed_liquidity', 'failed_market_cap', 'failed_regulated'];
    if (notImplemented.includes(filterKey)) {
      return 'Not Available';
    }
    
    const map: Record<string, string> = {
      'failed_min_volume': thresholds.minVolume ? `≥ $${parseFloat(thresholds.minVolume).toLocaleString()}` : '',
      'failed_min_price': thresholds.minPrice ? `≥ $${parseFloat(thresholds.minPrice)}` : '',
      'failed_max_price': thresholds.maxPrice ? `≤ $${parseFloat(thresholds.maxPrice).toLocaleString()}` : '',
      'failed_spread': thresholds.maxBidAskSpread ? `≤ ${parseFloat(thresholds.maxBidAskSpread)}%` : '',
      'failed_daily_range': thresholds.minDailyRange ? `≥ ${parseFloat(thresholds.minDailyRange)}%` : '',
      'failed_volatility': thresholds.volatilityMin && thresholds.volatilityMax ? `${parseFloat(thresholds.volatilityMin)}-${parseFloat(thresholds.volatilityMax)}%` : '',
      'failed_stablecoin': thresholds.excludeStablecoins ? 'Excluded' : 'Allowed',
      'failed_quote_currency': thresholds.allowedTradingPairs ? thresholds.allowedTradingPairs.join(', ') : '',
      'failed_history': thresholds.minDataHistoryDays ? `≥ ${thresholds.minDataHistoryDays} days` : '',
    };
    
    return map[filterKey] || null;
  };

  // Calculate countdown using unified scanner metadata (nextCycleAt from scan metrics)
  const nextCycleTime = scanMetrics?.nextCycleAt ? new Date(scanMetrics.nextCycleAt).getTime() : null;
  const timeUntilNextCycle = nextCycleTime ? Math.max(0, nextCycleTime - currentTime) : 0;
  const secondsUntilNextCycle = Math.floor(timeUntilNextCycle / 1000);
  
  // Format countdown display (~30s unified scanner)
  const countdownDisplay = secondsUntilNextCycle > 0 ? `${secondsUntilNextCycle}s` : '0s';

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Card data-testid="filter-insights-loading">
          <CardHeader>
            <Skeleton className="h-8 w-64" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-32 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="space-y-4">
        <Card data-testid="filter-insights-empty">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filter Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">No filter insights available</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Stage 2 Follow-Up: Use scan_tick data as single source of truth for eligible count
  const eligibleCount = scanTickData?.eligible ?? data?.eligible_count ?? 0;
  const ineligibleCount = scanTickData?.ineligible ?? data?.ineligible_count ?? 0;
  const evaluatedCount = scanTickData?.evaluated ?? data?.evaluated ?? 0;
  
  const eligiblePercent = evaluatedCount > 0 
    ? ((eligibleCount / evaluatedCount) * 100).toFixed(1)
    : '0.0';

  // Get ALL breakdown entries sorted by count (Phase 27.F.15.A: Show all 11 categories)
  const allBreakdownEntries = Object.entries(data.breakdown)
    .sort((a, b) => b[1] - a[1]);

  const formatFailureReason = (key: string): string => {
    return key
      .replace('failed_', '')
      .replace('strategy_none_triggered', 'No Strategy Triggered')
      .replace(/_/g, ' ')
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  return (
    <div className="space-y-4" data-testid="filter-insights">
      {/* Unified Scanner Status Block - Real-time cycle tracking (~30s intervals) */}
      <Card className="border-primary/20">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-primary" />
              <div>
                <CardTitle className="text-sm font-medium">
                  Unified Scanner Status
                </CardTitle>
                {scanMetrics && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Cycle: {scanMetrics.scanCycleId}
                  </p>
                )}
              </div>
            </div>
            <div className="flex items-center gap-3">
              {scanMetrics?.lastBatch && (
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">Last Batch</p>
                  <p className="text-sm font-medium">
                    {scanMetrics.lastBatch.eligible}/{scanMetrics.lastBatch.evaluated} eligible
                    <span className="text-xs text-muted-foreground ml-2">
                      ({scanMetrics.lastBatch.latencyMs}ms)
                    </span>
                  </p>
                </div>
              )}
              <div className="text-right">
                <p className="text-xs text-muted-foreground">Next Scan</p>
                <p className="text-sm font-medium">{countdownDisplay}</p>
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Unified Scanner Insights - Detailed filter breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Universe Overview
          </CardTitle>
          {data?.ts && (
            <p className="text-xs text-muted-foreground mt-1">
              Last scan: {new Date(data.ts).toLocaleString()}
            </p>
          )}
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-xs text-muted-foreground mb-1">Total Universe</p>
              <p className="text-2xl font-bold" data-testid="text-universe-count">
                {data.universe_count.toLocaleString()}
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Evaluated</p>
              <p className="text-2xl font-bold" data-testid="text-evaluated-count">
                {evaluatedCount.toLocaleString()}
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Eligible</p>
              <div className="flex items-baseline gap-2">
                <p className="text-2xl font-bold text-success" data-testid="text-eligible-count">
                  {eligibleCount}
                </p>
                <Badge variant="default" className="bg-success/10 text-success">
                  {eligiblePercent}%
                </Badge>
              </div>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Ineligible</p>
              <p className="text-2xl font-bold text-muted-foreground" data-testid="text-ineligible-count">
                {ineligibleCount}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filter Breakdown - Phase 27.F.15.A: Show all 11 categories */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filter Breakdown</CardTitle>
          <p className="text-xs text-muted-foreground mt-1">
            All {allBreakdownEntries.length} filter categories from last scan (sorted by rejection count)
          </p>
        </CardHeader>
        <CardContent>
          {allBreakdownEntries.length === 0 ? (
            <p className="text-sm text-muted-foreground">No filter data available</p>
          ) : (
            <div className="space-y-2">
              {allBreakdownEntries.map(([key, count], index) => {
                const isTopFailure = index < 3 && count > 0;
                const threshold = getThreshold(key);
                const isUserAdjustable = !['failed_blacklist', 'failed_whitelist', 'failed_quote_currency', 'failed_guardrail_risk', 'strategy_none_triggered'].includes(key);
                
                return (
                  <div 
                    key={key} 
                    className={cn(
                      "flex items-center justify-between p-2 rounded border",
                      isTopFailure ? "border-destructive/20 bg-destructive/5" : "border-border",
                      count === 0 && "opacity-40"
                    )}
                  >
                    <div className="flex items-center gap-2 flex-1">
                      {count > 0 ? (
                        <XCircle className={cn(
                          "w-4 h-4 shrink-0",
                          isTopFailure ? "text-destructive" : "text-warning"
                        )} />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 shrink-0 text-success" />
                      )}
                      <div className="flex flex-col gap-0.5 flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className={cn(
                            "text-sm",
                            isTopFailure && count > 0 ? "font-medium" : "font-normal"
                          )}>
                            {formatFailureReason(key)}
                          </span>
                          {isUserAdjustable && (
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger>
                                  <Info className="w-3 h-3 text-muted-foreground" />
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p className="text-xs">User-adjustable in Filters tab</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          )}
                        </div>
                        {threshold && (
                          <span className="text-xs text-muted-foreground">
                            Threshold: {threshold}
                          </span>
                        )}
                      </div>
                    </div>
                    <Badge 
                      variant={count > 0 ? (isTopFailure ? "destructive" : "secondary") : "outline"}
                      data-testid={`badge-filter-${key}`}
                      className={cn(
                        "shrink-0",
                        count === 0 && "text-success border-success/20"
                      )}
                    >
                      {count > 0 ? count.toLocaleString() : "✓ Pass"}
                    </Badge>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Top Candidates */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Top 10 Candidates
          </CardTitle>
        </CardHeader>
        <CardContent>
          {data.top_candidates.length === 0 ? (
            <p className="text-sm text-muted-foreground">No eligible pairs found</p>
          ) : (
            <div className="space-y-2">
              {data.top_candidates.slice(0, 10).map((candidate, idx) => (
                <div
                  key={candidate.symbol}
                  className="flex items-center justify-between p-2 rounded border border-border hover:bg-accent/50 transition-colors"
                  data-testid={`candidate-${candidate.symbol}`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-muted-foreground font-mono w-6">
                      #{idx + 1}
                    </span>
                    <span className="font-medium">{candidate.symbol}</span>
                    {candidate.strategy && (
                      <Badge variant="outline" className="text-xs">
                        {candidate.strategy}
                      </Badge>
                    )}
                  </div>
                  {candidate.confidence !== undefined && (
                    <Badge variant="default" className="bg-success/10 text-success">
                      {(candidate.confidence * 100).toFixed(0)}%
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Last Updated */}
      <div className="text-center text-xs text-muted-foreground">
        Last updated: {new Date(data.ts).toLocaleString()}
      </div>
    </div>
  );
}
