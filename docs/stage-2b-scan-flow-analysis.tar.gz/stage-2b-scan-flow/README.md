# Stage 2B Scan Flow Analysis Package

This package contains all relevant files for analyzing the Market Scanner → Filter Insights → Filtered Pairs data flow.

## Package Contents

### Backend (Data Creation + Broadcast)
1. ✅ `backend/market-scanner.ts` - Core market scanner service that generates scan_tick events
2. ✅ `backend/trading-state-sync.ts` - Handles trading state synchronization
3. ✅ `backend/cycle-cache.ts` - Manages scan cycle caching
4. ✅ `backend/routes.ts` - API route definitions
5. ✅ `backend/context-bridge.ts` - WebSocket broadcast layer

### Frontend (Data Reception + State Management)
6. ✅ `frontend/hooks/use-websocket.tsx` - WebSocket connection hook
7. ❌ `frontend/hooks/use-scan-tick-data.tsx` - **DOES NOT EXIST** (scan_tick logic embedded in components)
8. ✅ `frontend/hooks/use-trading.tsx` - Trading state management hook
9. ✅ `frontend/lib/queryClient.ts` - React Query client configuration

### Frontend (UI Components)
10. ✅ `frontend/components/filter-insights.tsx` - Filter Insights component (Active Trades → Insights tab)
11. ✅ `frontend/components/active-trades.tsx` - Contains `FilteredPairsTab` component (not separate file)
12. ✅ `frontend/components/ready-to-buy-table.tsx` - Ready to Buy table component
13. ❌ `frontend/components/unified-scanner-status.tsx` - **DOES NOT EXIST**

### Optional Files
14. ❌ `frontend/context/ScanContext.tsx` - **DOES NOT EXIST**
15. ❌ `frontend/context/ScanProvider.tsx` - **DOES NOT EXIST**
16. ❌ `frontend/services/api.ts` - **DOES NOT EXIST**

## Key Findings

### Current Architecture
- **No dedicated scan_tick data hook**: Logic is embedded directly in Filter Insights and FilteredPairsTab components
- **Filtered Pairs is inline**: The FilteredPairsTab component exists within active-trades.tsx, not as a separate file
- **No unified scanner status component**: Scanner status/countdown logic may be distributed across components
- **No centralized scan context**: Each component manages its own scan_tick subscription

### Implementation Notes (Stage 2 - Nov 2025)
1. **Backend broadcasts**: Market Scanner emits `scan_tick` events every ~30s with:
   - `eligible` (count)
   - `eligibleSymbols[]` (array of symbols)
   - `scanCycleId` (unique cycle ID)
   - `mode` ('paper' or 'learning')
   - `evaluated` (total evaluated)
   - `ineligible` (excluded count)

2. **Frontend subscriptions**:
   - Filter Insights: Subscribes to scan_tick, accepts both 'paper' and 'learning' modes
   - FilteredPairsTab: Subscribes to scan_tick, accepts both 'paper' and 'learning' modes
   - Both invalidate React Query cache on event receipt

3. **Known Issues**:
   - Filter Insights only renders on Active Trades → "insights" tab (admin/owner only)
   - Components won't receive events until user navigates to Active Trades page
   - No shared state between components - each maintains independent subscription

## Next Steps for GPT-5 Analysis

This package enables complete analysis of:
1. ✅ Data creation (market-scanner.ts)
2. ✅ WebSocket broadcast layer (context-bridge.ts)
3. ✅ Frontend subscription pattern (components directly subscribing)
4. ✅ Cache invalidation logic (React Query in components)
5. ❌ Unified state management (doesn't exist - opportunity for improvement)

## Recommendations for Stage 2C

Consider creating:
- `use-scan-tick-data.tsx` - Shared hook for scan_tick subscription
- `ScanProvider.tsx` - Context provider for scan state
- Unified scanner status component for consistent countdown/status display
- Dedicated filtered-pairs component extraction from active-trades.tsx

---

**Package Created**: November 12, 2025  
**Analysis Target**: Stage 2C - Full Market Scanner Synchronization
