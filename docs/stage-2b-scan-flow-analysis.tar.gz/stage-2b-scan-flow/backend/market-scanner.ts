import { KrakenService } from './kraken';
import { StrategyEngine } from './strategy-engine';
import { storage } from '../storage';
import { WatchlistPair } from '@shared/schema';
import { strategyAlerts } from './strategy-alerts';
import { cycleCache } from './cycle-cache';
import { buildSettingsFromModeLevel } from './risk-manager';
import { getPaperSimulationStatus } from './paper-sim-service';
import type { TradingEngine } from './trading-engine';

// Unified rotational scanner configuration
const SCAN_INTERVAL_MS = 30 * 1000; // 30 seconds (configurable 20-45s)
const BATCH_SIZE = 60; // Total pairs per batch (mix of Top-N and Tier-B)

export class MarketScanner {
  private kraken: KrakenService;
  private strategyEngine: StrategyEngine;
  private isScanning: Map<string, boolean> = new Map(); // Per-mode mutex
  private scanTimer: NodeJS.Timeout | null = null;
  private cachedTickerSnapshot: { data: any; timestamp: number } | null = null;
  private readonly TICKER_CACHE_TTL_MS = 20 * 1000; // 20 seconds
  
  // Rotational state tracking
  private tierBRotationIndex: Map<string, number> = new Map(); // Tracks Tier-B position per mode
  
  // Performance optimization: Cache filtered pairs result per mode
  private cachedFilteredPairs: Map<string, { data: any[]; timestamp: number; settingsHash: string }> = new Map();
  private readonly FILTERED_PAIRS_CACHE_TTL_MS = 30 * 1000; // 30 seconds
  
  // Trading engines for mode detection
  private paperEngine: TradingEngine | null = null;
  private liveEngine: TradingEngine | null = null;

  constructor(paperEngine?: TradingEngine, liveEngine?: TradingEngine) {
    this.kraken = new KrakenService();
    this.strategyEngine = new StrategyEngine();
    this.isScanning.set('paper', false);
    this.isScanning.set('live', false);
    this.isScanning.set('learning', false);
    this.tierBRotationIndex.set('paper', 0);
    this.tierBRotationIndex.set('live', 0);
    this.tierBRotationIndex.set('learning', 0);
    
    this.paperEngine = paperEngine || null;
    this.liveEngine = liveEngine || null;
  }

  /**
   * Detect the active trading mode
   * Returns 'live' if live engine is running, 'paper' if paper engine is running,
   * or 'learning' if both are off (passive learning mode)
   * 
   * MODE PRIORITY: Live mode takes precedence over paper mode
   * SAFETY: Throws error if both engines are running (invalid state)
   */
  private detectActiveMode(): 'paper' | 'live' | 'learning' {
    const paperRunning = this.paperEngine?.isEngineRunning?.() || false;
    const liveRunning = this.liveEngine?.isEngineRunning?.() || false;
    
    const timestamp = new Date().toISOString();
    console.log(`[LIFECYCLE][${timestamp}] MarketScanner.detectActiveMode() - paperRunning=${paperRunning}, liveRunning=${liveRunning}`);
    
    // SAFETY: Both engines running is an invalid state
    if (paperRunning && liveRunning) {
      const error = new Error('[MarketScanner] CRITICAL: Both paper and live engines are running simultaneously! Only one mode should be active.');
      console.error(error.message);
      throw error;
    }
    
    // PRIORITY: Live mode takes precedence (real trading must not be starved of data)
    if (liveRunning) {
      console.log(`[LIFECYCLE][${timestamp}] MarketScanner switching to LIVE mode`);
      return 'live';
    }
    if (paperRunning) {
      console.log(`[LIFECYCLE][${timestamp}] MarketScanner switching to PAPER mode`);
      console.log(`[MarketScanner] 🧠 Passive learning loop cleared (switching to Paper mode)`);
      return 'paper';
    }
    console.log(`[LIFECYCLE][${timestamp}] MarketScanner in LEARNING mode (passive observation)`);
    return 'learning'; // Passive learning mode - observe market without trading
  }

  /**
   * Unified rotational scanner start method
   * Runs continuous 30-45s cycles mixing Top-N and Tier-B pairs
   * MODE ISOLATION: Only scans the active mode (paper/live/learning)
   */
  async start(): Promise<void> {
    try {
      const activeMode = this.detectActiveMode();
      console.log('[MarketScanner] ▶ Starting unified rotational scanning...');
      console.log(`  Active Mode: ${activeMode.toUpperCase()}`);
      console.log(`  Scan Interval: ${SCAN_INTERVAL_MS / 1000}s`);
      console.log(`  Batch Size: ${BATCH_SIZE} pairs (mixed Top-N + Tier-B)`);
      
      if (activeMode === 'learning') {
        console.log('[MarketScanner] 🧠 PASSIVE LEARNING MODE - Observing market without trading');
      }
      
      // Run initial cycle for active mode only (with 25s timeout)
      console.log(`[MarketScanner] Running initial ${activeMode} cycle (with 25s timeout)...`);
      
      try {
        await Promise.race([
          this.runUnifiedCycle(activeMode),
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`${activeMode} mode startup timeout after 25s`)), 25000)
          )
        ]);
        console.log(`[MarketScanner] ${activeMode} mode initial cycle completed successfully`);
      } catch (err: any) {
        console.warn(`[MarketScanner] ⚠️ ${activeMode} mode initial cycle failed/timed out:`, err?.message);
      }
      
      console.log('[MarketScanner] Initial cycle complete (or timed out), continuing with timer initialization...');
      
      // Initialize recurring timer (scan active mode only)
      console.log(`[MarketScanner] Setting up recurring timer for ${activeMode.toUpperCase()} mode...`);
      this.scanTimer = setInterval(async () => {
        const currentMode = this.detectActiveMode();
        console.log(`[MarketScanner] ⏰ Unified scan timer fired (mode: ${currentMode})`);
        
        // Only scan the currently active mode
        try {
          await this.runUnifiedCycle(currentMode);
        } catch (err: any) {
          console.warn(`[MarketScanner] ⚠️ ${currentMode} mode cycle failed:`, err?.message);
        }
      }, SCAN_INTERVAL_MS);
      
      console.log('[MarketScanner] ✅ Timer initialized successfully');
    } catch (err: any) {
      console.error('[MarketScanner] ❌ Failed to start:', err?.message);
      console.error('[MarketScanner] Stack trace:', err?.stack);
      // Re-throw to propagate the error to routes.ts catch handler
      throw err;
    }
  }

  /**
   * Stop all scanning timers
   */
  stop(): void {
    const stopTimestamp = new Date().toISOString();
    console.log(`[LIFECYCLE][${stopTimestamp}] MarketScanner.stop() called`);
    
    if (this.scanTimer) {
      clearInterval(this.scanTimer);
      this.scanTimer = null;
      console.log(`[LIFECYCLE][${stopTimestamp}] MarketScanner timer cleared`);
    }
    console.log('[MarketScanner] Scanning stopped');
  }

  /**
   * Unified rotational scanner - mixes Top-N and Tier-B pairs
   * Runs every ~30s to update eligible pairs and broadcast scan_tick
   * 
   * Strategy:
   * - Covers all Top-N pairs within ~1 minute (2-3 cycles)
   * - Covers entire universe (Tier-B) within ~10-15 minutes
   * - Each batch mixes both Top-N and Tier-B pairs
   * 
   * Mode Behavior:
   * - 'paper': Normal scanning for paper trading
   * - 'live': Normal scanning for live trading
   * - 'learning': Passive observation mode - no trades executed
   */
  private async runUnifiedCycle(mode: 'live' | 'paper' | 'learning'): Promise<void> {
    const cycleStartTimestamp = new Date().toISOString();
    console.log(`[LIFECYCLE][${cycleStartTimestamp}] MarketScanner.runUnifiedCycle() started (mode=${mode})`);
    console.log(`[Scan:${mode}] ▶ ENTER runUnifiedCycle()`);
    
    // Mutex: prevent overlapping scans for this mode
    if (this.isScanning.get(mode)) {
      console.log(`[Scan:${mode}] Scan already in progress, skipping...`);
      return;
    }

    this.isScanning.set(mode, true);
    const startTime = Date.now();
    
    // Log passive learning mode
    if (mode === 'learning') {
      console.log(`[Scan:learning] 🧠 Observational pass — no trades executed.`);
    }

    try {
      console.time(`[Scan:${mode}] totalTime`);
      console.log(`\n🔄 [Scan:${mode}] Starting unified rotational scan...`);

      // Step 1: Get mode-level settings
      // Learning mode uses paper settings (since it's passive observation)
      const settingsMode = mode === 'learning' ? 'paper' : mode;
      console.log(`[Scan:${mode}] Step 1: buildSettingsFromModeLevel(${settingsMode})`);
      const settings = await buildSettingsFromModeLevel(settingsMode as 'paper' | 'live');
      const universeProfile = settings?.universeProfile || 'TOP_100';
      const topNSize = this.parseUniverseProfile(universeProfile);
      console.log(`[Scan:${mode}] Universe profile: ${universeProfile} (${topNSize} Top-N pairs)`);

      // Step 2: Get screener filters
      // Learning mode uses paper filters
      console.log(`[Scan:${mode}] Step 2: getScreenerFilters(${settingsMode})`);
      const screenerSettings = await storage.getScreenerFilters({ mode: settingsMode as 'paper' | 'live' });
      console.log(`[Scan:${mode}] Screener filters retrieved OK`, screenerSettings ? '(present)' : '(null)');
      if (!screenerSettings) {
        console.log(`[Scan:${mode}] No screener settings found, skipping`);
        return;
      }

      // Step 3: Collect mixed batch (Top-N + Tier-B rotation)
      console.log(`[Scan:${mode}] Step 3: collectMixedBatch()`);
      const mixedBatch = await this.collectMixedBatch(mode, {
        topNSize,
        batchSize: BATCH_SIZE,
        screenerSettings
      });
      console.log(`[Scan:${mode}] Mixed batch collected: ${mixedBatch.eligible.length} eligible (${mixedBatch.topNCount} Top-N + ${mixedBatch.tierBCount} Tier-B)`);

      // Step 4: Create snapshot
      console.log(`[Scan:${mode}] Step 4: createSnapshot()`);
      const latencyMs = Date.now() - startTime;
      const eligibleSymbols = mixedBatch.eligible.map(p => p.symbol);
      const snapshot = cycleCache.createSnapshot(
        mode,
        mixedBatch.evaluated,
        eligibleSymbols,
        SCAN_INTERVAL_MS,
        latencyMs
      );
      console.log(`[Scan:${mode}] Snapshot created: ${snapshot.scanCycleId}, eligible=${eligibleSymbols.length}/${mixedBatch.evaluated}`);

      // Step 5: Broadcast scan_tick
      console.log(`[Scan:${mode}] Step 5: broadcast scan_tick`);
      await this.broadcastScanTick(mode, snapshot);
      
      if (mode === 'learning') {
        console.log(`[Scan:learning] 📡 scan_tick broadcast sent (${eligibleSymbols.length} pairs)`);
      }

      console.timeEnd(`[Scan:${mode}] totalTime`);
      const cycleEndTimestamp = new Date().toISOString();
      console.log(`[LIFECYCLE][${cycleEndTimestamp}] MarketScanner.runUnifiedCycle() completed (mode=${mode})`);
      console.log(`[Scan:${mode}] ✅ Completed successfully (rotation: ${this.tierBRotationIndex.get(mode)})\n`);

    } catch (error: any) {
      console.error(`[Scan:${mode}] ❌ Error during runUnifiedCycle:`, error?.message);
      console.error(`[Scan:${mode}] Stack trace:`, error?.stack);
    } finally {
      this.isScanning.set(mode, false);
    }
  }

  /**
   * Parse universe profile string to numeric size
   * Examples: 'TOP_25' -> 25, 'TOP_100' -> 100
   * Validates against supported profiles and provides safe fallback
   */
  private parseUniverseProfile(profile: string): number {
    // Supported universe sizes
    const VALID_PROFILES = ['TOP_25', 'TOP_50', 'TOP_100', 'TOP_200', 'TOP_500'];
    const DEFAULT_PROFILE = 'TOP_100';
    const DEFAULT_SIZE = 100;

    // Guard against null/undefined/empty
    if (!profile || typeof profile !== 'string') {
      console.warn(`[MarketScanner] Invalid universe profile (${typeof profile}), defaulting to ${DEFAULT_SIZE}`);
      return DEFAULT_SIZE;
    }

    // Trim and uppercase for normalization
    const normalized = profile.trim().toUpperCase();

    // Validate against supported profiles
    if (!VALID_PROFILES.includes(normalized)) {
      console.warn(`[MarketScanner] Unsupported universe profile "${profile}", defaulting to ${DEFAULT_PROFILE}. Supported: ${VALID_PROFILES.join(', ')}`);
      return DEFAULT_SIZE;
    }

    // Parse numeric value
    const match = normalized.match(/^TOP_(\d+)$/);
    if (match) {
      const size = parseInt(match[1], 10);
      if (size > 0 && size <= 10000) {
        return size;
      }
      console.warn(`[MarketScanner] Universe size ${size} out of range [1-10000], defaulting to ${DEFAULT_SIZE}`);
      return DEFAULT_SIZE;
    }

    // Fallback (should never reach here due to VALID_PROFILES check)
    console.warn(`[MarketScanner] Failed to parse universe profile "${profile}", defaulting to ${DEFAULT_SIZE}`);
    return DEFAULT_SIZE;
  }

  /**
   * Collect mixed batch of Top-N + Tier-B pairs with rotation
   * 
   * Strategy:
   * - Top-N pairs: Always include all from universeSize (e.g., TOP_100)
   * - Tier-B pairs: Rotate through broader universe to cover all pairs over time
   * - Mix: Combine and dedupe, then apply filters
   * 
   * Rotation ensures:
   * - All Top-N pairs covered every ~1 minute (2-3 cycles)
   * - Entire universe (Tier-B) covered over ~10-15 minutes
   */
  private async collectMixedBatch(
    mode: 'live' | 'paper',
    options: {
      topNSize: number;
      batchSize: number;
      screenerSettings: any;
    }
  ): Promise<{
    eligible: any[];
    evaluated: number;
    topNCount: number;
    tierBCount: number;
  }> {
    const { topNSize, batchSize, screenerSettings } = options;
    
    // Create hash of screener settings for cache validation
    const settingsHash = JSON.stringify({
      minVolume: screenerSettings.minVolume || '0',
      minPrice: screenerSettings.minPrice,
      maxPrice: screenerSettings.maxPrice,
      maxBidAskSpread: screenerSettings.maxBidAskSpread,
      excludeStablecoins: screenerSettings.excludeStablecoins ?? true,
      rsiMin: screenerSettings.rsiMin,
      rsiMax: screenerSettings.rsiMax,
      volatilityMin: screenerSettings.volatilityMin,
      volatilityMax: screenerSettings.volatilityMax,
      minLiquidity: screenerSettings.minLiquidity,
      minMarketCap: screenerSettings.minMarketCap,
      allowRegulatedOnly: screenerSettings.allowRegulatedOnly ?? false,
      quoteCurrencies: screenerSettings.quoteCurrencies,
      activeTimeframes: screenerSettings.activeTimeframes
    });
    
    // Check cache for fresh filtered pairs
    const cachedEntry = this.cachedFilteredPairs.get(mode);
    const now = Date.now();
    let allFilteredPairs: any[];
    
    if (cachedEntry && 
        cachedEntry.settingsHash === settingsHash && 
        (now - cachedEntry.timestamp) < this.FILTERED_PAIRS_CACHE_TTL_MS) {
      console.log(`[Scan:${mode}] ⚡ Using cached filtered pairs (${cachedEntry.data.length} pairs, age: ${Math.floor((now - cachedEntry.timestamp) / 1000)}s)`);
      allFilteredPairs = cachedEntry.data;
    } else {
      // Cache miss or stale - fetch fresh data from Kraken
      console.log(`[Scan:${mode}] 🔍 Fetching fresh filtered pairs from Kraken...`);
      allFilteredPairs = await this.kraken.getEligiblePairs({
        minVolume: screenerSettings.minVolume || '0',
        minDailyRange: '0',
        minPrice: screenerSettings.minPrice || undefined,
        maxPrice: screenerSettings.maxPrice || undefined,
        maxBidAskSpread: screenerSettings.maxBidAskSpread || undefined,
        excludeStablecoins: screenerSettings.excludeStablecoins ?? true,
        allowedTradingPairs: [],
        blacklistedSymbols: [],
        whitelistedSymbols: [],
        minHistoryDays: undefined,
        rsiMin: screenerSettings.rsiMin || undefined,
        rsiMax: screenerSettings.rsiMax || undefined,
        volatilityMin: screenerSettings.volatilityMin || undefined,
        volatilityMax: screenerSettings.volatilityMax || undefined,
        minLiquidity: screenerSettings.minLiquidity || undefined,
        minMarketCap: screenerSettings.minMarketCap || undefined,
        allowRegulatedOnly: screenerSettings.allowRegulatedOnly ?? false,
        universeSize: undefined, // Get all pairs for rotation
        quoteCurrencies: screenerSettings.quoteCurrencies as string[] || undefined,
        activeTimeframes: screenerSettings.activeTimeframes as string[] || undefined
      });
      
      // Cache the result
      this.cachedFilteredPairs.set(mode, {
        data: allFilteredPairs,
        timestamp: now,
        settingsHash
      });
      console.log(`[Scan:${mode}] 💾 Cached ${allFilteredPairs.length} filtered pairs`);
    }

    // Split into Top-N and Tier-B
    // Cap Top-N to 60% of batch to ensure Tier-B gets space (40% reserved for rotation)
    const maxTopNInBatch = Math.floor(batchSize * 0.6);
    const topNPairs = allFilteredPairs.slice(0, Math.min(topNSize, maxTopNInBatch));
    const tierBPairs = allFilteredPairs.slice(topNSize);
    
    // Determine Tier-B slice size for this batch (remaining capacity)
    const tierBSliceSize = Math.max(0, batchSize - topNPairs.length);
    
    // Get rotational index for this mode
    let rotationIndex = this.tierBRotationIndex.get(mode) || 0;
    
    // Extract Tier-B slice (wrap around if needed)
    const tierBSlice: any[] = [];
    if (tierBPairs.length > 0 && tierBSliceSize > 0) {
      for (let i = 0; i < tierBSliceSize; i++) {
        const index = (rotationIndex + i) % tierBPairs.length;
        tierBSlice.push(tierBPairs[index]);
      }
      
      // Update rotation index for next cycle
      rotationIndex = (rotationIndex + tierBSliceSize) % tierBPairs.length;
      this.tierBRotationIndex.set(mode, rotationIndex);
    }
    
    // Combine and dedupe
    const mixedBatch = [...topNPairs, ...tierBSlice];
    const deduped = Array.from(new Map(mixedBatch.map(p => [p.symbol, p])).values());
    
    console.log(`[Scan:${mode}] Batch composition: ${topNPairs.length} Top-N + ${tierBSlice.length} Tier-B = ${deduped.length} total`);
    console.log(`[Scan:${mode}] Rotation: Tier-B index ${rotationIndex}/${tierBPairs.length} (${Math.floor((rotationIndex / tierBPairs.length) * 100)}% coverage)`);
    
    return {
      eligible: deduped,
      evaluated: deduped.length,
      topNCount: topNPairs.length,
      tierBCount: tierBSlice.length
    };
  }

  /**
   * Broadcast unified scan_tick WebSocket event
   */
  private async broadcastScanTick(mode: 'live' | 'paper', snapshot: any): Promise<void> {
    try {
      const broadcastTimestamp = Date.now();
      const { contextBridge } = await import('./context-bridge.js');
      
      console.log(`[Stage-2][SCAN] Broadcasting scan_tick at ${broadcastTimestamp}:`, {
        mode,
        scanCycleId: snapshot.scanCycleId,
        eligible: snapshot.eligibleSymbols.length,
        ineligible: snapshot.ineligibleCount,
        evaluated: snapshot.evaluatedCount
      });
      console.log(`[Stage-2][EligiblePairs] source=market_scanner, count=${snapshot.eligibleSymbols.length}, scanCycleId=${snapshot.scanCycleId}, mode=${mode}`);
      
      await contextBridge.broadcast({
        type: 'scan_tick',
        payload: {
          mode,
          scanCycleId: snapshot.scanCycleId,
          evaluated: snapshot.evaluatedCount,
          eligible: snapshot.eligibleSymbols.length,
          ineligible: snapshot.ineligibleCount,
          eligibleSymbols: snapshot.eligibleSymbols,
          nextCycleAt: snapshot.nextCycleAt,
          nextCycleInSec: cycleCache.getNextCycleInSec(mode),
          latencyMs: snapshot.latencyMs,
          broadcastTimestamp
        },
        mode
      });

      console.log(`[Scan:${mode}] 📡 scan_tick broadcast sent (${snapshot.eligibleSymbols.length} pairs)`);
      console.log(`[Stage-2][SCAN] Broadcast complete, Δt=${Date.now() - broadcastTimestamp}ms`);
    } catch (error) {
      console.error(`[Scan:${mode}] Failed to broadcast scan_tick:`, error);
    }
  }

  /**
   * Get cached or fresh ticker snapshot
   * Shared across cycles to minimize Kraken API calls
   */
  private async getCachedTickers(): Promise<any> {
    const now = Date.now();
    
    // Return cached if fresh (< 20s old)
    if (this.cachedTickerSnapshot && (now - this.cachedTickerSnapshot.timestamp) < this.TICKER_CACHE_TTL_MS) {
      console.log('[MarketScanner] Using cached ticker snapshot');
      return this.cachedTickerSnapshot.data;
    }

    // Fetch fresh data
    console.log('[MarketScanner] Fetching fresh ticker snapshot');
    const tickers = await this.kraken.getTicker();
    this.cachedTickerSnapshot = {
      data: tickers,
      timestamp: now
    };
    
    return tickers;
  }

  /**
   * NOTE: performScan() is DISABLED - replaced by unified rotational scanner
   * This method is no longer called (deepCycleTimer was removed)
   * Keeping code for reference in case watchlist/signal logic needs to be re-integrated
   */
  private async performScan(): Promise<void> {
    // DISABLED: This method is no longer used after moving to unified rotational scanner
    console.warn('[MarketScanner] performScan() called but is disabled - use runUnifiedCycle() instead');
    return;
    
    /* DISABLED CODE BELOW - kept for reference
    if (this.isScanning) {
      console.log('Scan already in progress, skipping...');
      return;
    }

    this.isScanning = true;
    const startTime = Date.now();
    console.log('\n🔍 Performing deep-cycle scan...');

    // Track eligible pairs for both modes to create deep-cycle snapshots
    const deepCycleData = {
      paper: { evaluated: 0, eligiblePairs: [] as any[] },
      live: { evaluated: 0, eligiblePairs: [] as any[] }
    };

    try {
      // Get all users to update their watchlists
      const users = await this.getAllActiveUsers();
      
      // If no users, use default settings for testing
      if (users.length === 0) {
        console.log('No active users found, using default screener settings for testing...');
        const defaultSettings = {
          minVolume: '30000000',
          minDailyRange: '6.5',
          minPrice: '0.01',
          maxBidAskSpread: '1.00',
          excludeStablecoins: true,
          allowedTradingPairs: ['USD', 'USDT'],
          blacklistedSymbols: [],
          whitelistedSymbols: [],
          minHistoryDays: 90
        };
        
        const eligiblePairs = await this.kraken.getEligiblePairs(defaultSettings);
        console.log(`Found ${eligiblePairs.length} eligible pairs with default settings`);
      } else {
        // Process each user with their own settings
        for (const user of users) {
          // Phase 27.F.13.M: Use global screener_filters (mode-only, no userId)
          const screenerSettings = await storage.getScreenerFilters({ mode: 'paper' });
// Phase 41F-L.E2E-PURGE: DISABLED -           const tradingSettings = await storage.getTradingSettings(user.id);
          
          if (!screenerSettings) {
            console.log(`No screener settings found for user ${user.id}, skipping...`);
            continue;
          }

          console.log(`\n👤 Processing user ${user.id} with custom screener filters...`);
          
          // Cycle 3A: Process both paper and live modes separately for deep-cycle tracking
          for (const currentMode of ['paper', 'live'] as const) {
            const modeSettings = await storage.getScreenerFilters({ mode: currentMode });
            if (!modeSettings) {
              console.log(`No screener settings found for ${currentMode} mode, skipping...`);
              continue;
            }

            // Get universe size for this mode
            const settings = await buildSettingsFromModeLevel(currentMode);
            const universeProfile = settings?.universeProfile || modeSettings.universeSize || 'TOP_100';
            const universeSize = typeof universeProfile === 'string' ? this.parseUniverseProfile(universeProfile) : universeProfile;
            
            // Apply mode-specific screener filters
            const eligiblePairs = await this.kraken.getEligiblePairs({
              minVolume: modeSettings.minVolume || '0',
              minDailyRange: '0',
              minPrice: modeSettings.minPrice || undefined,
              maxPrice: modeSettings.maxPrice || undefined,
              maxBidAskSpread: modeSettings.maxBidAskSpread || undefined,
              excludeStablecoins: modeSettings.excludeStablecoins ?? true,
              allowedTradingPairs: [], // User explicitly requires NO currency-based filtering
              blacklistedSymbols: [],
              whitelistedSymbols: [],
              minHistoryDays: undefined,
              rsiMin: modeSettings.rsiMin || undefined,
              rsiMax: modeSettings.rsiMax || undefined,
              volatilityMin: modeSettings.volatilityMin || undefined,
              volatilityMax: modeSettings.volatilityMax || undefined,
              minLiquidity: modeSettings.minLiquidity || undefined,
              minMarketCap: modeSettings.minMarketCap || undefined,
              allowRegulatedOnly: modeSettings.allowRegulatedOnly ?? false,
              universeSize: modeSettings.universeSize || undefined,
              quoteCurrencies: modeSettings.quoteCurrencies as string[] || undefined,
              activeTimeframes: modeSettings.activeTimeframes as string[] || undefined
            });
            
            console.log(`[DeepCycle:${currentMode}] Universe: ${universeSize}, Eligible: ${eligiblePairs.length}`);
            
            // Cycle 3A: Track deep-cycle data for this mode
            deepCycleData[currentMode].evaluated = universeSize;
            deepCycleData[currentMode].eligiblePairs = eligiblePairs;
          }
          
          // Phase 27.F.15.A: Log filter diagnostics for both modes (mode-specific pairs)
          await this.logFilterDiagnostics(user.id, 'paper', deepCycleData.paper.eligiblePairs);
          await this.logFilterDiagnostics(user.id, 'live', deepCycleData.live.eligiblePairs);
          
          // Update watchlists for both live and paper modes (mode-specific pairs)
          await this.updateUserWatchlist(user.id, 'paper', deepCycleData.paper.eligiblePairs);
          await this.updateUserWatchlist(user.id, 'live', deepCycleData.live.eligiblePairs);
          
          // Auto-start paper simulation if user has eligible pairs and it's not already running
          await this.ensurePaperSimulationRunning(user.id, deepCycleData.paper.eligiblePairs);
          
          // Scan for signals in both modes
          await this.scanForSignals(user.id, 'paper');
          await this.scanForSignals(user.id, 'live');
        }
      }
      
      // Dawn Trader Phase 27.F.13.F: Enhanced automatic cleanup (runs every 10 minutes with scan)
      console.log('\n🧹 Running comprehensive cleanup...');
      
      // 1. Expire old trading signals
      const expiredSignals = await storage.expireAllExpiredSignals();
      console.log(`[Cleanup] ${expiredSignals} expired signals removed`);
      
      // 2. Clean stale filtered pairs (not refreshed in 15 minutes)
      const stalePairs = await storage.cleanStaleWatchlistPairs(15);
      console.log(`[Cleanup] ${stalePairs} stale filtered pairs removed`);
      
      // 3. Clean old closed paper trades (older than 24 hours)
      // Phase 27.F.15.B.4: Updated to mode-based signature
      const oldPaperTrades = await storage.cleanOldPaperSimTrades('paper', 24);
      console.log(`[Cleanup] ${oldPaperTrades} closed paper trades archived`);
      
      // 4. Clean old closed live trades (older than 30 days)
      const oldLiveTrades = await storage.cleanOldLiveTrades(30);
      console.log(`[Cleanup] ${oldLiveTrades} closed live trades archived`);
      
      console.log(`✅ Cleanup complete: ${expiredSignals + stalePairs + oldPaperTrades + oldLiveTrades} total records cleaned`);

      // Cycle 3A: Create and broadcast deep-cycle snapshots for both modes
      const latencyMs = Date.now() - startTime;
      console.log('\n📊 Creating deep-cycle snapshots...');
      
      for (const mode of ['paper', 'live'] as const) {
        const data = deepCycleData[mode];
        if (data.evaluated > 0) {
          const eligibleSymbols = data.eligiblePairs.map(p => p.symbol);
          const deepSnapshot = cycleCache.createSnapshot(
            mode,
            data.evaluated,
            eligibleSymbols,
            DEEP_CYCLE_INTERVAL_MS, // 10 minutes
            latencyMs
          );
          
          console.log(`[DeepCycle:${mode}] Created snapshot: ${deepSnapshot.scanCycleId} (${eligibleSymbols.length}/${data.evaluated} pairs)`);
          
          // Broadcast deep-cycle event with cadence flag
          await this.broadcastDeepCycleTick(mode, deepSnapshot);
        }
      }

    } catch (error) {
      console.error('Error during market scan:', error);
    } finally {
      this.isScanning = false;
    }
    */ // END DISABLED CODE
  }

  private async getAllActiveUsers(): Promise<Array<{ id: string; tradingStatus: string }>> {
    // Query all users from the database who have trading settings
    // The scanner updates watchlists for all users, not just those actively trading
    const allUsers = await storage.getAllUsers();
    
    // Return all users (settings check disabled in Phase 41F-L.E2E-PURGE)
    const usersWithSettings = allUsers.map(user => ({
      id: user.id,
      tradingStatus: user.tradingStatus || 'stopped'
    }));
    
    console.log(`[MarketScan] Found ${usersWithSettings.length} users`);
    return usersWithSettings;
  }

  private async updateUserWatchlist(userId: string, mode: 'live' | 'paper', eligiblePairs: any[]): Promise<void> {
    try {
      // Get current user watchlist for this mode
      // Phase 27.F.15.B.4: getWatchlist is now mode-only (global)
      const currentWatchlist = await storage.getWatchlist({ mode });
      const currentSymbols = new Set(currentWatchlist.map(p => p.symbol));

      // Add new eligible pairs to watchlist
      for (const pair of eligiblePairs) {
        if (!currentSymbols.has(pair.symbol)) {
          const watchlistPair: any = {
            userId,
            mode,
            symbol: pair.symbol,
            baseCurrency: pair.baseCurrency,
            quoteCurrency: pair.quoteCurrency,
            volume24h: pair.volume24h.toString(),
            currentPrice: pair.currentPrice.toString(),
            vwap: pair.vwap?.toString(),
            dailyRange: pair.dailyRange.toString(),
            lastScanned: new Date()
          };

          await storage.addWatchlistPair(watchlistPair);
        } else {
          // Update existing pair data
          const existingPair = currentWatchlist.find(p => p.symbol === pair.symbol);
          if (existingPair) {
            await storage.updateWatchlistPair(existingPair.id, {
              volume24h: pair.volume24h.toString(),
              currentPrice: pair.currentPrice.toString(),
              vwap: pair.vwap?.toString(),
              dailyRange: pair.dailyRange.toString(),
              lastScanned: new Date()
            });
          }
        }
      }

      // Remove pairs that no longer meet criteria
      const eligibleSymbols = new Set(eligiblePairs.map(p => p.symbol));
      for (const watchlistPair of currentWatchlist) {
        if (!eligibleSymbols.has(watchlistPair.symbol)) {
          await storage.removeWatchlistPair(watchlistPair.id);
        }
      }

    } catch (error) {
      console.error(`Error updating ${mode} watchlist for user ${userId}:`, error);
    }
  }

  private async scanForSignals(userId: string, mode: 'live' | 'paper'): Promise<void> {
    try {
      // Phase 27.F.15.B.4: getWatchlist is now mode-only (global)
      const watchlist = await storage.getWatchlist({ mode });
// Phase 41F-L.E2E-PURGE: DISABLED -       const settings = await storage.getTradingSettings(userId);
      
      // Phase 41F-L.E2E-PURGE: Trading settings disabled, using default values
      const settings = {
        tradingSuspended: false
      };

      // Check if trading is suspended by kill switch
      if (settings.tradingSuspended) {
        console.log('🚨 Trading suspended by Kill Switch — strategies skipped.');
        return;
      }

      // Phase 27.F.15.B.4: listStrategySettings is now mode-only (global)
      const strategySettings = await storage.listStrategySettings({ mode });

      for (const pair of watchlist) {
        await this.analyzeSymbolForSignals(userId, pair, settings, strategySettings, mode);
        
        // Add delay to respect API rate limits
        await new Promise(resolve => setTimeout(resolve, 100));
      }
    } catch (error) {
      console.error(`Error scanning for signals for user ${userId}:`, error);
    }
  }

  private async analyzeSymbolForSignals(
    userId: string, 
    pair: WatchlistPair, 
    settings: any,
    strategySettings: any[],
    mode: 'live' | 'paper'
  ): Promise<void> {
    try {
      // Get price data for analysis
      const ohlcData = await this.kraken.getOHLCData(pair.symbol, 60); // 1-hour candles
      if (!ohlcData.ohlc || ohlcData.ohlc.length < 20) return;

      // Convert to our PriceData format
      const priceData = ohlcData.ohlc.map((candle, index) => ({
        id: `${pair.symbol}-${candle.time}-${index}`,
        symbol: pair.symbol,
        timestamp: new Date(candle.time * 1000),
        open: candle.open,
        high: candle.high,
        low: candle.low,
        close: candle.close,
        volume: candle.volume,
        vwap: candle.vwap,
        sma: '0' // Will be calculated
      }));

      // Calculate technical indicators
      const currentPrice = parseFloat(priceData[priceData.length - 1].close);
      const vwap = this.strategyEngine.calculateVWAP(priceData.slice(-24)); // 24-hour VWAP
      const sma = this.strategyEngine.calculateSMA(priceData, parseInt(settings.smaLength || '20'));
      
      const indicators = {
        vwap,
        sma,
        currentPrice,
        volume: parseFloat(priceData[priceData.length - 1].volume),
        high24h: Math.max(...priceData.slice(-24).map(p => parseFloat(p.high))),
        low24h: Math.min(...priceData.slice(-24).map(p => parseFloat(p.low)))
      };

      // Helper function to get strategy params
      const getStrategyParams = (strategyName: string) => {
        const strategySetting = strategySettings.find(s => s.strategy === strategyName && s.enabled);
        return strategySetting?.params || null;
      };

      // Check all 8 strategies for signals
      console.log(`\n🔍 Analyzing ${pair.symbol} for strategy signals...`);
      const signals = [];

      // Original 3 strategies (still using TradingSettings)
      signals.push(this.strategyEngine.detectVWAPPullback(indicators, settings, priceData));
      signals.push(this.strategyEngine.detectABCDLong(priceData, settings));
      signals.push(this.strategyEngine.detectSMATrendRide(indicators, priceData, settings));

      // New 5 strategies (using strategy-specific params)
      const breakoutParams = getStrategyParams('breakout');
      if (breakoutParams) {
        signals.push(this.strategyEngine.detectBreakout(priceData, breakoutParams));
      }

      const meanReversionParams = getStrategyParams('mean_reversion');
      if (meanReversionParams) {
        signals.push(this.strategyEngine.detectMeanReversion(indicators, priceData, meanReversionParams));
      }

      const rangeTradingParams = getStrategyParams('range_trading');
      if (rangeTradingParams) {
        signals.push(this.strategyEngine.detectRangeTrading(priceData, rangeTradingParams));
      }

      const vwapBounceParams = getStrategyParams('vwap_bounce');
      if (vwapBounceParams) {
        signals.push(this.strategyEngine.detectVWAPBounce(indicators, priceData, vwapBounceParams));
      }

      const liquidityTrapParams = getStrategyParams('liquidity_trap');
      if (liquidityTrapParams) {
        signals.push(this.strategyEngine.detectLiquidityTrap(priceData, liquidityTrapParams));
      }

      // Filter out null signals
      const validSignals = signals.filter(signal => signal !== null);

      // ===== TELEMETRY: Signal Counter Logging =====
      if (validSignals.length > 0) {
        const signalsByStrategy = validSignals.reduce((acc: Record<string, number>, signal: any) => {
          acc[signal.strategy] = (acc[signal.strategy] || 0) + 1;
          return acc;
        }, {});
        console.log(`📊 [TELEMETRY] Signals generated for ${pair.symbol}:`, signalsByStrategy);
      }

      // Apply conflict resolution if multiple signals found
      let resolvedSignals = validSignals;
      let skippedSignals: any[] = [];
      if (validSignals.length > 1) {
        resolvedSignals = this.resolveConflicts(validSignals, strategySettings);
        skippedSignals = validSignals.filter(s => !resolvedSignals.includes(s));
        console.log(`⚖️ Conflict resolution: ${validSignals.length} signals → ${resolvedSignals.length} resolved for ${pair.symbol}`);
        
        // ===== TELEMETRY: Skipped Signals =====
        if (skippedSignals.length > 0) {
          console.log(`📊 [TELEMETRY] Skipped signals (conflict resolution):`, 
            skippedSignals.map(s => `${s.strategy}(conf=${s.confidence})`).join(', '));
        }

        // ===== ALERT: Conflict Resolution =====
        strategyAlerts.conflictResolution(
          userId,
          pair.symbol,
          validSignals.length,
          resolvedSignals.length,
          skippedSignals.map(s => s.strategy)
        );
      }

      // Process any found signals
      if (resolvedSignals.length > 0) {
        console.log(`✅ Found ${resolvedSignals.length} signal(s) for ${pair.symbol}`);
      }
      
      for (const signal of resolvedSignals) {
        if (signal) {
          signal.symbol = pair.symbol;
          await this.processSignal(userId, mode, signal, pair, indicators);
        }
      }

    } catch (error) {
      console.error(`Error analyzing ${pair.symbol} for user ${userId}:`, error);
    }
  }

  /**
   * Resolve conflicts when multiple strategies trigger on the same symbol
   * Strategy: BEST SCORE WINS - Only 1 signal per asset
   * Prioritization (deterministic):
   * 1. Strategy weight (from settings)
   * 2. Signal confidence
   * 3. Strategy name (alphabetical, for determinism)
   */
  private resolveConflicts(signals: any[], strategySettings: any[]): any[] {
    // Get strategy weight for each signal
    const signalsWithWeight = signals.map(signal => {
      const setting = strategySettings.find(s => s.strategy === signal.strategy);
      const weight = setting?.weight ?? 1.0; // Default weight = 1.0
      return { signal, weight };
    });

    // Sort by: weight (desc) → confidence (desc) → strategy name (asc for determinism)
    signalsWithWeight.sort((a, b) => {
      // 1. Higher weight wins
      if (a.weight !== b.weight) {
        return b.weight - a.weight;
      }
      // 2. Higher confidence wins
      if (a.signal.confidence !== b.signal.confidence) {
        return b.signal.confidence - a.signal.confidence;
      }
      // 3. Alphabetical strategy name (deterministic tiebreaker)
      return a.signal.strategy.localeCompare(b.signal.strategy);
    });

    // Take only the best signal (prevents over-exposure to single asset)
    const bestSignal = signalsWithWeight[0].signal;

    // Log conflict resolution details
    if (signals.length > 1) {
      const dropped = signals.length - 1;
      console.log(`📉 Conflict resolution: ${signals.length} signals → BEST SCORE WINS`);
      console.log(`  ✅ Selected: ${bestSignal.strategy} (weight=${signalsWithWeight[0].weight}, conf=${bestSignal.confidence})`);
      console.log(`  ❌ Dropped: ${dropped} signal(s):`, 
        signalsWithWeight.slice(1).map(s => `${s.signal.strategy}(w=${s.weight},c=${s.signal.confidence})`).join(', '));
    }

    return [bestSignal];
  }

  private async processSignal(
    userId: string, 
    mode: 'live' | 'paper',
    signal: any, 
    pair: WatchlistPair,
    indicators: any
  ): Promise<void> {
    console.log(`Signal detected for user ${userId}:`, {
      symbol: signal.symbol,
      strategy: signal.strategy,
      confidence: signal.confidence,
      entry: signal.entryPrice,
      stop: signal.stopPrice,
      target: signal.targetPrice
    });

    try {
      // Parse symbol to extract base and quote currencies (e.g., "BTCUSD" -> "BTC", "USD")
      const symbolParts = signal.symbol.match(/^([A-Z]+)(USD|USDT|EUR|GBP)$/);
      const baseCurrency = symbolParts ? symbolParts[1] : signal.symbol.slice(0, -3);
      const quoteCurrency = symbolParts ? symbolParts[2] : signal.symbol.slice(-3);

      // Save signal to database with 24-hour expiration
      const expiresAt = new Date();
      expiresAt.setHours(expiresAt.getHours() + 24);

      // Phase 41F-L.E2E: Lineage tracking - generate traceId and emit signal_snapshot
      const { lineageService } = await import('./lineage.js');
      const traceId = lineageService.getTraceId(signal.symbol, mode);
      
      await lineageService.emitSignalSnapshot({
        traceId,
        symbol: signal.symbol,
        mode,
        strategy: signal.strategy,
        signal: 'buy', // Market scanner generates buy signals
        confidence: signal.confidence,
        metadata: {
          entryPrice: signal.entryPrice,
          stopPrice: signal.stopPrice,
          targetPrice: signal.targetPrice,
          detectedBy: 'market_scanner'
        }
      });

      // Phase 27.F.15.B.4: saveTradingSignal is now mode-only (global)
      await storage.saveTradingSignal({
        mode,
        symbol: signal.symbol,
        baseCurrency,
        quoteCurrency,
        strategy: signal.strategy,
        confidence: signal.confidence.toString(),
        entryPrice: signal.entryPrice.toString(),
        stopPrice: signal.stopPrice.toString(),
        targetPrice: signal.targetPrice.toString(),
        currentPrice: (pair.currentPrice || indicators.currentPrice.toString()),
        vwap: indicators.vwap?.toString() || pair.vwap,
        volume24h: pair.volume24h,
        dailyRange: pair.dailyRange,
        status: 'active',
        expiresAt,
        metadata: {
          detectedBy: 'market_scanner',
          scanCycle: new Date().toISOString(),
          traceId // Preserve traceId for linking to trades
        }
      });

      console.log(`✅ [41F-L.E2E] Trading signal saved with lineage tracking:`, {
        symbol: signal.symbol,
        traceId
      });
      
      // Clean up expired signals for this mode (older than 24 hours)
      // Phase 27.F.15.B.4: expireOldSignals is now mode-only (global)
      const expirationCutoff = new Date();
      expirationCutoff.setHours(expirationCutoff.getHours() - 24);
      await storage.expireOldSignals({ mode, beforeDate: expirationCutoff });
      
    } catch (error) {
      console.error(`Error saving trading signal for ${signal.symbol}:`, error);
    }
  }

  async getMarketOverview(): Promise<{
    totalPairs: number;
    activePairs: number;
    topVolume: any[];
    topPerformers: any[];
  }> {
    try {
      const tickers = await this.kraken.getTicker();
      const pairs = Object.entries(tickers);
      
      const activePairs = pairs.filter(([_, ticker]) => {
        const volume = parseFloat(ticker.v[1]);
        return volume >= 1000000; // At least $1M volume
      });

      const sortedByVolume = activePairs
        .sort((a, b) => parseFloat(b[1].v[1]) - parseFloat(a[1].v[1]))
        .slice(0, 10)
        .map(([symbol, ticker]) => ({
          symbol,
          volume24h: parseFloat(ticker.v[1]),
          price: parseFloat(ticker.c[0]),
          change: ((parseFloat(ticker.c[0]) - parseFloat(ticker.o)) / parseFloat(ticker.o)) * 100
        }));

      const topPerformers = activePairs
        .map(([symbol, ticker]) => ({
          symbol,
          change: ((parseFloat(ticker.c[0]) - parseFloat(ticker.o)) / parseFloat(ticker.o)) * 100,
          price: parseFloat(ticker.c[0]),
          volume: parseFloat(ticker.v[1])
        }))
        .sort((a, b) => b.change - a.change)
        .slice(0, 10);

      return {
        totalPairs: pairs.length,
        activePairs: activePairs.length,
        topVolume: sortedByVolume,
        topPerformers
      };
    } catch (error) {
      console.error('Error getting market overview:', error);
      return {
        totalPairs: 0,
        activePairs: 0,
        topVolume: [],
        topPerformers: []
      };
    }
  }

  /**
   * Phase 27.F.15.A/B: Log comprehensive filter diagnostics to database
   * This enables the Filtered Pairs widget to show real-time scan statistics
   * with detailed breakdown by filter type
   */
  private async logFilterDiagnostics(
    userId: string, 
    mode: 'live' | 'paper', 
    eligiblePairs: any[]
  ): Promise<void> {
    try {
      // Get total universe count
      const tickers = await this.kraken.getTicker();
      const pairsScanned = Object.keys(tickers).length;
      const eligibleCount = eligiblePairs.length;
      
      // Calculate overall stats
      const failurePercent = pairsScanned > 0 
        ? ((pairsScanned - eligibleCount) / pairsScanned * 100).toFixed(2)
        : '0';
      
      // Determine top failure reason
      // Since we don't have access to exclusionReasons here, we use the same heuristic
      // The detailed breakdown is available via /api/paper-sim/diagnostics/scan
      let topFailureReason = 'Quote Currency Filter';
      
      if (parseFloat(failurePercent) > 90) {
        topFailureReason = 'Quote Currency Filter';
      } else if (parseFloat(failurePercent) > 50) {
        topFailureReason = 'Min Volume';
      } else if (eligibleCount > 0) {
        topFailureReason = 'Daily Range';
      }
      
      // Log to database
      // Phase 27.F.15.B.4: logFilterDiagnostic is now mode-only (global)
      await storage.logFilterDiagnostic({
        mode,
        pairsScanned,
        eligiblePairs: eligibleCount,
        topFailureReason,
        failurePercent
      });
      
      console.log(`📊 [FilterDiag] ${mode}: scanned=${pairsScanned}, eligible=${eligibleCount} (${(100 - parseFloat(failurePercent)).toFixed(1)}%)`);
    } catch (error) {
      console.error(`Error logging filter diagnostics for user ${userId} (${mode}):`, error);
    }
  }

  /**
   * Auto-start paper simulation for users with eligible pairs
   * SAFETY: Respects kill switch, trading status, and manual stops
   */
  private async ensurePaperSimulationRunning(userId: string, eligiblePairs: any[]): Promise<void> {
    try {
      // Only auto-start if user has eligible pairs
      if (eligiblePairs.length === 0) {
        console.log(`[MarketScan:AutoStart] User ${userId} has no eligible pairs, skipping auto-start`);
        return;
      }

      // SAFETY CHECK 1: Respect mode-level settings (kill switch, etc.)
      // Phase 41F-L.E2E-PURGE: Use mode-level settings instead of getTradingSettings
      const settings = await buildSettingsFromModeLevel('paper');
      if (settings.isSuspended || settings.killSwitch) {
        console.log(`[MarketScan:AutoStart] User ${userId} has trading suspended (kill switch), skipping auto-start`);
        return;
      }

      // SAFETY CHECK 2: Check if paper simulation is already running
      const simStatus = await getPaperSimulationStatus(userId);
      if (simStatus?.isRunning) {
        console.log(`[MarketScan:AutoStart] Paper simulation already running, skipping auto-start`);
        return;
      }

      // All checks passed - auto-start paper simulation
      console.log(`[MarketScan:AutoStart] User ${userId} has ${eligiblePairs.length} eligible pairs, starting paper simulation...`);
      
      // Auto-start logic would go here - currently disabled pending proper implementation
      // TODO: Implement paper simulation auto-start using mode-level engine
    } catch (error) {
      console.error(`[MarketScan:AutoStart] Error in auto-start check for user ${userId}:`, error);
    }
  }
}
