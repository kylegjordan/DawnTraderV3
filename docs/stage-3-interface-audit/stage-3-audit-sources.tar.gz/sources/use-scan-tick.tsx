import { useEffect, useState, useRef } from 'react';
import { useWebSocket } from './use-websocket';
import { useQuery } from '@tanstack/react-query';

interface ScanTickPayload {
  mode: 'live' | 'paper' | 'learning';
  scanCycleId: string;
  evaluated: number;
  eligible: number;
  ineligible: number;
  eligibleSymbols: string[];
  lastTickAt: string;
  nextCycleAt: string;
  nextCycleInSec: number;
  cadenceMs: number;
  latencyMs: number;
  broadcastTimestamp: number;
}

interface ScanStatusResponse {
  mode: string;
  cadenceMs: number;
  lastTickAt: string | null;
  nextTickAt: string | null;
  lastCycleId: string | null;
  eligible: number;
  evaluated: number;
  status: 'pending' | 'active';
}

interface UseScanTickReturn {
  eligible: number;
  evaluated: number;
  scanCycleId: string | null;
  countdownSeconds: number;
  lastTickAt: string | null;
  nextCycleAt: string | null;
  latencyMs: number;
  isLoading: boolean;
  activeMode: string | null;
}

export function useScanTick(): UseScanTickReturn {
  const { messages } = useWebSocket();
  const [activeMode, setActiveMode] = useState<string | null>(null);
  const [eligible, setEligible] = useState<number>(0);
  const [evaluated, setEvaluated] = useState<number>(0);
  const [scanCycleId, setScanCycleId] = useState<string | null>(null);
  const [lastTickAt, setLastTickAt] = useState<string | null>(null);
  const [nextCycleAt, setNextCycleAt] = useState<string | null>(null);
  const [cadenceMs, setCadenceMs] = useState<number>(30000);
  const [latencyMs, setLatencyMs] = useState<number>(0);
  const [countdownSeconds, setCountdownSeconds] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const countdownIntervalRef = useRef<number | null>(null);

  // Stage 2C: Hydrate immediately from /api/scan/status (mode-agnostic - detects active scanner mode)
  // Query paper mode first, but if it's in learning mode, the response will indicate that
  const { data: statusData } = useQuery<ScanStatusResponse>({
    queryKey: [`/api/scan/status?mode=paper`],
    staleTime: Infinity, // Only fetch once on mount, then rely on scan_tick events
    refetchOnWindowFocus: false,
  });

  // Hydrate from initial status response and detect active scanner mode
  useEffect(() => {
    if (statusData && statusData.status === 'active' && !scanCycleId) {
      const detectedMode = statusData.mode;
      console.log('[Stage-2C][useScanTick] Hydrating from /api/scan/status:', {
        ...statusData,
        detectedMode
      });
      
      setActiveMode(detectedMode);
      setEligible(statusData.eligible);
      setEvaluated(statusData.evaluated);
      setScanCycleId(statusData.lastCycleId);
      setLastTickAt(statusData.lastTickAt);
      setNextCycleAt(statusData.nextTickAt);
      setCadenceMs(statusData.cadenceMs);
      setIsLoading(false);
    }
  }, [statusData, scanCycleId]);

  // Stage 2C: Handle scan_tick WebSocket events (dynamically updates activeMode on mode changes)
  useEffect(() => {
    // Look for scan_tick messages (any mode)
    const scanTickMessages = messages.filter((msg) => msg.type === 'scan_tick');

    if (scanTickMessages.length > 0) {
      const latestTick = scanTickMessages[scanTickMessages.length - 1];
      const payload = latestTick.payload as ScanTickPayload;

      console.log('[Stage-2C][useScanTick] Received scan_tick:', {
        mode: payload.mode,
        scanCycleId: payload.scanCycleId,
        eligible: payload.eligible,
        evaluated: payload.evaluated,
        cadenceMs: payload.cadenceMs,
        lastTickAt: payload.lastTickAt,
        nextCycleAt: payload.nextCycleAt
      });

      // Dynamically update activeMode if it changes (engine start/stop transitions)
      if (payload.mode !== activeMode) {
        console.log('[Stage-2C][useScanTick] Mode switched:', activeMode, '→', payload.mode);
        setActiveMode(payload.mode);
      }

      // Update state - countdown effect will handle timer updates
      setEligible(payload.eligible);
      setEvaluated(payload.evaluated);
      setScanCycleId(payload.scanCycleId);
      setLastTickAt(payload.lastTickAt);
      setNextCycleAt(payload.nextCycleAt);
      setCadenceMs(payload.cadenceMs);
      setLatencyMs(payload.latencyMs);
      setIsLoading(false);
    }
  }, [messages]);

  // Stage 2C: Dedicated countdown effect - continuously updates based on nextCycleAt
  useEffect(() => {
    // Clear any existing interval
    if (countdownIntervalRef.current) {
      clearInterval(countdownIntervalRef.current);
      countdownIntervalRef.current = null;
    }

    // Exit early if no nextCycleAt
    if (!nextCycleAt) {
      setCountdownSeconds(0);
      return;
    }

    const nextCycleTime = new Date(nextCycleAt).getTime();

    // Invalid timestamp check
    if (isNaN(nextCycleTime)) {
      setCountdownSeconds(0);
      return;
    }

    // Countdown update function
    const updateCountdown = () => {
      const now = Date.now();
      const remainingMs = Math.max(0, nextCycleTime - now);
      const remainingSec = Math.ceil(remainingMs / 1000);
      setCountdownSeconds(remainingSec);
    };

    // Initial update
    updateCountdown();

    // Set up interval - keeps running even when countdown reaches 0
    // Will naturally update when nextCycleAt changes from new scan_tick
    countdownIntervalRef.current = window.setInterval(updateCountdown, 1000);

    // Cleanup on unmount or when nextCycleAt changes
    return () => {
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
        countdownIntervalRef.current = null;
      }
    };
  }, [nextCycleAt]);

  return {
    eligible,
    evaluated,
    scanCycleId,
    countdownSeconds,
    lastTickAt,
    nextCycleAt,
    latencyMs,
    isLoading,
    activeMode
  };
}
