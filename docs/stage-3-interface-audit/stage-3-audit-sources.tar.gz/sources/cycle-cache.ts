/**
 * CycleCache - Per-Mode Cycle Snapshot Storage
 * 
 * Phase: Cycle 3A - Trading Cycle Alignment
 * 
 * Maintains in-memory snapshots of scan cycles for each mode (paper/live).
 * Each snapshot includes:
 * - scan_cycle_id: Unique identifier for this cycle
 * - evaluatedCount: Number of pairs evaluated in this cycle
 * - eligibleSymbols: Array of symbols that passed filters
 * - ineligibleCount: Calculated as evaluated - eligible.length
 * - nextCycleAt: ISO timestamp for next cycle
 * - timestamp: When this snapshot was created
 * 
 * TTL: 3 minutes (auto-expire stale data)
 */

import { nanoid } from 'nanoid';

export interface CycleSnapshot {
  scanCycleId: string;
  evaluatedCount: number;
  eligibleSymbols: string[];
  ineligibleCount: number;
  nextCycleAt: string; // ISO-8601 timestamp
  timestamp: string; // ISO-8601 timestamp
  latencyMs?: number; // Optional: cycle execution time
}

export interface CycleMetrics {
  scanCycleId: string;
  nextCycleInSec: number;
  nextCycleAt: string;
  lastBatch: {
    evaluated: number;
    eligible: number;
    ineligible: number;
  };
  timestamp: string;
  latencyMs?: number;
}

const CYCLE_TTL_MS = 3 * 60 * 1000; // 3 minutes
const DEFAULT_CYCLE_INTERVAL_MS = 30 * 1000; // 30 seconds default

class CycleCacheService {
  private cache: Map<string, { snapshot: CycleSnapshot; expiresAt: number }> = new Map();

  /**
   * Store a new cycle snapshot for a mode
   */
  set(mode: 'live' | 'paper', snapshot: CycleSnapshot): void {
    const key = `cycle:${mode}`;
    const expiresAt = Date.now() + CYCLE_TTL_MS;
    
    this.cache.set(key, {
      snapshot,
      expiresAt
    });
    
    console.log(`[CycleCache] Stored snapshot for ${mode} mode:`, {
      scanCycleId: snapshot.scanCycleId,
      evaluated: snapshot.evaluatedCount,
      eligible: snapshot.eligibleSymbols.length,
      nextCycleAt: snapshot.nextCycleAt
    });
  }

  /**
   * Get current cycle snapshot for a mode (returns null if expired or not found)
   */
  get(mode: 'live' | 'paper'): CycleSnapshot | null {
    const key = `cycle:${mode}`;
    const cached = this.cache.get(key);
    
    if (!cached) {
      return null;
    }
    
    // Check if expired
    if (Date.now() > cached.expiresAt) {
      console.log(`[CycleCache] Snapshot expired for ${mode} mode, clearing...`);
      this.cache.delete(key);
      return null;
    }
    
    return cached.snapshot;
  }

  /**
   * Calculate seconds until next cycle
   */
  getNextCycleInSec(mode: 'live' | 'paper'): number {
    const snapshot = this.get(mode);
    
    if (!snapshot || !snapshot.nextCycleAt) {
      // No snapshot, estimate ~30s for next cycle
      return 30;
    }
    
    const nextCycleTime = new Date(snapshot.nextCycleAt).getTime();
    const now = Date.now();
    const diffMs = Math.max(0, nextCycleTime - now);
    
    return Math.floor(diffMs / 1000);
  }

  /**
   * Get cycle metrics for API endpoint
   */
  getMetrics(mode: 'live' | 'paper'): CycleMetrics | null {
    const snapshot = this.get(mode);
    
    if (!snapshot) {
      return null;
    }
    
    return {
      scanCycleId: snapshot.scanCycleId,
      nextCycleInSec: this.getNextCycleInSec(mode),
      nextCycleAt: snapshot.nextCycleAt,
      lastBatch: {
        evaluated: snapshot.evaluatedCount,
        eligible: snapshot.eligibleSymbols.length,
        ineligible: snapshot.ineligibleCount
      },
      timestamp: snapshot.timestamp,
      latencyMs: snapshot.latencyMs
    };
  }

  /**
   * Get eligible pairs list for current cycle
   */
  getEligiblePairs(mode: 'live' | 'paper'): { 
    scanCycleId: string; 
    count: number; 
    symbols: string[];
    timestamp: string;
  } | null {
    const snapshot = this.get(mode);
    
    if (!snapshot) {
      return null;
    }
    
    return {
      scanCycleId: snapshot.scanCycleId,
      count: snapshot.eligibleSymbols.length,
      symbols: snapshot.eligibleSymbols,
      timestamp: snapshot.timestamp
    };
  }

  /**
   * Create a new cycle snapshot with auto-generated ID and nextCycleAt
   */
  createSnapshot(
    mode: 'live' | 'paper',
    evaluatedCount: number,
    eligibleSymbols: string[],
    cycleIntervalMs: number = DEFAULT_CYCLE_INTERVAL_MS,
    latencyMs?: number
  ): CycleSnapshot {
    const now = new Date();
    const nextCycleAt = new Date(now.getTime() + cycleIntervalMs);
    
    const snapshot: CycleSnapshot = {
      scanCycleId: `cycle_${mode}_${nanoid(10)}`,
      evaluatedCount,
      eligibleSymbols,
      ineligibleCount: evaluatedCount - eligibleSymbols.length,
      nextCycleAt: nextCycleAt.toISOString(),
      timestamp: now.toISOString(),
      latencyMs
    };
    
    this.set(mode, snapshot);
    return snapshot;
  }

  /**
   * Clear cache for specific mode or all modes
   */
  clear(mode?: 'live' | 'paper'): void {
    if (mode) {
      const key = `cycle:${mode}`;
      this.cache.delete(key);
      console.log(`[CycleCache] Cleared cache for ${mode} mode`);
    } else {
      this.cache.clear();
      console.log('[CycleCache] Cleared all cache');
    }
  }

  /**
   * Clean up expired entries (called periodically)
   */
  cleanupExpired(): number {
    const now = Date.now();
    let cleaned = 0;
    
    for (const [key, value] of this.cache.entries()) {
      if (now > value.expiresAt) {
        this.cache.delete(key);
        cleaned++;
      }
    }
    
    if (cleaned > 0) {
      console.log(`[CycleCache] Cleaned ${cleaned} expired entries`);
    }
    
    return cleaned;
  }

  /**
   * Get stats for monitoring
   */
  getStats(): {
    totalEntries: number;
    paperSnapshot: CycleSnapshot | null;
    liveSnapshot: CycleSnapshot | null;
  } {
    return {
      totalEntries: this.cache.size,
      paperSnapshot: this.get('paper'),
      liveSnapshot: this.get('live')
    };
  }
}

// Export singleton instance
export const cycleCache = new CycleCacheService();

// Schedule cleanup every minute
setInterval(() => {
  cycleCache.cleanupExpired();
}, 60 * 1000);

console.log('[CycleCache] Service initialized with 3-minute TTL');
