import { useState, useEffect, Component, ErrorInfo, ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import ActiveTrades from "@/components/trading/active-trades";
import Watchlist from "@/components/trading/watchlist";
import ReadyToBuyTable from "@/components/trading/ready-to-buy-table";
import MaintenanceBanner from "@/components/maintenance/maintenance-banner";
import ModeBanner from "@/components/mode-banner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, TrendingUp, Filter, Lightbulb, RefreshCw, AlertTriangle, Clock } from "lucide-react";
import { FilterHealthWidget } from "@/components/dashboard/filter-health-widget";
import { FilterInsights } from "@/components/trading/filter-insights";
import { useUserRole } from "@/hooks/useUserRole";
import { Button } from "@/components/ui/button";
import { queryClient } from "@/lib/queryClient";
import { useScanTick } from "@/hooks/use-scan-tick";

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Trading page error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-6 space-y-4">
          <Card className="border-destructive">
            <CardHeader>
              <div className="flex items-center gap-2 text-destructive">
                <AlertTriangle className="h-5 w-5" />
                <CardTitle>Error Loading Trading Page</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                {this.state.error?.message || 'An unexpected error occurred'}
              </p>
              <Button onClick={() => window.location.reload()}>
                Reload Page
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}

interface ScanRowsSymbol {
  symbol: string;
  status: 'passed' | 'error';
  timestamp: string;
}

interface ScanRowsResponse {
  mode: string;
  scanCycleId: string;
  eligible: number;
  evaluated: number;
  symbols: ScanRowsSymbol[];
  timestamp: string;
  nextCycleAt: string;
}

function FilteredPairsTab() {
  // Stage 2C: Use scan_tick as single source of truth (auto-detects active mode: paper/live/learning)
  const scanTick = useScanTick();

  // Stage 2C: Query scan rows from cache (NO polling - event-driven only)
  const { data, isLoading, error } = useQuery<ScanRowsResponse>({
    queryKey: [`/api/scan/rows?mode=paper`],
    staleTime: Infinity, // Never auto-refresh - only refresh on scan_tick events
    refetchOnWindowFocus: false,
    retry: 2,
    retryDelay: 1000,
  });

  // Stage 2C: Invalidate query when scan_tick updates (event-driven)
  useEffect(() => {
    if (!scanTick.isLoading && scanTick.scanCycleId) {
      console.log('[Stage-2C][FilteredPairs] scan_tick update, refreshing rows:', {
        eligible: scanTick.eligible,
        scanCycleId: scanTick.scanCycleId,
        countdown: scanTick.countdownSeconds
      });
      
      // Refresh rows when new scan_tick arrives
      queryClient.invalidateQueries({ queryKey: [`/api/scan/rows?mode=paper`] });
    }
  }, [scanTick.scanCycleId]);

  // Phase 41.3: Filter out abort errors (React Query cancellation)
  const isAbortError = error && (error as Error).message?.includes('abort');
  
  if (error && !isAbortError) {
    return (
      <div className="space-y-4">
        <FilterHealthWidget />
        <Card>
          <CardContent className="py-8 text-center">
            <p className="text-destructive">Failed to load filtered pairs: {(error as Error).message}</p>
            <p className="text-sm text-muted-foreground mt-2">
              Data will refresh automatically on next scan_tick event
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Stage 2C: Countdown display
  const countdownDisplay = scanTick.countdownSeconds > 0 ? `${scanTick.countdownSeconds}s` : '0s';

  return (
    <div className="space-y-4">
      <FilterHealthWidget />
      
      {/* Stage 2C: Scanner Status - Event-driven via scan_tick SSOT */}
      <Card className="border-primary/20">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-primary" />
              <div>
                <CardTitle className="text-sm font-medium">
                  {scanTick.eligible} Eligible Pairs
                </CardTitle>
                {scanTick.scanCycleId && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Cycle: {scanTick.scanCycleId}
                  </p>
                )}
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Next Scan</p>
              <p className="text-sm font-medium">{countdownDisplay}</p>
            </div>
          </div>
        </CardHeader>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>
            Filtered Pairs ({scanTick.eligible} symbols)
          </CardTitle>
          {scanTick.lastTickAt && (
            <p className="text-sm text-muted-foreground mt-1" data-testid="text-last-updated">
              Last scan: {new Date(scanTick.lastTickAt).toLocaleTimeString()}
            </p>
          )}
        </CardHeader>
        <CardContent>
          {(isLoading || scanTick.isLoading) && !data ? (
            <div className="text-center py-8">
              <RefreshCw className="w-8 h-8 mx-auto mb-3 animate-spin text-muted-foreground" />
              <p className="text-muted-foreground">Loading filtered pairs...</p>
            </div>
          ) : data && data.symbols && data.symbols.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full" data-testid="table-filtered-pairs">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2 px-3 font-medium">Symbol</th>
                    <th className="text-left py-2 px-3 font-medium">Status</th>
                    <th className="text-left py-2 px-3 font-medium">Last Updated</th>
                  </tr>
                </thead>
                <tbody>
                  {data.symbols.map((symbol, index) => (
                    <tr key={`${symbol.symbol}-${index}`} className="border-b hover:bg-muted/50" data-testid={`row-pair-${index}`}>
                      <td className="py-2 px-3 font-medium" data-testid={`text-symbol-${index}`}>{symbol.symbol}</td>
                      <td className="py-2 px-3" data-testid={`text-status-${index}`}>
                        <span className={`text-sm ${symbol.status === 'passed' ? 'text-success' : 'text-destructive'}`}>
                          {symbol.status === 'passed' ? 'All filters passed' : 'Error'}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-sm text-muted-foreground" data-testid={`text-timestamp-${index}`}>
                        {new Date(symbol.timestamp).toLocaleTimeString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8">
              <Filter className="w-12 h-12 mx-auto mb-3 text-muted-foreground opacity-50" />
              <h3 className="text-lg font-semibold mb-2">No Filtered Pairs</h3>
              <p className="text-muted-foreground">
                No symbols currently pass the screening filters
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function TradingPageContent() {
  const [activeTab, setActiveTab] = useState("open");
  const { isAdmin, isOwner } = useUserRole();
  
  // Filter Insights tab is only available for admin/owner users
  const showFilterInsights = isAdmin || isOwner;

  return (
    <div className="p-4 sm:p-6 space-y-4 sm:space-y-6" data-testid="trading-page">
      {/* Maintenance Mode Banner */}
      <MaintenanceBanner />
      
      {/* Trading Mode Banner */}
      <ModeBanner />

      <div>
        <h1 className="text-3xl font-bold mb-2">Trading</h1>
        <p className="text-muted-foreground">
          Manage open positions, view ready-to-buy signals, and monitor filtered pairs
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className={`grid w-full ${showFilterInsights ? 'grid-cols-4' : 'grid-cols-3'}`} data-testid="trading-tabs">
          <TabsTrigger value="open" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm px-2 sm:px-3" data-testid="tab-open-trades">
            <BarChart3 className="w-3 h-3 sm:w-4 sm:h-4" />
            <span className="hidden xs:inline">Open Trades</span>
            <span className="xs:hidden">Open</span>
          </TabsTrigger>
          <TabsTrigger value="ready" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm px-2 sm:px-3" data-testid="tab-ready-to-buy">
            <TrendingUp className="w-3 h-3 sm:w-4 sm:h-4" />
            <span className="hidden xs:inline">Ready to Buy</span>
            <span className="xs:hidden">Ready</span>
          </TabsTrigger>
          <TabsTrigger value="filtered" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm px-2 sm:px-3" data-testid="tab-filtered-pairs">
            <Filter className="w-3 h-3 sm:w-4 sm:h-4" />
            <span className="hidden xs:inline">Filtered Pairs</span>
            <span className="xs:hidden">Filtered</span>
          </TabsTrigger>
          {showFilterInsights && (
            <TabsTrigger value="insights" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm px-2 sm:px-3" data-testid="tab-filter-insights">
              <Lightbulb className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden xs:inline">Filter Insights</span>
              <span className="xs:hidden">Insights</span>
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="open" className="mt-6">
          <ActiveTrades />
        </TabsContent>

        <TabsContent value="ready" className="mt-6">
          <ReadyToBuyTable />
        </TabsContent>

        <TabsContent value="filtered" className="mt-6">
          <FilteredPairsTab />
        </TabsContent>

        {showFilterInsights && (
          <TabsContent value="insights" className="mt-6">
            <FilterInsights />
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}

export default function TradingPage() {
  return (
    <ErrorBoundary>
      <TradingPageContent />
    </ErrorBoundary>
  );
}
