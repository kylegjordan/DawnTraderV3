import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/dashboard";
import History from "@/pages/history";
import Analysis from "@/pages/analysis";
import Settings from "@/pages/settings";
import WatchlistPage from "@/pages/watchlist";
import ActiveTradesPage from "@/pages/active-trades";
import KillSwitchScreen from "@/pages/kill-switch";
import ReportsPage from "@/pages/reports";
import DailyBriefPage from "@/pages/daily-brief";
import GoalsEnginePage from "@/pages/goals-engine";
import LoginPage from "@/pages/login";
import RegisterPage from "@/pages/register";
import SystemsPage from "@/pages/systems";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/top-bar";
import { useState, useEffect } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import NotFound from "@/pages/not-found";
import { TradingModeProvider } from "@/contexts/trading-mode-context";
import { ensureValidToken } from "@/lib/auth";

// Auth guard component with token refresh
function RequireAuth({ children }: { children: React.ReactNode }) {
  const [_, setLocation] = useLocation();
  const [isChecking, setIsChecking] = useState(true);
  
  useEffect(() => {
    const checkAuth = async () => {
      // ensureValidToken checks expiry and refreshes if needed
      const validToken = await ensureValidToken();
      
      if (!validToken) {
        setLocation("/login");
        return;
      }
      
      setIsChecking(false);
    };
    
    checkAuth();
  }, [setLocation]);
  
  if (isChecking) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }
  
  return <>{children}</>;
}

function Router() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const isMobile = useIsMobile();
  const [location, setLocation] = useLocation();
  
  // Check kill switch status and auto-redirect
  const { data: settings } = useQuery<{ tradingSuspended?: boolean }>({
    queryKey: ['/api/settings'],
    refetchInterval: 60000,
    staleTime: 60000,
    refetchOnWindowFocus: false
  });
  
  useEffect(() => {
    const allowedPaths = ['/kill-switch', '/settings'];
    if (settings?.tradingSuspended && !allowedPaths.includes(location)) {
      setLocation('/kill-switch');
    }
  }, [settings, location, setLocation]);

  // Check if on public routes (login/register)
  const isPublicRoute = location === '/login' || location === '/register';

  // Public routes (no auth required)
  if (isPublicRoute) {
    return (
      <Switch>
        <Route path="/login" component={LoginPage} />
        <Route path="/register" component={RegisterPage} />
      </Switch>
    );
  }

  // Protected routes (require auth)
  return (
    <RequireAuth>
      <div className="flex h-screen overflow-hidden bg-background">
        <Sidebar 
          isOpen={sidebarOpen} 
          onClose={() => setSidebarOpen(false)}
          className={`${isMobile ? 'fixed z-40' : 'relative'}`}
        />
        
        <main className="flex-1 overflow-y-auto scrollbar-thin">
          <TopBar 
            onMenuClick={() => setSidebarOpen(true)}
            showMenuButton={isMobile}
          />
          
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/dashboard" component={Dashboard} />
            <Route path="/watchlist" component={WatchlistPage} />
            <Route path="/active-trades" component={ActiveTradesPage} />
            <Route path="/history" component={History} />
            <Route path="/reports" component={ReportsPage} />
            <Route path="/daily-brief" component={DailyBriefPage} />
            <Route path="/analysis" component={Analysis} />
            <Route path="/goals-engine" component={GoalsEnginePage} />
            <Route path="/systems" component={SystemsPage} />
            <Route path="/settings" component={Settings} />
            <Route path="/kill-switch" component={KillSwitchScreen} />
            <Route component={NotFound} />
          </Switch>
        </main>
        
        {isMobile && sidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-30"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </div>
    </RequireAuth>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TradingModeProvider>
        <TooltipProvider>
          <div className="min-h-screen bg-background text-foreground">
            <Toaster />
            <Router />
          </div>
        </TooltipProvider>
      </TradingModeProvider>
    </QueryClientProvider>
  );
}

export default App;
