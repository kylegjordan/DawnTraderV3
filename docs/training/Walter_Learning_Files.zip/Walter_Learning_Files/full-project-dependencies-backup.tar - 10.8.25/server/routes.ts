import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import rateLimit from "express-rate-limit";
import { storage } from "./storage";
import { KrakenService } from "./services/kraken";
import { TradingEngine, EngineSettingsBus } from "./services/trading-engine";
import { AIAnalyst } from "./services/ai-analyst";
import { MarketScanner } from "./services/market-scanner";
import { RiskManager } from "./services/risk-manager";
import { aiOpportunitiesService } from "./services/ai-opportunities";
import { dailyBriefService } from "./services/daily-brief";
import { insertTradingSettingsSchema, insertWatchlistPairSchema, insertGuardrailsSchema, insertScreenerFiltersSchema } from "@shared/schema";
import { databaseMonitor } from "./services/database-monitor";
import { stockService } from "./services/stocks";
import { marketDataService } from "./services/market-data";
import OpenAI from "openai";
import jwt from "jsonwebtoken";
import { validatePasswordStrength, hashPassword, verifyPassword, getPasswordStrengthMessage } from "./services/auth-service";

// Rate Limiting for Authentication Endpoints - prevent brute force attacks
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // max 5 login attempts per window
  message: { error: "Too many login attempts, please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});

const tradingEngines = new Map<string, TradingEngine>();
const marketScanner = new MarketScanner();
const aiAnalyst = new AIAnalyst();
const riskManager = new RiskManager();

// JWT secrets for authentication
const JWT_SECRET = process.env.JWT_SECRET || "development_secret_change_in_production";
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || "development_refresh_secret_change_in_production";

// Issue access and refresh tokens
function issueTokens(user: { id: string; username: string }) {
  const accessToken = jwt.sign(
    { id: user.id, username: user.username }, 
    JWT_SECRET, 
    { expiresIn: '12h' }
  );
  const refreshToken = jwt.sign(
    { id: user.id }, 
    JWT_REFRESH_SECRET, 
    { expiresIn: '7d' }
  );
  return { accessToken, refreshToken };
}

// Authentication Middleware
export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    username: string;
  };
}

function authenticateToken(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader) {
    return res.status(401).json({ error: 'No authentication credentials provided' });
  }
  
  const token = authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { id: string; username: string };
    req.user = { id: decoded.id, username: decoded.username };
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// TEMPORARILY DISABLED: Do not ping Kraken for 1 hour (maintenance mode)
// marketScanner.startHourlyScanning();

// AI Opportunities service will be started conditionally based on user settings
// (service checks settings before starting hourly generation)
// TEMPORARILY DISABLED: Do not ping Kraken for 1 hour

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // WebSocket server for real-time data
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws: WebSocket, request) => {
    console.log('WebSocket client connected');
    
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        handleWebSocketMessage(ws, data);
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });
    
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
  });

  // API Routes

  // Health check endpoint
  app.get('/api/health', (_req, res) => {
    res.json({ 
      status: 'ok', 
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      env: process.env.NODE_ENV || 'development'
    });
  });

  // Authentication Routes
  
  // REGISTER - DISABLED FOR SINGLE-USER MODE
  // To enable registration, remove the error response below and uncomment the registration logic
  app.post('/api/auth/register', async (req: AuthenticatedRequest, res) => {
    return res.status(403).json({ 
      error: 'Registration is disabled. This is a single-user application.' 
    });
    
    /* REGISTRATION CODE (uncomment to enable):
    try {
      const { username, email, password } = req.body;
      
      if (!username || !email || !password) {
        return res.status(400).json({ error: 'Username, email, and password are required' });
      }
      
      // Basic email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ error: 'Invalid email format' });
      }
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ error: 'Username already exists' });
      }
      
      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(400).json({ error: 'Email already exists' });
      }
      
      // Validate password strength
      if (!validatePasswordStrength(password)) {
        return res.status(400).json({ 
          error: getPasswordStrengthMessage(password)
        });
      }
      
      // Hash password and create user
      const passwordHash = await hashPassword(password);
      const user = await storage.createUser({ 
        username,
        email,
        password: passwordHash,
        displayName: username,
        timezone: 'UTC',
        tradingMode: 'paper',
        tradingStatus: 'stopped'
      });
      
      // Create default trading settings for the new user
      await storage.createTradingSettings({ userId: user.id });
      
      res.json({ success: true, userId: user.id });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({ error: 'Registration failed' });
    }
    */
  });

  // LOGIN - Rate limited to prevent brute force attacks
  app.post('/api/auth/login', loginLimiter, async (req: AuthenticatedRequest, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required' });
      }
      
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      if (!user.password) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }
      
      const valid = await verifyPassword(password, user.password);
      if (!valid) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }
      
      const { accessToken, refreshToken } = issueTokens({ id: user.id, username: user.username });
      
      res.json({ 
        accessToken, 
        refreshToken,
        token: accessToken, // Keep for backward compatibility
        user: { id: user.id, username: user.username } 
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ error: 'Login failed' });
    }
  });

  // VERIFY TOKEN
  app.get('/api/auth/verify', async (req: AuthenticatedRequest, res) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader) {
        return res.status(401).json({ valid: false, error: 'No authorization header' });
      }
      
      const token = authHeader.split(' ')[1];
      if (!token) {
        return res.status(401).json({ valid: false, error: 'No token provided' });
      }
      
      const decoded = jwt.verify(token, JWT_SECRET) as { id: string; username: string };
      res.json({ valid: true, user: decoded });
    } catch (error) {
      res.status(401).json({ valid: false, error: 'Invalid or expired token' });
    }
  });

  // REFRESH TOKEN
  app.post('/api/auth/refresh', async (req: AuthenticatedRequest, res) => {
    try {
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({ error: 'Refresh token is required' });
      }
      
      const decoded = jwt.verify(token, JWT_REFRESH_SECRET) as { id: string };
      const user = await storage.getUser(decoded.id);
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      const { accessToken, refreshToken } = issueTokens({ id: user.id, username: user.username });
      
      res.json({ 
        accessToken, 
        refreshToken,
        user: { id: user.id, username: user.username }
      });
    } catch (error) {
      res.status(401).json({ error: 'Invalid or expired refresh token' });
    }
  });

  // User and Authentication
  app.get('/api/user/profile', authenticateToken, async (req: AuthenticatedRequest, res) => {
    const user = await storage.getUser(req.user!.id);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json(user);
  });

  // Trading Settings
  app.get('/api/settings', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      
      let settings = await storage.getTradingSettings(userId);
      
      if (!settings) {
        // Create default settings
        settings = await storage.createTradingSettings({ userId });
      }
      
      // Check if environment secrets are configured
      const hasKrakenApiKey = !!process.env.KRAKEN_API_KEY;
      const hasKrakenApiSecret = !!process.env.KRAKEN_API_SECRET;
      
      res.json({
        ...settings,
        hasKrakenApiKey,
        hasKrakenApiSecret,
        krakenApiKeySet: hasKrakenApiKey,
        krakenApiSecretSet: hasKrakenApiSecret
      });
    } catch (error) {
      console.error('Error fetching settings:', error);
      res.status(500).json({ error: 'Failed to fetch settings' });
    }
  });

  app.put('/api/settings', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      
      // Update trading settings (credentials are now only stored in environment secrets)
      const validatedData = insertTradingSettingsSchema.omit({ userId: true }).parse(req.body);
      const settings = await storage.updateTradingSettings(userId, validatedData);
      
      res.json(settings);
    } catch (error) {
      console.error('Error updating settings:', error);
      res.status(500).json({ error: 'Failed to update settings' });
    }
  });

  // Guardrails endpoints (mode-isolated)
  app.get('/api/guardrails', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = req.query.mode as 'live' | 'paper';

      if (!mode || (mode !== 'live' && mode !== 'paper')) {
        return res.status(400).json({ error: 'Mode parameter is required and must be "live" or "paper"' });
      }

      let guardrailsData = await storage.getGuardrails({ userId, mode });

      if (!guardrailsData) {
        // Return defaults if not found
        guardrailsData = {
          id: '',
          userId,
          mode,
          maxDailyLoss: '1000.00',
          maxDrawdown: '10.00',
          maxPositionSize: '5000.00',
          maxOpenPositions: 5,
          riskPerTrade: '1.5',
          aiCanAdjust: false,
          createdAt: new Date(),
          updatedAt: new Date()
        };
      }

      res.json(guardrailsData);
    } catch (error) {
      console.error('Error fetching guardrails:', error);
      res.status(500).json({ error: 'Failed to fetch guardrails' });
    }
  });

  app.put('/api/guardrails', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = req.query.mode as 'live' | 'paper';

      if (!mode || (mode !== 'live' && mode !== 'paper')) {
        return res.status(400).json({ error: 'Mode parameter is required and must be "live" or "paper"' });
      }

      const validatedData = insertGuardrailsSchema.parse({ ...req.body, userId, mode });
      const guardrailsData = await storage.upsertGuardrails(validatedData);

      console.info(`[Guardrails] User ${userId} updated guardrails for ${mode} mode`);

      res.json(guardrailsData);
    } catch (error) {
      console.error('Error updating guardrails:', error);
      res.status(500).json({ error: 'Failed to update guardrails' });
    }
  });

  // Screener filters endpoints (mode-isolated)
  app.get('/api/screeners', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = req.query.mode as 'live' | 'paper';

      if (!mode || (mode !== 'live' && mode !== 'paper')) {
        return res.status(400).json({ error: 'Mode parameter is required and must be "live" or "paper"' });
      }

      let screenerData = await storage.getScreenerFilters({ userId, mode });

      if (!screenerData) {
        // Return defaults if not found
        screenerData = {
          id: '',
          userId,
          mode,
          minVolume: '1000000.00',
          minPrice: '0.01',
          maxPrice: '10000.00',
          minMarketCap: '100000000.00',
          maxBidAskSpread: '1.00',
          rsiMin: 30,
          rsiMax: 70,
          volatilityMin: '0.50',
          volatilityMax: '5.00',
          excludeStablecoins: true,
          minLiquidity: '500000.00',
          allowRegulatedOnly: false,
          createdAt: new Date(),
          updatedAt: new Date()
        };
      }

      res.json(screenerData);
    } catch (error) {
      console.error('Error fetching screener filters:', error);
      res.status(500).json({ error: 'Failed to fetch screener filters' });
    }
  });

  app.put('/api/screeners', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = req.query.mode as 'live' | 'paper';

      if (!mode || (mode !== 'live' && mode !== 'paper')) {
        return res.status(400).json({ error: 'Mode parameter is required and must be "live" or "paper"' });
      }

      const validatedData = insertScreenerFiltersSchema.parse({ ...req.body, userId, mode });
      const screenerData = await storage.upsertScreenerFilters(validatedData);

      console.info(`[Screeners] User ${userId} updated screener filters for ${mode} mode`);

      res.json(screenerData);
    } catch (error) {
      console.error('Error updating screener filters:', error);
      res.status(500).json({ error: 'Failed to update screener filters' });
    }
  });

  // Trading Engine Control
  app.post('/api/trading/start', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { mode } = req.body; // 'live' or 'paper'
      
      // Get API credentials from environment secrets only
      const apiKey = process.env.KRAKEN_API_KEY;
      const apiSecret = process.env.KRAKEN_API_SECRET;
      
      // Validate credentials are present before starting
      if (!apiKey || !apiSecret) {
        return res.status(400).json({ 
          error: 'Kraken API credentials not configured',
          message: 'Please add KRAKEN_API_KEY and KRAKEN_API_SECRET to Replit Secrets before starting trading.'
        });
      }
      
      let engine = tradingEngines.get(userId);
      if (!engine) {
        engine = new TradingEngine(userId, apiKey, apiSecret);
        tradingEngines.set(userId, engine);
      }
      
      await engine.start();
      await storage.updateUser(userId, { tradingStatus: 'active', tradingMode: mode });
      
      res.json({ status: 'started', mode });
    } catch (error) {
      console.error('Error starting trading:', error);
      res.status(500).json({ error: 'Failed to start trading' });
    }
  });

  app.post('/api/trading/stop', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      
      const engine = tradingEngines.get(userId);
      if (engine) {
        await engine.stop();
      }
      
      await storage.updateUser(userId, { tradingStatus: 'stopped' });
      
      res.json({ status: 'stopped' });
    } catch (error) {
      console.error('Error stopping trading:', error);
      res.status(500).json({ error: 'Failed to stop trading' });
    }
  });

  app.get('/api/trading/status', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const user = await storage.getUser(userId);
      const engine = tradingEngines.get(userId);
      
      res.json({
        tradingStatus: user?.tradingStatus || 'stopped',
        tradingMode: user?.tradingMode || 'paper',
        engineRunning: engine?.isEngineRunning() || false
      });
    } catch (error) {
      console.error('Error getting trading status:', error);
      res.status(500).json({ error: 'Failed to get trading status' });
    }
  });

  // Portfolio and Metrics
  app.get('/api/portfolio/overview', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      
      const liveBalance = await riskManager.getLiveKrakenBalance(userId);
      const metrics = await riskManager.getPortfolioMetrics(userId);
      const cashCrypto = await riskManager.getCashVsCrypto(userId);
      const winRateData = await riskManager.getWinRate(userId, 30);
      
      res.json({
        totalValue: liveBalance.totalValueUSD,
        unrealizedPL: metrics.unrealizedPL,
        realizedPL: metrics.realizedPL,
        currentExposure: metrics.currentExposure,
        openTradesCount: metrics.openTradesCount,
        ...winRateData,
        cash: liveBalance.cashUSD,
        crypto: liveBalance.cryptoUSD,
        cashPercent: liveBalance.totalValueUSD > 0 ? (liveBalance.cashUSD / liveBalance.totalValueUSD) * 100 : 0,
        cryptoPercent: liveBalance.totalValueUSD > 0 ? (liveBalance.cryptoUSD / liveBalance.totalValueUSD) * 100 : 0,
        syncTimestamp: liveBalance.syncTimestamp,
        balanceSource: liveBalance.source,
        balanceError: liveBalance.error
      });
    } catch (error) {
      console.error('Error fetching portfolio overview:', error);
      res.status(500).json({ error: 'Failed to fetch portfolio data' });
    }
  });

  app.get('/api/portfolio/earnings', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const earnings = await riskManager.getEarnings(userId);
      res.json(earnings);
    } catch (error) {
      console.error('Error fetching earnings:', error);
      res.status(500).json({ error: 'Failed to fetch earnings data' });
    }
  });

  app.get('/api/portfolio/earnings-chart', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const days = parseInt(req.query.days as string) || 30;
      const chartData = await riskManager.getEarningsChartData(userId, days);
      res.json(chartData);
    } catch (error) {
      console.error('Error fetching earnings chart data:', error);
      res.status(500).json({ error: 'Failed to fetch earnings chart data' });
    }
  });

  app.get('/api/portfolio/history', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const period = (req.query.period as string) || '1M';
      
      const initialBalance = 50000;
      
      const now = new Date();
      let startDate = new Date();
      
      switch (period) {
        case '7D':
          startDate.setDate(now.getDate() - 7);
          break;
        case '1M':
          startDate.setMonth(now.getMonth() - 1);
          break;
        case '3M':
          startDate.setMonth(now.getMonth() - 3);
          break;
        case 'YTD':
          startDate = new Date(now.getFullYear(), 0, 1);
          break;
        case 'ALL':
          startDate = new Date(now.getFullYear() - 2, 0, 1);
          break;
      }
      
      const allTrades = await storage.getTrades(userId, {});
      const closedTrades = allTrades.filter(t => 
        t.status === 'closed' && 
        t.exitTime
      ).sort((a, b) => 
        new Date(a.exitTime!).getTime() - new Date(b.exitTime!).getTime()
      );
      
      let portfolioValueAtStart = initialBalance;
      const tradesInPeriod: typeof closedTrades = [];
      
      closedTrades.forEach(trade => {
        const tradeDate = new Date(trade.exitTime!);
        if (tradeDate < startDate) {
          portfolioValueAtStart += Number(trade.realizedPL) || 0;
        } else {
          tradesInPeriod.push(trade);
        }
      });
      
      const dataPoints: Array<{ date: string; value: number; timestamp: number }> = [];
      let currentValue = portfolioValueAtStart;
      
      dataPoints.push({
        date: startDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        value: portfolioValueAtStart,
        timestamp: startDate.getTime()
      });
      
      tradesInPeriod.forEach(trade => {
        if (trade.realizedPL) {
          currentValue += Number(trade.realizedPL);
          dataPoints.push({
            date: new Date(trade.exitTime!).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
            value: currentValue,
            timestamp: new Date(trade.exitTime!).getTime()
          });
        }
      });
      
      if (dataPoints.length === 1 || (dataPoints.length > 1 && new Date(dataPoints[dataPoints.length - 1].timestamp).getTime() < now.getTime() - 86400000)) {
        dataPoints.push({
          date: now.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
          value: currentValue,
          timestamp: now.getTime()
        });
      }
      
      res.json(dataPoints);
    } catch (error) {
      console.error('Error fetching portfolio history:', error);
      res.status(500).json({ error: 'Failed to fetch portfolio history' });
    }
  });

  app.get('/api/portfolio/value-history', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const period = (req.query.period as string) || '30d';
      
      const initialBalance = 50000;
      
      const now = new Date();
      let startDate = new Date();
      
      switch (period) {
        case '30d':
          startDate.setDate(now.getDate() - 30);
          break;
        case '90d':
          startDate.setDate(now.getDate() - 90);
          break;
        case '1y':
          startDate.setFullYear(now.getFullYear() - 1);
          break;
        case 'all':
          startDate = new Date(now.getFullYear() - 2, 0, 1);
          break;
      }
      
      const allTrades = await storage.getTrades(userId, {});
      const closedTrades = allTrades.filter(t => 
        t.status === 'closed' && 
        t.exitTime
      ).sort((a, b) => 
        new Date(a.exitTime!).getTime() - new Date(b.exitTime!).getTime()
      );
      
      let portfolioValueAtStart = initialBalance;
      const tradesInPeriod: typeof closedTrades = [];
      
      closedTrades.forEach(trade => {
        const tradeDate = new Date(trade.exitTime!);
        if (tradeDate < startDate) {
          portfolioValueAtStart += Number(trade.realizedPL) || 0;
        } else {
          tradesInPeriod.push(trade);
        }
      });
      
      const dataPoints: Array<{ date: string; value: number }> = [];
      let currentValue = portfolioValueAtStart;
      
      dataPoints.push({
        date: startDate.toISOString(),
        value: portfolioValueAtStart
      });
      
      tradesInPeriod.forEach(trade => {
        if (trade.realizedPL) {
          currentValue += Number(trade.realizedPL);
          dataPoints.push({
            date: trade.exitTime!,
            value: currentValue
          });
        }
      });
      
      if (dataPoints.length === 1 || (dataPoints.length > 1 && new Date(dataPoints[dataPoints.length - 1].date).getTime() < now.getTime() - 86400000)) {
        dataPoints.push({
          date: now.toISOString(),
          value: currentValue
        });
      }
      
      res.json(dataPoints);
    } catch (error) {
      console.error('Error fetching portfolio value history:', error);
      res.status(500).json({ error: 'Failed to fetch portfolio value history' });
    }
  });

  app.get('/api/portfolio/stats', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      
      const initialBalance = 50000;
      
      const allTrades = await storage.getTrades(userId, {});
      const closedTrades = allTrades.filter(t => t.status === 'closed' && t.exitTime);
      
      const totalProfitLoss = closedTrades.reduce((sum, t) => sum + (Number(t.realizedPL) || 0), 0);
      const currentValue = initialBalance + totalProfitLoss;
      
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      
      const tradesLast24h = closedTrades.filter(t => 
        t.exitTime && new Date(t.exitTime) >= yesterday
      );
      
      const change24h = tradesLast24h.reduce((sum, t) => sum + (Number(t.realizedPL) || 0), 0);
      const valueYesterday = currentValue - change24h;
      const changePercent24h = valueYesterday !== 0 ? (change24h / valueYesterday) * 100 : 0;
      
      const winningTrades = closedTrades.filter(t => (Number(t.realizedPL) || 0) > 0).length;
      const winRate = closedTrades.length > 0 ? (winningTrades / closedTrades.length) * 100 : 0;
      
      res.json({
        currentValue,
        change24h,
        changePercent24h,
        winRate
      });
    } catch (error) {
      console.error('Error fetching portfolio stats:', error);
      res.status(500).json({ error: 'Failed to fetch portfolio stats' });
    }
  });

  // Trades
  app.get('/api/trades', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { status, symbol, strategy, limit } = req.query;
      
      const trades = await storage.getTrades(userId, {
        status: status as string,
        symbol: symbol as string,
        strategy: strategy as string,
        limit: limit ? parseInt(limit as string) : undefined
      });
      
      res.json(trades);
    } catch (error) {
      console.error('Error fetching trades:', error);
      res.status(500).json({ error: 'Failed to fetch trades' });
    }
  });

  app.get('/api/trades/active', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const trades = await storage.getActiveTrades(userId);
      res.json(trades);
    } catch (error) {
      console.error('Error fetching active trades:', error);
      res.status(500).json({ error: 'Failed to fetch active trades' });
    }
  });

  app.post('/api/trades/:id/close', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { id } = req.params;
      
      const engine = tradingEngines.get(userId);
      if (!engine) {
        return res.status(400).json({ error: 'Trading engine not initialized' });
      }
      
      const closedTrade = await engine.closeTrade(id, 'manual');
      res.json(closedTrade);
    } catch (error) {
      console.error('Error closing trade:', error);
      res.status(500).json({ error: 'Failed to close trade' });
    }
  });

  // Watchlist
  app.get('/api/watchlist', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const watchlist = await storage.getWatchlist(userId);
      res.json(watchlist);
    } catch (error) {
      console.error('Error fetching watchlist:', error);
      res.status(500).json({ error: 'Failed to fetch watchlist' });
    }
  });

  app.post('/api/watchlist', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const validatedData = insertWatchlistPairSchema.parse({ ...req.body, userId });
      
      const pair = await storage.addWatchlistPair(validatedData);
      res.json(pair);
    } catch (error) {
      console.error('Error adding to watchlist:', error);
      res.status(500).json({ error: 'Failed to add to watchlist' });
    }
  });

  app.delete('/api/watchlist/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const { id } = req.params;
      await storage.removeWatchlistPair(id);
      res.json({ success: true });
    } catch (error) {
      console.error('Error removing from watchlist:', error);
      res.status(500).json({ error: 'Failed to remove from watchlist' });
    }
  });

  // Market Data
  app.get('/api/market/overview', async (req: AuthenticatedRequest, res) => {
    try {
      const overview = await marketScanner.getMarketOverview();
      res.json(overview);
    } catch (error) {
      console.error('Error fetching market overview:', error);
      res.status(500).json({ error: 'Failed to fetch market overview' });
    }
  });

  app.get('/api/market/ticker/:symbol', async (req: AuthenticatedRequest, res) => {
    try {
      const { symbol } = req.params;
      const kraken = new KrakenService();
      const ticker = await kraken.getTicker(symbol);
      res.json(ticker);
    } catch (error) {
      console.error('Error fetching ticker:', error);
      res.status(500).json({ error: 'Failed to fetch ticker data' });
    }
  });

  // AI Features
  app.get('/api/ai/reports', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { type, limit } = req.query;
      
      const reports = await storage.getAIReports(
        userId, 
        type as string, 
        limit ? parseInt(limit as string) : 10
      );
      
      res.json(reports);
    } catch (error) {
      console.error('Error fetching AI reports:', error);
      res.status(500).json({ error: 'Failed to fetch AI reports' });
    }
  });

  app.post('/api/ai/reports/generate', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { type } = req.body; // 'daily', 'weekly', 'monthly'
      
      let report;
      switch (type) {
        case 'daily':
          report = await aiAnalyst.generateDailyReport(userId);
          break;
        case 'weekly':
          report = await aiAnalyst.generateWeeklyReport(userId);
          break;
        case 'monthly':
          report = await aiAnalyst.generateMonthlyReport(userId);
          break;
        default:
          return res.status(400).json({ error: 'Invalid report type' });
      }
      
      res.json(report);
    } catch (error) {
      console.error('Error generating AI report:', error);
      res.status(500).json({ error: 'Failed to generate AI report' });
    }
  });

  app.post('/api/ai/analyze-symbol', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { symbol } = req.body;
      
      const analysis = await aiAnalyst.analyzeSymbol(symbol, userId);
      res.json(analysis);
    } catch (error) {
      console.error('Error analyzing symbol:', error);
      res.status(500).json({ error: 'Failed to analyze symbol' });
    }
  });

  // Daily Briefs
  app.get('/api/daily-briefs/today', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const today = new Date().toISOString().split('T')[0];
      
      const brief = await storage.getDailyBrief(userId, today);
      res.json(brief || null);
    } catch (error) {
      console.error('Error fetching today\'s brief:', error);
      res.status(500).json({ error: 'Failed to fetch today\'s brief' });
    }
  });

  app.get('/api/daily-briefs', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { status, limit } = req.query;
      
      const briefs = await storage.getDailyBriefs(userId, {
        status: status as string,
        limit: limit ? parseInt(limit as string) : 30
      });
      
      res.json(briefs);
    } catch (error) {
      console.error('Error fetching briefs:', error);
      res.status(500).json({ error: 'Failed to fetch briefs' });
    }
  });

  app.get('/api/daily-briefs/:date', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { date } = req.params;
      
      const brief = await storage.getDailyBrief(userId, date);
      res.json(brief || null);
    } catch (error) {
      console.error('Error fetching brief:', error);
      res.status(500).json({ error: 'Failed to fetch brief' });
    }
  });

  app.post('/api/daily-briefs/update', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      
      await dailyBriefService.updateDailyBrief(userId);
      res.json({ success: true, message: 'Brief updated successfully' });
    } catch (error) {
      console.error('Error updating brief:', error);
      res.status(500).json({ error: 'Failed to update brief' });
    }
  });

  // Paper Trading Routes (Complete data isolation from live trading)
  app.get('/api/paper/trades', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const trades = await storage.getAllPaperTrades(userId);
      res.json(trades);
    } catch (error) {
      console.error('Error fetching paper trades:', error);
      res.status(500).json({ error: 'Failed to fetch paper trades' });
    }
  });

  app.get('/api/paper/trades/open', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const trades = await storage.getOpenPaperTrades(userId);
      res.json(trades);
    } catch (error) {
      console.error('Error fetching open paper trades:', error);
      res.status(500).json({ error: 'Failed to fetch open paper trades' });
    }
  });

  app.delete('/api/paper/trades/clear', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      await storage.deleteAllPaperTrades(userId);
      res.json({ success: true, message: 'All paper trades cleared' });
    } catch (error) {
      console.error('Error clearing paper trades:', error);
      res.status(500).json({ error: 'Failed to clear paper trades' });
    }
  });

  app.get('/api/paper/briefs/today', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const today = new Date().toISOString().split('T')[0];
      
      const brief = await storage.getPaperDailyBrief(userId, today);
      res.json(brief || null);
    } catch (error) {
      console.error('Error fetching today\'s paper brief:', error);
      res.status(500).json({ error: 'Failed to fetch today\'s paper brief' });
    }
  });

  app.get('/api/paper/briefs', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { status, limit } = req.query;
      
      const briefs = await storage.getPaperDailyBriefs(userId, {
        status: status as string,
        limit: limit ? parseInt(limit as string) : 30
      });
      
      res.json(briefs);
    } catch (error) {
      console.error('Error fetching paper briefs:', error);
      res.status(500).json({ error: 'Failed to fetch paper briefs' });
    }
  });

  app.get('/api/paper/metrics', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { PaperMetricsService } = await import('./services/paper-metrics.js');
      const metricsService = new PaperMetricsService(userId);
      
      const [portfolio, winRate, stats, performanceByStrategy, earnings, ade, trend] = await Promise.all([
        metricsService.getPortfolioMetrics(),
        metricsService.getWinRate(30),
        metricsService.getTradeStatistics(),
        metricsService.getPerformanceByStrategy(),
        metricsService.getEarnings(),
        metricsService.getAverageDailyEarnings(),
        metricsService.get7DayEarningsTrend()
      ]);
      
      res.json({
        portfolio,
        winRate,
        stats,
        performanceByStrategy,
        earnings,
        averageDailyEarnings: ade,
        earningsTrend: trend
      });
    } catch (error) {
      console.error('Error fetching paper metrics:', error);
      res.status(500).json({ error: 'Failed to fetch paper metrics' });
    }
  });

  app.get('/api/paper/metrics/portfolio', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { PaperMetricsService } = await import('./services/paper-metrics.js');
      const metricsService = new PaperMetricsService(userId);
      
      const metrics = await metricsService.getPortfolioMetrics();
      res.json(metrics);
    } catch (error) {
      console.error('Error fetching paper portfolio metrics:', error);
      res.status(500).json({ error: 'Failed to fetch paper portfolio metrics' });
    }
  });

  app.get('/api/ai/conversation', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const conversation = await storage.getAIConversation(userId);
      res.json(conversation || { messages: [], context: {} });
    } catch (error) {
      console.error('Error fetching conversation:', error);
      res.status(500).json({ error: 'Failed to fetch conversation' });
    }
  });

  app.post('/api/ai/chat', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { message, context } = req.body;
      
      const result = await aiAnalyst.chatWithAssistant(userId, message, context);
      res.json(result);
    } catch (error) {
      console.error('Error in AI chat:', error);
      res.status(500).json({ error: 'Failed to process AI chat' });
    }
  });

  app.post('/api/ai/settings/apply', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { settingName, newValue, confirmation } = req.body;
      
      const result = await aiAnalyst.applySettingsChange(userId, settingName, newValue, confirmation);
      res.json(result);
    } catch (error) {
      console.error('Error applying settings change:', error);
      res.status(500).json({ error: 'Failed to apply settings change' });
    }
  });

  app.get('/api/ai/audit-logs', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { limit } = req.query;
      
      const logs = await storage.getAuditLogs(userId, limit ? parseInt(limit as string) : 50);
      res.json(logs);
    } catch (error) {
      console.error('Error fetching audit logs:', error);
      res.status(500).json({ error: 'Failed to fetch audit logs' });
    }
  });

  app.get('/api/ai/error-logs', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { resolved, errorType, limit } = req.query;
      
      const filters: any = {};
      if (resolved !== undefined) filters.resolved = resolved === 'true';
      if (errorType) filters.errorType = errorType as string;
      if (limit) filters.limit = parseInt(limit as string);
      
      const logs = await storage.getErrorLogs(userId, filters);
      res.json(logs);
    } catch (error) {
      console.error('Error fetching error logs:', error);
      res.status(500).json({ error: 'Failed to fetch error logs' });
    }
  });

  app.post('/api/ai/diagnose-error', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { errorId } = req.body;
      
      const diagnosis = await aiAnalyst.diagnoseError(errorId, userId);
      res.json(diagnosis);
    } catch (error) {
      console.error('Error diagnosing error:', error);
      res.status(500).json({ error: 'Failed to diagnose error' });
    }
  });

  // AI Conversations - Multiple chats management
  app.get('/api/conversations', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const conversations = await storage.getAIConversations(userId);
      res.json(conversations);
    } catch (error) {
      console.error('Error fetching conversations:', error);
      res.status(500).json({ error: 'Failed to fetch conversations' });
    }
  });

  app.get('/api/conversations/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const { id } = req.params;
      const conversation = await storage.getAIConversationById(id);
      
      if (!conversation) {
        return res.status(404).json({ error: 'Conversation not found' });
      }
      
      res.json(conversation);
    } catch (error) {
      console.error('Error fetching conversation:', error);
      res.status(500).json({ error: 'Failed to fetch conversation' });
    }
  });

  app.post('/api/conversations', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { title } = req.body;
      
      const conversation = await storage.createAIConversation({
        userId,
        title: title || 'New Chat',
        messages: [],
        context: {},
        maxContextMessages: 20
      });
      
      res.json(conversation);
    } catch (error) {
      console.error('Error creating conversation:', error);
      res.status(500).json({ error: 'Failed to create conversation' });
    }
  });

  app.patch('/api/conversations/:id', async (req: AuthenticatedRequest, res) => {
    try {
      const { id } = req.params;
      const { title, maxContextMessages } = req.body;
      
      const updates: Partial<any> = {};
      if (title !== undefined) updates.title = title;
      if (maxContextMessages !== undefined) updates.maxContextMessages = maxContextMessages;
      
      const conversation = await storage.updateAIConversationById(id, updates);
      res.json(conversation);
    } catch (error) {
      console.error('Error updating conversation:', error);
      res.status(500).json({ error: 'Failed to update conversation' });
    }
  });

  app.delete('/api/conversations/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const { id } = req.params;
      await storage.deleteAIConversation(id);
      res.json({ success: true });
    } catch (error) {
      console.error('Error deleting conversation:', error);
      res.status(500).json({ error: 'Failed to delete conversation' });
    }
  });

  app.post('/api/conversations/:id/message', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { id } = req.params;
      const { message, context } = req.body;
      
      const result = await aiAnalyst.chatWithAssistant(userId, message, context, id);
      res.json(result);
    } catch (error) {
      console.error('Error sending message:', error);
      res.status(500).json({ error: 'Failed to send message' });
    }
  });

  // Kill Switch Incident Analysis Conversation
  app.post('/api/kill-switch/create-analysis-chat', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { eventId } = req.body;
      
      // Get kill switch event details
      const event = eventId 
        ? await storage.getKillSwitchEventById(eventId)
        : await storage.getLatestKillSwitchEvent(userId);
      
      if (!event) {
        return res.status(404).json({ error: 'No kill switch event found' });
      }

      // Get settings at time of incident
      const settings = await storage.getTradingSettings(userId);
      if (!settings) {
        return res.status(404).json({ error: 'Settings not found' });
      }

      // Parse closed trades
      let closedTrades: any[] = [];
      if (event.tradesClosed) {
        try {
          const parsed = JSON.parse(event.tradesClosed);
          closedTrades = Array.isArray(parsed) ? parsed : [];
        } catch (error) {
          console.error('Failed to parse tradesClosed:', error);
        }
      }

      // Build incident context
      const incidentContext = {
        eventId: event.id,
        triggeredAt: event.triggeredAt,
        lossPercent: event.lossPercent,
        lossAmount: event.lossAmount,
        accountEquity: event.accountEquity,
        portfolioValue: event.portfolioValue,
        killSwitchLimit: event.killSwitchLimit,
        warningTrigger: event.warningTrigger,
        tradesCount: closedTrades.length,
        closedTrades: closedTrades.map((t: any) => ({
          symbol: t.symbol,
          strategy: t.strategy,
          entryPrice: t.entryPrice,
          exitPrice: t.exitPrice,
          profitLoss: Number(t.realizedPL),
          rMultiple: Number(t.realizedPLR)
        })),
        currentSettings: {
          screener: {
            minVolume: settings.minVolume,
            minDailyRange: settings.minDailyRange,
            minPrice: settings.minPrice
          },
          guardrails: {
            riskPerTrade: settings.riskPerTrade,
            maxExposurePercent: settings.maxExposurePercent,
            maxOpenTrades: settings.maxOpenTrades
          },
          strategies: {
            vwap: {
              timeframe: settings.vwapTimeframe,
              pullbackThreshold: settings.vwapPullbackThreshold,
              volumeMultiplier: settings.vwapVolumeMultiplier
            },
            abcd: {
              minConsolidation: settings.abcdMinConsolidation,
              breakoutThreshold: settings.abcdBreakoutThreshold,
              exitType: settings.abcdExitType
            },
            sma: {
              length: settings.smaLength,
              entryCondition: settings.smaEntryCondition,
              exitCondition: settings.smaExitCondition
            }
          }
        }
      };

      // Create initial message with incident context
      const initialMessage = {
        role: 'user',
        content: `Kill Switch Incident Analysis Request

INCIDENT SUMMARY:
- Triggered: ${new Date(event.triggeredAt).toISOString()}
- Loss: ${event.lossPercent}% ($${event.lossAmount})
- Account Equity (before): $${event.accountEquity}
- Portfolio Value (after): $${event.portfolioValue}
- Kill Switch Limit: ${event.killSwitchLimit}%
- Warning Trigger: ${event.warningTrigger}%

TRADES CLOSED: ${closedTrades.length} positions
${closedTrades.map((t: any, i: number) => `
${i + 1}. ${t.symbol} (${t.strategy})
   Entry: $${t.entryPrice} → Exit: $${t.exitPrice}
   P/L: $${Number(t.realizedPL)} (${Number(t.realizedPLR)}R)`).join('')}

CURRENT SETTINGS SNAPSHOT:
- Screener: Min Volume $${settings.minVolume}, Min Range ${settings.minDailyRange}%
- Guardrails: Risk/Trade $${settings.riskPerTrade}, Max Exposure ${settings.maxExposurePercent}%, Max Trades ${settings.maxOpenTrades}
- Strategies: VWAP (${settings.vwapTimeframe}min, ${settings.vwapPullbackThreshold}% pullback), ABCD (${settings.abcdMinConsolidation} bars, ${settings.abcdBreakoutThreshold}% breakout), SMA (${settings.smaLength} period, ${settings.smaEntryCondition} entry)

Please analyze this kill switch incident and provide:
1. Root cause analysis - What led to these losses?
2. Pattern identification - Were there common factors across losing trades?
3. Settings recommendations - Should I adjust screener filters, guardrails, or strategy parameters?
4. Risk management improvements - How can I prevent this in the future?

Provide specific, actionable recommendations.`,
        timestamp: new Date()
      };

      // Create conversation with incident context
      const conversation = await storage.createAIConversation({
        userId,
        title: `Kill Switch Analysis - ${new Date(event.triggeredAt).toLocaleDateString()}`,
        messages: [initialMessage],
        context: incidentContext,
        maxContextMessages: 20
      });

      res.json({
        success: true,
        conversationId: conversation.id,
        conversation
      });
    } catch (error: any) {
      console.error('Error creating kill switch analysis chat:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Chat cost tracking
  app.get('/api/chat-logs', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { conversationId, limit } = req.query;
      
      const logs = await storage.getChatLogs(
        userId,
        conversationId as string | undefined,
        limit ? parseInt(limit as string) : 50
      );
      res.json(logs);
    } catch (error) {
      console.error('Error fetching chat logs:', error);
      res.status(500).json({ error: 'Failed to fetch chat logs' });
    }
  });

  app.get('/api/chat-costs', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { fromDate, toDate } = req.query;
      
      const summary = await storage.getChatCostSummary(
        userId,
        fromDate ? new Date(fromDate as string) : undefined,
        toDate ? new Date(toDate as string) : undefined
      );
      res.json(summary);
    } catch (error) {
      console.error('Error fetching chat costs:', error);
      res.status(500).json({ error: 'Failed to fetch chat costs' });
    }
  });

  app.post('/api/ai/error-logs/:id/resolve', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const { id } = req.params;
      const { notes } = req.body;
      
      const resolvedLog = await storage.resolveErrorLog(id, notes);
      res.json(resolvedLog);
    } catch (error) {
      console.error('Error resolving error log:', error);
      res.status(500).json({ error: 'Failed to resolve error log' });
    }
  });

  // AI Opportunities routes
  app.get('/api/ai/opportunities', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { status, type, minProbability } = req.query;
      
      const opportunities = await aiOpportunitiesService.getOpportunitiesForUser(userId, {
        status: status as string | undefined,
        type: type as string | undefined,
        minProbability: minProbability ? parseFloat(minProbability as string) : undefined
      });
      
      res.json(opportunities);
    } catch (error) {
      console.error('Error fetching AI opportunities:', error);
      res.status(500).json({ error: 'Failed to fetch opportunities' });
    }
  });

  app.get('/api/ai/opportunities/latest-run', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const latestRun = await aiOpportunitiesService.getLatestRun(userId);
      res.json(latestRun || null);
    } catch (error) {
      console.error('Error fetching latest run:', error);
      res.status(500).json({ error: 'Failed to fetch latest run' });
    }
  });

  app.get('/api/ai/opportunities/validation-report', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const report = await aiOpportunitiesService.getValidationReport(userId);
      res.json(report);
    } catch (error) {
      console.error('Error generating validation report:', error);
      res.status(500).json({ error: 'Failed to generate validation report' });
    }
  });

  app.patch('/api/ai/opportunities/:id/status', async (req: AuthenticatedRequest, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      await aiOpportunitiesService.updateOpportunityStatus(id, status);
      res.json({ success: true });
    } catch (error) {
      console.error('Error updating opportunity status:', error);
      res.status(500).json({ error: 'Failed to update opportunity status' });
    }
  });

  app.post('/api/ai/opportunities/generate', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      
      // Check if feature is enabled for this user
      const settings = await storage.getTradingSettings(userId);
      if (!settings?.aiOpportunitiesEnabled) {
        return res.status(403).json({ error: 'AI Opportunities feature is disabled for this user' });
      }
      
      // Generate for this user only (with cooldown protection)
      await aiOpportunitiesService.generateOpportunitiesForSingleUser(userId);
      
      // Audit log the manual trigger
      await storage.createAuditLog({
        userId,
        actionType: 'manual_opportunity_generation',
        gptResponse: 'User manually triggered AI opportunities generation',
        status: 'completed'
      });
      
      res.json({ success: true, message: 'Opportunity generation started for your account' });
    } catch (error) {
      console.error('Error starting opportunity generation:', error);
      const errorMessage = (error as Error).message || 'Failed to start opportunity generation';
      res.status(429).json({ error: errorMessage }); // 429 for rate limiting
    }
  });

  // Market Context (AI Market Analysis) routes
  app.get('/api/market-context/latest', async (req: AuthenticatedRequest, res) => {
    try {
      const mode = (req.query.mode as string) || 'live';
      
      if (mode !== 'live' && mode !== 'paper') {
        return res.status(400).json({ error: 'Invalid mode. Must be "live" or "paper"' });
      }
      
      const analysis = await storage.getLatestAiMarketAnalysis(mode);
      res.json(analysis || null);
    } catch (error) {
      console.error('Error fetching latest market analysis:', error);
      res.status(500).json({ error: 'Failed to fetch market analysis' });
    }
  });

  app.get('/api/market-context/history', async (req: AuthenticatedRequest, res) => {
    try {
      const mode = (req.query.mode as string) || 'live';
      const days = parseInt(req.query.days as string) || 7;
      
      if (mode !== 'live' && mode !== 'paper') {
        return res.status(400).json({ error: 'Invalid mode. Must be "live" or "paper"' });
      }
      
      const fromDate = new Date();
      fromDate.setDate(fromDate.getDate() - days);
      const toDate = new Date();
      
      const analyses = await storage.getAiMarketAnalysesByRange({
        mode: mode as 'live' | 'paper',
        from: fromDate.toISOString().split('T')[0],
        to: toDate.toISOString().split('T')[0]
      });
      res.json(analyses);
    } catch (error) {
      console.error('Error fetching market analysis history:', error);
      res.status(500).json({ error: 'Failed to fetch market analysis history' });
    }
  });

  app.post('/api/market-context/analyze', async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { mode = 'live' } = req.body;
      
      if (mode !== 'live' && mode !== 'paper') {
        return res.status(400).json({ error: 'Invalid mode. Must be "live" or "paper"' });
      }
      
      // Check if feature is enabled for this user
      const settings = await storage.getTradingSettings(userId);
      if (!settings?.aiOpportunitiesEnabled) {
        return res.status(403).json({ error: 'AI features are disabled for this user' });
      }
      
      // Manually trigger market analysis
      const { runAiMarketAnalysis } = await import('./services/ai-market-analyzer');
      const { adjustSignalWeightsByRegime } = await import('./services/signal-weight-optimizer');
      
      const analysis = await runAiMarketAnalysis(mode);
      
      // Apply regime-based adjustments if confidence is high enough
      if (analysis.confidence && analysis.confidence >= 60) {
        await adjustSignalWeightsByRegime(analysis.regime, mode);
      }
      
      // Audit log the manual trigger
      await storage.createAuditLog({
        userId,
        actionType: 'manual_market_analysis',
        gptResponse: `User manually triggered ${mode} market analysis: ${analysis.regime} (${analysis.confidence}% confidence)`,
        status: 'completed'
      });
      
      res.json({ success: true, analysis });
    } catch (error) {
      console.error('Error running market analysis:', error);
      res.status(500).json({ error: 'Failed to run market analysis' });
    }
  });

  // Stock API routes
  app.get('/api/stocks/quote/:symbol', async (req: AuthenticatedRequest, res) => {
    try {
      const { symbol } = req.params;
      const quote = await stockService.getQuote(symbol);
      res.json(quote);
    } catch (error) {
      console.error('Error fetching stock quote:', error);
      res.status(500).json({ error: 'Failed to fetch stock quote' });
    }
  });

  app.get('/api/stocks/company/:symbol', async (req: AuthenticatedRequest, res) => {
    try {
      const { symbol } = req.params;
      const company = await stockService.getCompanyInfo(symbol);
      res.json(company);
    } catch (error) {
      console.error('Error fetching company info:', error);
      res.status(500).json({ error: 'Failed to fetch company info' });
    }
  });

  app.get('/api/stocks/search/:query', async (req: AuthenticatedRequest, res) => {
    try {
      const { query } = req.params;
      const results = await stockService.search(query);
      res.json(results);
    } catch (error) {
      console.error('Error searching stocks:', error);
      res.status(500).json({ error: 'Failed to search stocks' });
    }
  });

  app.get('/api/symbol/data', async (req: AuthenticatedRequest, res) => {
    try {
      const symbol = (req.query.symbol as string)?.toUpperCase();
      if (!symbol) {
        return res.status(400).json({ error: 'Missing symbol parameter' });
      }

      const data = await stockService.getSymbolData(symbol);
      
      if (!data) {
        return res.status(404).json({ 
          error: `No data found for ${symbol}`,
          retryable: true
        });
      }

      res.json(data);
    } catch (err: any) {
      console.error('Symbol data fetch error:', err);
      res.status(500).json({ 
        error: 'Internal error fetching symbol data',
        message: err.message
      });
    }
  });

  // Test endpoint for Finnhub feed
  app.get('/api/test/finnhub-feed', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const testSymbol = 'AAPL';
      const timestamp = new Date().toISOString();
      
      console.log(`[Test Finnhub Feed] Starting test for ${testSymbol} at ${timestamp}`);
      
      // Test search functionality
      let searchResults: any = null;
      let searchError: string | null = null;
      try {
        searchResults = await stockService.search(testSymbol);
        console.log(`[Test Finnhub Feed] Search results:`, searchResults);
      } catch (error: any) {
        console.error(`[Test Finnhub Feed] Search failed:`, {
          status: error.status || 'unknown',
          message: error.message,
          stack: error.stack
        });
        searchError = error.message;
      }
      
      // Test quote functionality
      let quoteData: any = null;
      let quoteError: string | null = null;
      try {
        quoteData = await stockService.getQuote(testSymbol);
        console.log(`[Test Finnhub Feed] Quote data:`, quoteData);
      } catch (error: any) {
        console.error(`[Test Finnhub Feed] Quote failed:`, {
          status: error.status || 'unknown',
          message: error.message,
          stack: error.stack
        });
        quoteError = error.message;
      }
      
      // Test company profile functionality
      let companyData: any = null;
      let companyError: string | null = null;
      try {
        companyData = await stockService.getCompanyInfo(testSymbol);
        console.log(`[Test Finnhub Feed] Company data:`, companyData);
      } catch (error: any) {
        console.error(`[Test Finnhub Feed] Company info failed:`, {
          status: error.status || 'unknown',
          message: error.message,
          stack: error.stack
        });
        companyError = error.message;
      }
      
      // Return comprehensive test results
      res.json({
        testSymbol,
        timestamp,
        search: searchResults || { error: searchError },
        quote: quoteData || { error: quoteError },
        company: companyData || { error: companyError },
        summary: {
          searchSuccessful: !searchError,
          quoteSuccessful: !quoteError,
          companySuccessful: !companyError,
          allTestsPassed: !searchError && !quoteError && !companyError
        }
      });
    } catch (error: any) {
      console.error('[Test Finnhub Feed] Unexpected error:', {
        message: error.message,
        stack: error.stack
      });
      res.status(500).json({ 
        error: 'Test failed with unexpected error',
        message: error.message,
        timestamp: new Date().toISOString()
      });
    }
  });

  // Crypto search route
  app.get('/api/crypto/search/:query', async (req: AuthenticatedRequest, res) => {
    try {
      const { query } = req.params;
      const normalizedQuery = query.toLowerCase().trim();
      
      // Search through supported crypto symbols and names
      const cryptoList = [
        { symbol: 'BTC', name: 'Bitcoin' },
        { symbol: 'ETH', name: 'Ethereum' },
        { symbol: 'SOL', name: 'Solana' },
        { symbol: 'SUI', name: 'Sui' },
        { symbol: 'ADA', name: 'Cardano' },
        { symbol: 'DOT', name: 'Polkadot' },
        { symbol: 'MATIC', name: 'Polygon' },
        { symbol: 'AVAX', name: 'Avalanche' },
        { symbol: 'LINK', name: 'Chainlink' },
        { symbol: 'UNI', name: 'Uniswap' },
        { symbol: 'ATOM', name: 'Cosmos' },
        { symbol: 'XRP', name: 'XRP' },
        { symbol: 'DOGE', name: 'Dogecoin' },
        { symbol: 'LTC', name: 'Litecoin' },
        { symbol: 'BCH', name: 'Bitcoin Cash' },
        { symbol: 'XLM', name: 'Stellar' },
        { symbol: 'ALGO', name: 'Algorand' },
        { symbol: 'VET', name: 'VeChain' },
        { symbol: 'FIL', name: 'Filecoin' },
        { symbol: 'TRX', name: 'TRON' },
        { symbol: 'ETC', name: 'Ethereum Classic' }
      ];

      const results = cryptoList
        .filter(crypto => 
          crypto.symbol.toLowerCase().includes(normalizedQuery) ||
          crypto.name.toLowerCase().includes(normalizedQuery)
        )
        .slice(0, 5)
        .map(crypto => ({
          symbol: crypto.symbol,
          description: crypto.name,
          type: 'Crypto'
        }));

      res.json(results);
    } catch (error) {
      console.error('Error searching crypto:', error);
      res.status(500).json({ error: 'Failed to search crypto' });
    }
  });

  // Reports Export API
  app.get('/api/reports/export', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { reportType, format, from, to, symbol, strategy, mode } = req.query;
      
      // Fetch all trades for the user
      const allTrades = await storage.getTrades(userId, { 
        status: 'closed',
        limit: 10000 
      });
      
      // Apply filters
      let filteredTrades = allTrades;
      
      // Date range filter
      if (from || to) {
        filteredTrades = filteredTrades.filter(trade => {
          if (!trade.exitTime) return false;
          const exitDate = new Date(trade.exitTime);
          if (from && exitDate < new Date(from as string)) return false;
          if (to && exitDate > new Date(to as string)) return false;
          return true;
        });
      }
      
      // Symbol filter
      if (symbol && symbol !== 'all') {
        filteredTrades = filteredTrades.filter(trade => trade.symbol === symbol);
      }
      
      // Strategy filter
      if (strategy && strategy !== 'all') {
        filteredTrades = filteredTrades.filter(trade => trade.strategy === strategy);
      }
      
      // Mode filter
      if (mode && mode !== 'all') {
        filteredTrades = filteredTrades.filter(trade => trade.mode === mode);
      }
      
      // Generate report based on type
      let csvData = '';
      let filename = 'report.csv';
      
      switch (reportType) {
        case 'tax':
          csvData = generateTaxReport(filteredTrades);
          filename = 'tax-report.csv';
          break;
        case 'performance':
          csvData = generatePerformanceReport(filteredTrades);
          filename = 'performance-report.csv';
          break;
        case 'journal':
          csvData = generateTradeJournalReport(filteredTrades);
          filename = 'trade-journal.csv';
          break;
        case 'fees':
          csvData = generateFeesReport(filteredTrades);
          filename = 'fees-report.csv';
          break;
        case 'pnl-monthly':
          csvData = generatePnLReport(filteredTrades, 'monthly');
          filename = 'pnl-monthly.csv';
          break;
        case 'pnl-quarterly':
          csvData = generatePnLReport(filteredTrades, 'quarterly');
          filename = 'pnl-quarterly.csv';
          break;
        case 'pnl-annual':
          csvData = generatePnLReport(filteredTrades, 'annual');
          filename = 'pnl-annual.csv';
          break;
        case 'custom':
        case 'all-trades':
        default:
          csvData = generateTradeCSV(filteredTrades);
          filename = 'trades.csv';
          break;
      }
      
      if (format === 'pdf') {
        // For now, return CSV with a note that PDF generation is not yet implemented
        // In production, you would use a PDF library here
        res.status(501).json({ error: 'PDF export coming soon. Please use CSV format.' });
        return;
      }
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
      res.send(csvData);
    } catch (error) {
      console.error('Error generating report:', error);
      res.status(500).json({ error: 'Failed to generate report' });
    }
  });

  // Export functionality
  app.get('/api/export/trades', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { from, to, format } = req.query;
      
      const trades = await storage.getTrades(userId, { 
        status: 'closed',
        limit: 10000 
      });
      
      // Filter by date range if provided
      let filteredTrades = trades;
      if (from || to) {
        filteredTrades = trades.filter(trade => {
          if (!trade.exitTime) return false;
          const exitDate = new Date(trade.exitTime);
          
          if (from && exitDate < new Date(from as string)) return false;
          if (to && exitDate > new Date(to as string)) return false;
          
          return true;
        });
      }
      
      if (format === 'csv') {
        const csvData = generateTradeCSV(filteredTrades);
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=trades.csv');
        res.send(csvData);
      } else {
        res.json(filteredTrades);
      }
    } catch (error) {
      console.error('Error exporting trades:', error);
      res.status(500).json({ error: 'Failed to export trades' });
    }
  });

  // Database monitoring
  app.get('/api/database/status', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const currentStatus = await databaseMonitor.checkDatabaseSize();
      const history = await storage.getDatabaseSizeHistory(7); // Last 7 days
      
      res.json({
        current: currentStatus,
        history: history.map(log => ({
          sizeMb: parseFloat(log.sizeMb),
          sizeGb: parseFloat(log.sizeGb),
          checkedAt: log.checkedAt,
        })),
        limits: {
          maxSizeGb: 10,
          warningThresholdGb: 5,
          criticalThresholdGb: 7,
        },
      });
    } catch (error) {
      console.error('Error getting database status:', error);
      res.status(500).json({ error: 'Failed to get database status' });
    }
  });

  // Maintenance mode status
  app.get('/api/maintenance/status', (req, res) => {
    res.json({
      isMaintenanceMode: process.env.MAINTENANCE_MODE === 'true'
    });
  });

  // Screener test endpoint for demonstrating different filter configurations
  app.post('/api/screener/test', async (req: AuthenticatedRequest, res) => {
    try {
      const kraken = new KrakenService();
      const testSettings = req.body || {
        minVolume: '10000000',
        minDailyRange: '3.0',
        minPrice: '0.01',
        maxBidAskSpread: '1.00',
        excludeStablecoins: true,
        allowedTradingPairs: ['USD', 'USDT'],
        blacklistedSymbols: [],
        whitelistedSymbols: [],
        minHistoryDays: 90
      };

      console.log('\n🧪 Screener Test with custom settings:', testSettings);
      const eligiblePairs = await kraken.getEligiblePairs(testSettings);
      
      res.json({
        success: true,
        settings: testSettings,
        eligiblePairs,
        totalEligible: eligiblePairs.length
      });
    } catch (error: any) {
      console.error('Screener test error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Portfolio guardrails test endpoint - simulate multiple signals
  app.post('/api/guardrails/test', async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const settings = await storage.getTradingSettings(userId);
      
      if (!settings) {
        return res.status(404).json({ error: 'Settings not found' });
      }

      console.log('\n🛡️  PORTFOLIO GUARDRAILS TEST');
      console.log('='.repeat(60));
      console.log('Settings:', {
        riskPerTrade: settings.riskPerTrade,
        maxExposure: `${settings.maxExposurePercent}%`,
        maxOpenTrades: settings.maxOpenTrades,
        stopBuffer: `${settings.stopBufferPercent}%`,
        slippageMajors: `${settings.slippageToleranceMajors}%`,
        slippageMidcaps: `${settings.slippageToleranceMidcaps}%`
      });

      const { RiskManager } = await import('./services/risk-manager');
      const { TradingEngine } = await import('./services/trading-engine');
      
      const riskManager = new RiskManager();
      const tradingEngine = new TradingEngine(userId);

      // Simulate 5 different trading signals
      const testSignals = [
        {
          symbol: 'BTCUSD',
          strategy: 'vwap_pullback' as const,
          entryPrice: 65000,
          stopPrice: 64000,
          targetPrice: 67000,
          confidence: 0.85,
          metadata: { vwap: 64500 }
        },
        {
          symbol: 'ETHUSD',
          strategy: 'abcd_long' as const,
          entryPrice: 3500,
          stopPrice: 3400,
          targetPrice: 3700,
          confidence: 0.80,
          metadata: { breakout: true }
        },
        {
          symbol: 'SOLUSD',
          strategy: 'sma_trend_ride' as const,
          entryPrice: 150,
          stopPrice: 145,
          targetPrice: 160,
          confidence: 0.75,
          metadata: { sma: 148 }
        },
        {
          symbol: 'XRPUSD',
          strategy: 'vwap_pullback' as const,
          entryPrice: 2.50,
          stopPrice: 2.40,
          targetPrice: 2.70,
          confidence: 0.70,
          metadata: { vwap: 2.45 }
        },
        {
          symbol: 'ADAUSD',
          strategy: 'sma_trend_ride' as const,
          entryPrice: 0.75,
          stopPrice: 0.70,
          targetPrice: 0.85,
          confidence: 0.65,
          metadata: { sma: 0.73 }
        }
      ];

      const results = [];

      for (let i = 0; i < testSignals.length; i++) {
        const signal = testSignals[i];
        console.log(`\n📊 Signal ${i + 1}/${testSignals.length}: ${signal.symbol} (${signal.strategy})`);
        console.log(`   Entry: $${signal.entryPrice}, Stop: $${signal.stopPrice}, Target: $${signal.targetPrice}`);

        // Check pre-trade risk
        const riskCheck = await riskManager.checkPreTradeRisk(userId, signal, settings);
        
        if (riskCheck.approved) {
          // Calculate position details
          const riskAmount = parseFloat(settings.riskPerTrade || '150');
          const stopDistance = Math.abs(signal.entryPrice - signal.stopPrice);
          const quantity = riskAmount / stopDistance;
          const positionValue = signal.entryPrice * quantity;
          
          // Apply stop buffer
          const stopBuffer = parseFloat(settings.stopBufferPercent || '0.3') / 100;
          const bufferedStop = signal.stopPrice * (1 - stopBuffer);
          
          console.log(`   ✅ APPROVED - Position: ${quantity.toFixed(4)} units ($${positionValue.toFixed(2)})`);
          console.log(`   Stop Buffer Applied: ${signal.stopPrice} → ${bufferedStop.toFixed(6)} (${settings.stopBufferPercent}%)`);
          
          results.push({
            signal: `${signal.symbol} ${signal.strategy}`,
            status: 'APPROVED',
            quantity: quantity.toFixed(4),
            positionValue: positionValue.toFixed(2),
            bufferedStop: bufferedStop.toFixed(6)
          });
        } else {
          console.log(`   ❌ REJECTED - ${riskCheck.reason}`);
          results.push({
            signal: `${signal.symbol} ${signal.strategy}`,
            status: 'REJECTED',
            reason: riskCheck.reason
          });
        }
      }

      // Get current portfolio metrics
      const metrics = await riskManager.getPortfolioMetrics(userId);
      
      console.log('\n📈 Portfolio Metrics:');
      console.log(`   Open Trades: ${metrics.openTradesCount}/${settings.maxOpenTrades}`);
      console.log(`   Current Exposure: $${metrics.currentExposure.toFixed(2)}`);
      console.log(`   Realized P/L: $${metrics.realizedPL.toFixed(2)}`);
      console.log('='.repeat(60));

      res.json({
        success: true,
        guardrails: {
          riskPerTrade: settings.riskPerTrade,
          maxExposure: settings.maxExposurePercent,
          maxOpenTrades: settings.maxOpenTrades,
          stopBuffer: settings.stopBufferPercent,
          slippageTolerance: {
            majors: settings.slippageToleranceMajors,
            midcaps: settings.slippageToleranceMidcaps,
            small: settings.slippageToleranceSmall
          }
        },
        results,
        portfolioMetrics: metrics,
        message: 'Check server logs for detailed guardrail application'
      });
    } catch (error: any) {
      console.error('Guardrails test error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Kill Switch endpoints
  app.get('/api/kill-switch/status', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const settings = await storage.getTradingSettings(userId);
      
      if (!settings) {
        return res.status(404).json({ error: 'Settings not found' });
      }

      const pl24h = await riskManager.calculate24hPL(userId);
      const latestEvent = await storage.getLatestKillSwitchEvent(userId);

      res.json({
        tradingSuspended: settings.tradingSuspended || false,
        dailyLossKillSwitch: settings.dailyLossKillSwitch,
        dailyLossWarningTrigger: settings.dailyLossWarningTrigger,
        current24hPL: pl24h,
        latestEvent
      });
    } catch (error: any) {
      console.error('Kill switch status error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/kill-switch/check', async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const settings = await storage.getTradingSettings(userId);
      
      if (!settings) {
        return res.status(404).json({ error: 'Settings not found' });
      }

      const result = await riskManager.checkKillSwitch(userId, settings);
      
      // Refetch settings to get updated tradingSuspended status
      const updatedSettings = await storage.getTradingSettings(userId);
      
      res.json({
        ...result,
        tradingSuspended: updatedSettings?.tradingSuspended || false
      });
    } catch (error: any) {
      console.error('Kill switch check error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/kill-switch/reset', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { notes } = req.body;
      
      const settings = await storage.getTradingSettings(userId);
      if (!settings) {
        return res.status(404).json({ error: 'Settings not found' });
      }

      if (!settings.tradingSuspended) {
        return res.status(400).json({ error: 'Trading is not suspended' });
      }

      const latestEvent = await storage.getLatestKillSwitchEvent(userId);
      if (latestEvent && !latestEvent.resolved) {
        await storage.resolveKillSwitchEvent(latestEvent.id, 'manual_ui', notes);
      }

      await storage.updateTradingSettings(userId, { tradingSuspended: false });

      console.log(`✅ Kill Switch reset for user ${userId}`);
      
      res.json({
        success: true,
        message: 'Trading resumed. Kill switch has been reset.',
        tradingSuspended: false
      });
    } catch (error: any) {
      console.error('Kill switch reset error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/kill-switch/events', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      
      const events = await storage.getKillSwitchEvents(userId, { limit });
      
      res.json(events);
    } catch (error: any) {
      console.error('Kill switch events error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Test endpoint for simulating kill switch scenarios
  app.post('/api/test/simulate-loss', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { scenario } = req.body; // 'warning', 'kill', or custom loss %
      
      const settings = await storage.getTradingSettings(userId);
      if (!settings) {
        return res.status(404).json({ error: 'Settings not found' });
      }

      const killSwitchPercent = parseFloat(settings.dailyLossKillSwitch || '7.00');
      const warningTriggerPercent = parseFloat(settings.dailyLossWarningTrigger || '75.00');
      
      let targetLossPercent: number;
      
      if (scenario === 'warning') {
        // Set loss to warning threshold (e.g., 75% of 7% = -5.25%)
        targetLossPercent = killSwitchPercent * (warningTriggerPercent / 100);
      } else if (scenario === 'kill') {
        // Set loss to just above kill threshold (e.g., -7.5%)
        targetLossPercent = killSwitchPercent * 1.1;
      } else if (typeof req.body.lossPercent === 'number') {
        // Custom loss percentage
        targetLossPercent = req.body.lossPercent;
      } else {
        return res.status(400).json({ error: 'Invalid scenario. Use "warning", "kill", or provide lossPercent' });
      }

      // Create a simulated losing trade to reach the target loss
      const riskAmount = parseFloat(settings.riskPerTrade || '150');
      const lossAmount = (riskAmount / 0.01) * (targetLossPercent / 100); // Scale up the loss
      
      const simulatedTrade = await storage.createTrade({
        userId,
        symbol: 'BTCUSD',
        strategy: 'vwap_pullback',
        mode: 'paper',
        entryPrice: '50000',
        quantity: (Math.abs(lossAmount) / 50000).toFixed(8),
        stopPrice: '49500',
        targetPrice: '51000',
        status: 'closed',
        exitPrice: (50000 - Math.abs(lossAmount) / (Math.abs(lossAmount) / 50000)).toFixed(2),
        exitTime: new Date(),
        realizedPL: lossAmount.toString(),
        realizedPLR: '-1.0',
        riskAmount: riskAmount.toString(),
        metadata: { test: true, scenario }
      });

      // Check kill switch after creating the losing trade
      const result = await riskManager.checkKillSwitch(userId, settings);
      const updatedSettings = await storage.getTradingSettings(userId);

      res.json({
        success: true,
        simulatedTrade,
        killSwitchResult: result,
        tradingSuspended: updatedSettings?.tradingSuspended || false,
        targetLossPercent,
        actualLossPercent: result.current24hPL
      });
    } catch (error: any) {
      console.error('Test simulate-loss error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Test endpoint to check if trade execution is blocked during suspension
  app.post('/api/test/attempt-trade', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const settings = await storage.getTradingSettings(userId);
      
      if (!settings) {
        return res.status(404).json({ error: 'Settings not found' });
      }

      // Create a test signal
      const testSignal = {
        symbol: 'ETHUSD',
        strategy: 'vwap_pullback' as const,
        entryPrice: 3000,
        stopPrice: 2950,
        targetPrice: 3100,
        confidence: 0.8,
        metadata: { test: true }
      };

      // Run through risk checks
      const riskCheck = await riskManager.checkPreTradeRisk(userId, testSignal, settings);

      res.json({
        tradingSuspended: settings.tradingSuspended,
        riskCheckApproved: riskCheck.approved,
        riskCheckReason: riskCheck.reason,
        testSignal
      });
    } catch (error: any) {
      console.error('Test attempt-trade error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Strategy test endpoint - analyze watchlist pairs for signals
  app.post('/api/strategies/test', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const watchlist = await storage.getWatchlist(userId);
      const settings = await storage.getTradingSettings(userId);
      
      if (!settings) {
        return res.status(404).json({ error: 'Settings not found' });
      }

      console.log(`\n🧪 Testing strategies for ${watchlist.length} watchlist pairs...`);
      console.log(`User settings:`, {
        vwapPullback: settings.vwapPullbackThreshold,
        vwapVolume: settings.vwapVolumeMultiplier,
        abcdBreakout: settings.abcdBreakoutThreshold,
        abcdExitType: settings.abcdExitType,
        smaEntry: settings.smaEntryCondition,
        smaExit: settings.smaExitCondition
      });
      
      const { StrategyEngine } = await import('./services/strategy-engine');
      const strategyEngine = new StrategyEngine();
      const kraken = new KrakenService();
      
      const results = [];
      
      for (const pair of watchlist) {
        console.log(`\n🔍 Analyzing ${pair.symbol} for strategy signals...`);
        
        try {
          const ohlcData = await kraken.getOHLCData(pair.symbol, 60);
          
          if (!ohlcData.ohlc || ohlcData.ohlc.length < 20) {
            results.push({ symbol: pair.symbol, error: 'Insufficient data' });
            continue;
          }

          const priceData = ohlcData.ohlc.map(candle => ({
            symbol: pair.symbol,
            timestamp: new Date(candle.time * 1000),
            open: candle.open,
            high: candle.high,
            low: candle.low,
            close: candle.close,
            volume: candle.volume,
            vwap: candle.vwap,
            sma: '0'
          }));

          const currentPrice = parseFloat(priceData[priceData.length - 1].close);
          const vwap = strategyEngine.calculateVWAP(priceData.slice(-24));
          const sma = strategyEngine.calculateSMA(priceData, parseInt(settings.smaLength?.toString() || '20'));
          
          const indicators = {
            vwap,
            sma,
            currentPrice,
            volume: parseFloat(priceData[priceData.length - 1].volume),
            high24h: Math.max(...priceData.slice(-24).map(p => parseFloat(p.high))),
            low24h: Math.min(...priceData.slice(-24).map(p => parseFloat(p.low)))
          };

          const vwapSignal = strategyEngine.detectVWAPPullback(indicators, settings);
          const abcdSignal = strategyEngine.detectABCDLong(priceData, settings);
          const smaSignal = strategyEngine.detectSMATrendRide(indicators, priceData, settings);

          results.push({
            symbol: pair.symbol,
            analyzed: true,
            signals: {
              vwap: vwapSignal ? 'FOUND' : null,
              abcd: abcdSignal ? 'FOUND' : null,
              sma: smaSignal ? 'FOUND' : null
            }
          });
        } catch (error: any) {
          results.push({ symbol: pair.symbol, error: error.message });
        }
      }
      
      res.json({
        success: true,
        watchlistSize: watchlist.length,
        results,
        message: 'Check server logs for detailed strategy analysis and settings used'
      });
    } catch (error: any) {
      console.error('Strategy test error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // TEST ENDPOINT: Test Kraken credentials
  app.get('/api/test/kraken-balance', authenticateToken, async (_req, res) => {
    try {
      const krakenService = new KrakenService();
      const balances = await krakenService.getAccountBalance();
      
      res.json({ 
        success: true, 
        message: 'Kraken API credentials are valid!',
        balances 
      });
    } catch (error: any) {
      
      res.status(500).json({ 
        success: false, 
        error: error.message 
      });
    }
  });

  // ========================================
  // SYSTEM MONITORING ENDPOINTS
  // ========================================

  // System Health Check
  app.get('/api/system/health', async (_req, res) => {
    try {
      const uptime = process.uptime();
      const status = {
        tradingEngine: 'running',
        aiScheduler: 'active',
        database: 'ok',
        kraken: 'stable',
        uptime: Math.floor(uptime),
        uptimeFormatted: `${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m`,
      };
      res.json({ ok: true, status });
    } catch (error: any) {
      console.error('System health check error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Strategy Settings Audit Log
  app.get('/api/system/strategy-audit', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const limit = parseInt(req.query.limit as string) || 50;
      
      const audits = await storage.listStrategySettingsAudit({ userId, limit });
      res.json({ ok: true, audits });
    } catch (error: any) {
      console.error('Strategy audit fetch error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // System Logs (simple in-memory log - placeholder)
  app.get('/api/system/logs', async (_req, res) => {
    try {
      // For now, return a simple message. In the future, could implement proper log aggregation
      const logs = [
        { timestamp: new Date().toISOString(), level: 'INFO', message: 'System operational' },
        { timestamp: new Date(Date.now() - 60000).toISOString(), level: 'INFO', message: 'Engine heartbeat OK' },
      ];
      res.json({ ok: true, logs });
    } catch (error: any) {
      console.error('System logs fetch error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // AI Audit Log
  app.get('/api/system/ai-audit', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const limit = parseInt(req.query.limit as string) || 50;
      
      const logs = await storage.getAuditLogs(userId, limit);
      res.json({ ok: true, logs });
    } catch (error: any) {
      console.error('AI audit log fetch error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Error Logs
  app.get('/api/system/error-logs', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const limit = parseInt(req.query.limit as string) || 100;
      
      const errors = await storage.getErrorLogs(userId, { limit });
      res.json({ ok: true, errors });
    } catch (error: any) {
      console.error('Error logs fetch error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ENDPOINT: Get Kraken API cache statistics
  app.get('/api/kraken/cache-stats', async (_req, res) => {
    try {
      const krakenService = new KrakenService();
      const stats = krakenService.getCacheStats();
      
      res.json({ 
        success: true, 
        cacheStats: stats,
        config: {
          balanceCacheTTL: '60s',
          openOrdersCacheTTL: '90s',
          closedOrdersCacheTTL: '600s (10 min)',
          rateLimitCooldown: '120s (2 min)'
        }
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        error: error.message 
      });
    }
  });

  // ===== STRATEGY METRICS ROUTES =====

  // Get strategy-level metrics for Live trading
  app.get('/api/metrics/strategies', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const days = parseInt(req.query.days as string) || 7;

      const fromDate = new Date();
      fromDate.setDate(fromDate.getDate() - days);

      const trades = await storage.getTrades(userId, {});
      const recentTrades = trades.filter(t => 
        t.entryTime && new Date(t.entryTime) >= fromDate
      );

      const strategies = ['vwap_pullback', 'abcd_long', 'sma_trend_ride'] as const;
      const strategyMetrics = [];

      for (const strategy of strategies) {
        const strategyTrades = recentTrades.filter(t => t.strategy === strategy);
        const closedTrades = strategyTrades.filter(t => t.status === 'closed');

        const wins = closedTrades.filter(t => parseFloat(t.realizedPL || '0') > 0);
        const winRate = closedTrades.length > 0 ? (wins.length / closedTrades.length) * 100 : 0;

        const totalPL = closedTrades.reduce((sum, t) => sum + parseFloat(t.realizedPL || '0'), 0);
        const avgRMultiple = closedTrades.length > 0
          ? closedTrades.reduce((sum, t) => sum + parseFloat(t.realizedPLR || '0'), 0) / closedTrades.length
          : 0;

        // Get prediction accuracy from Learning Feedback Engine
        const predictionAccuracy = await storage.getPredictionAccuracy(userId, 'live', strategy, days);

        // Get signal weights for this strategy
        const signalWeights = await storage.getSignalWeights(userId, strategy, 'live');

        const weightedConfidence = signalWeights.length > 0
          ? signalWeights.reduce((sum, w) => sum + parseFloat(w.weight), 0) / signalWeights.length
          : 1.0;

        // Calculate 7-day trend (daily P/L)
        const dailyPL: number[] = [];
        for (let i = 0; i < days; i++) {
          const dayStart = new Date();
          dayStart.setDate(dayStart.getDate() - i);
          dayStart.setHours(0, 0, 0, 0);
          const dayEnd = new Date(dayStart);
          dayEnd.setHours(23, 59, 59, 999);

          const dayTrades = closedTrades.filter(t => {
            const exitTime = t.exitTime ? new Date(t.exitTime) : null;
            return exitTime && exitTime >= dayStart && exitTime <= dayEnd;
          });

          const dayTotal = dayTrades.reduce((sum, t) => sum + parseFloat(t.realizedPL || '0'), 0);
          dailyPL.unshift(dayTotal);
        }

        strategyMetrics.push({
          strategy,
          strategyName: strategy.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
          winRate,
          avgRMultiple,
          totalPL,
          predictionAccuracy: predictionAccuracy.accuracy,
          confidence: weightedConfidence,
          totalTrades: strategyTrades.length,
          closedTrades: closedTrades.length,
          openTrades: strategyTrades.length - closedTrades.length,
          dailyPLTrend: dailyPL,
          status: totalPL > 0 ? 'positive' : totalPL < 0 ? 'negative' : 'neutral'
        });
      }

      res.json({
        success: true,
        data: strategyMetrics,
        period: `${days} days`
      });
    } catch (error: any) {
      console.error('Error fetching strategy metrics:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // Get strategy-level metrics for Paper trading
  app.get('/api/paper/metrics/strategies', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const days = parseInt(req.query.days as string) || 7;

      const fromDate = new Date();
      fromDate.setDate(fromDate.getDate() - days);

      const trades = await storage.getAllPaperTrades(userId);
      const recentTrades = trades.filter(t => 
        t.entryTime && new Date(t.entryTime) >= fromDate
      );

      const strategies = ['vwap_pullback', 'abcd_long', 'sma_trend_ride'] as const;
      const strategyMetrics = [];

      for (const strategy of strategies) {
        const strategyTrades = recentTrades.filter(t => t.strategy === strategy);
        const closedTrades = strategyTrades.filter(t => t.status === 'closed');

        const wins = closedTrades.filter(t => parseFloat(t.realizedPL || '0') > 0);
        const winRate = closedTrades.length > 0 ? (wins.length / closedTrades.length) * 100 : 0;

        const totalPL = closedTrades.reduce((sum, t) => sum + parseFloat(t.realizedPL || '0'), 0);
        const avgRMultiple = closedTrades.length > 0
          ? closedTrades.reduce((sum, t) => sum + parseFloat(t.realizedPLR || '0'), 0) / closedTrades.length
          : 0;

        const predictionAccuracy = await storage.getPredictionAccuracy(userId, 'paper', strategy, days);
        const signalWeights = await storage.getSignalWeights(userId, strategy, 'paper');

        const weightedConfidence = signalWeights.length > 0
          ? signalWeights.reduce((sum, w) => sum + parseFloat(w.weight), 0) / signalWeights.length
          : 1.0;

        const dailyPL: number[] = [];
        for (let i = 0; i < days; i++) {
          const dayStart = new Date();
          dayStart.setDate(dayStart.getDate() - i);
          dayStart.setHours(0, 0, 0, 0);
          const dayEnd = new Date(dayStart);
          dayEnd.setHours(23, 59, 59, 999);

          const dayTrades = closedTrades.filter(t => {
            const exitTime = t.exitTime ? new Date(t.exitTime) : null;
            return exitTime && exitTime >= dayStart && exitTime <= dayEnd;
          });

          const dayTotal = dayTrades.reduce((sum, t) => sum + parseFloat(t.realizedPL || '0'), 0);
          dailyPL.unshift(dayTotal);
        }

        strategyMetrics.push({
          strategy,
          strategyName: strategy.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
          winRate,
          avgRMultiple,
          totalPL,
          predictionAccuracy: predictionAccuracy.accuracy,
          confidence: weightedConfidence,
          totalTrades: strategyTrades.length,
          closedTrades: closedTrades.length,
          openTrades: strategyTrades.length - closedTrades.length,
          dailyPLTrend: dailyPL,
          status: totalPL > 0 ? 'positive' : totalPL < 0 ? 'negative' : 'neutral'
        });
      }

      res.json({
        success: true,
        data: strategyMetrics,
        period: `${days} days`
      });
    } catch (error: any) {
      console.error('Error fetching paper strategy metrics:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // Get detailed strategy view
  app.get('/api/metrics/strategies/:strategy/details', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { strategy } = req.params;
      const mode = (req.query.mode as string) || 'live';
      const days = parseInt(req.query.days as string) || 30;

      const fromDate = new Date();
      fromDate.setDate(fromDate.getDate() - days);

      const trades = mode === 'live'
        ? await storage.getTrades(userId, { strategy })
        : await storage.getAllPaperTrades(userId);
      const recentTrades = trades.filter(t => 
        t.entryTime && new Date(t.entryTime) >= fromDate && t.strategy === strategy
      );

      const closedTrades = recentTrades.filter(t => t.status === 'closed');

      // Overview metrics
      const wins = closedTrades.filter(t => parseFloat(t.realizedPL || '0') > 0);
      const winRate = closedTrades.length > 0 ? (wins.length / closedTrades.length) * 100 : 0;
      const totalPL = closedTrades.reduce((sum, t) => sum + parseFloat(t.realizedPL || '0'), 0);
      const avgRMultiple = closedTrades.length > 0
        ? closedTrades.reduce((sum, t) => sum + parseFloat(t.realizedPLR || '0'), 0) / closedTrades.length
        : 0;

      const avgHoldingTime = closedTrades.length > 0
        ? closedTrades.reduce((sum, t) => {
            if (t.entryTime && t.exitTime) {
              const diff = new Date(t.exitTime).getTime() - new Date(t.entryTime).getTime();
              return sum + (diff / (1000 * 60 * 60));
            }
            return sum;
          }, 0) / closedTrades.length
        : 0;

      // Signal insights
      const signalWeights = await storage.getSignalWeights(userId, strategy, mode);

      // Prediction diagnostics (confusion matrix)
      const predictionOutcomes = await storage.getPredictionOutcomes(userId, {
        mode,
        strategy,
        fromDate,
        limit: 1000
      });

      const completed = predictionOutcomes.filter(p => p.completedAt);
      const predictedLongCorrect = completed.filter(p => p.predictedDirection === 'long' && p.correct).length;
      const predictedLongIncorrect = completed.filter(p => p.predictedDirection === 'long' && !p.correct).length;
      const predictedShortCorrect = completed.filter(p => p.predictedDirection === 'short' && p.correct).length;
      const predictedShortIncorrect = completed.filter(p => p.predictedDirection === 'short' && !p.correct).length;
      const predictedNeutralCorrect = completed.filter(p => p.predictedDirection === 'neutral' && p.correct).length;
      const predictedNeutralIncorrect = completed.filter(p => p.predictedDirection === 'neutral' && !p.correct).length;

      // Equity curve
      const equityCurve: Array<{ date: string; value: number }> = [];
      let runningPL = 0;
      const sortedTrades = closedTrades.sort((a, b) => 
        new Date(a.exitTime!).getTime() - new Date(b.exitTime!).getTime()
      );

      for (const trade of sortedTrades) {
        runningPL += parseFloat(trade.realizedPL || '0');
        equityCurve.push({
          date: new Date(trade.exitTime!).toISOString(),
          value: runningPL
        });
      }

      res.json({
        success: true,
        data: {
          overview: {
            totalTrades: recentTrades.length,
            closedTrades: closedTrades.length,
            openTrades: recentTrades.length - closedTrades.length,
            winRate,
            avgRMultiple,
            avgHoldingTime,
            totalPL
          },
          signalInsights: signalWeights.map(w => ({
            signalType: w.signalType,
            weight: parseFloat(w.weight),
            lastUpdated: w.lastUpdated,
            trend: parseFloat(w.weight) > 1.1 ? 'up' : parseFloat(w.weight) < 0.9 ? 'down' : 'stable'
          })),
          predictionDiagnostics: {
            long: { correct: predictedLongCorrect, incorrect: predictedLongIncorrect },
            short: { correct: predictedShortCorrect, incorrect: predictedShortIncorrect },
            neutral: { correct: predictedNeutralCorrect, incorrect: predictedNeutralIncorrect },
            totalPredictions: completed.length,
            accuracy: completed.length > 0 ? (completed.filter(p => p.correct).length / completed.length) * 100 : 0
          },
          equityCurve
        }
      });
    } catch (error: any) {
      console.error('Error fetching strategy details:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // ===== LEARNING FEEDBACK ENGINE ROUTES =====

  // Get prediction accuracy metrics
  app.get('/api/learning/prediction-accuracy', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = (req.query.mode as string) || 'paper';
      const strategy = req.query.strategy as string;
      const days = parseInt(req.query.days as string) || 30;

      const accuracy = await storage.getPredictionAccuracy(userId, mode, strategy, days);
      
      res.json({
        success: true,
        data: accuracy,
        period: `${days} days`,
        mode,
        strategy: strategy || 'all'
      });
    } catch (error: any) {
      console.error('Error fetching prediction accuracy:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // Get signal weight insights
  app.get('/api/learning/signal-insights', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = (req.query.mode as string) || 'paper';

      const { signalWeightOptimizerService } = await import('./services/signal-weight-optimizer');
      const insights = await signalWeightOptimizerService.getWeightInsights(userId, mode);
      
      res.json({
        success: true,
        data: insights,
        mode
      });
    } catch (error: any) {
      console.error('Error fetching signal insights:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // Get signal weights
  app.get('/api/learning/signal-weights', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const strategy = req.query.strategy as string;
      const mode = req.query.mode as string;

      const weights = await storage.getSignalWeights(userId, strategy, mode);
      
      res.json({
        success: true,
        data: weights,
        count: weights.length
      });
    } catch (error: any) {
      console.error('Error fetching signal weights:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // Get prediction outcomes
  app.get('/api/learning/prediction-outcomes', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = req.query.mode as string;
      const strategy = req.query.strategy as string;
      const limit = parseInt(req.query.limit as string) || 50;
      
      const fromDate = req.query.fromDate ? new Date(req.query.fromDate as string) : undefined;
      const toDate = req.query.toDate ? new Date(req.query.toDate as string) : undefined;

      const outcomes = await storage.getPredictionOutcomes(userId, {
        mode,
        strategy,
        fromDate,
        toDate,
        limit
      });
      
      res.json({
        success: true,
        data: outcomes,
        count: outcomes.length
      });
    } catch (error: any) {
      console.error('Error fetching prediction outcomes:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // Get enriched features for a symbol
  app.get('/api/learning/features/:symbol', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const { symbol } = req.params;
      const { featureEnrichmentService } = await import('./services/feature-enrichment');
      
      const features = await featureEnrichmentService.enrichFeatures(symbol);
      
      res.json({
        success: true,
        data: features
      });
    } catch (error: any) {
      console.error('Error fetching enriched features:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // Trigger manual signal weight optimization
  app.post('/api/learning/optimize-weights', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = (req.body.mode as string) || 'paper';

      const { signalWeightOptimizerService } = await import('./services/signal-weight-optimizer');
      await signalWeightOptimizerService.optimizeUserWeights(userId, mode);
      
      res.json({
        success: true,
        message: `Signal weights optimized for ${mode} mode`
      });
    } catch (error: any) {
      console.error('Error optimizing signal weights:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // ===== GOALS ENGINE ROUTES =====

  // Get goals summary (mode-aware)
  app.get('/api/goals/summary', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = (req.query.mode as string) || 'live';

      const goals = mode === 'live' 
        ? await storage.getUserGoalsLive(userId)
        : await storage.getUserGoalsPaper(userId);

      res.json({ success: true, data: goals, mode });
    } catch (error: any) {
      console.error('Error fetching goals summary:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // Update goals (mode-aware)
  app.post('/api/goals/update', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { goals, mode = 'live' } = req.body;

      const updatedGoals = [];
      
      for (const goal of goals) {
        const goalData = {
          userId,
          metricName: goal.metricName,
          goalValue: goal.goalValue,
          actualValue: goal.actualValue,
          percentAchieved: goal.percentAchieved,
          aiValidationNotes: goal.aiValidationNotes,
        };

        const result = mode === 'live'
          ? await storage.upsertGoalLive(goalData)
          : await storage.upsertGoalPaper(goalData);
        
        updatedGoals.push(result);
      }

      res.json({ success: true, data: updatedGoals, mode });
    } catch (error: any) {
      console.error('Error updating goals:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // Analyze goals with AI (conversational goal-setting)
  app.post('/api/goals/analyze', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { userMessage, mode = 'live' } = req.body;

      const settings = await storage.getTradingSettings(userId);
      if (!settings) {
        return res.status(404).json({ success: false, error: 'Trading settings not found' });
      }

      const currentGoals = mode === 'live'
        ? await storage.getUserGoalsLive(userId)
        : await storage.getUserGoalsPaper(userId);

      const trades = mode === 'live'
        ? await storage.getTrades(userId, {})
        : await storage.getAllPaperTrades(userId);
      const closedTrades = trades.filter(t => t.status === 'closed');
      
      const totalPL = closedTrades.reduce((sum, t) => sum + parseFloat(t.realizedPL || '0'), 0);
      const avgPLPerTrade = closedTrades.length > 0 ? totalPL / closedTrades.length : 0;
      const winRate = closedTrades.length > 0 
        ? (closedTrades.filter(t => parseFloat(t.realizedPL || '0') > 0).length / closedTrades.length) * 100
        : 0;

      const prompt = `You are an AI trading advisor helping a user set and optimize their trading goals.

Current Trading Context:
- Mode: ${mode}
- Total Closed Trades: ${closedTrades.length}
- Total P/L: $${totalPL.toFixed(2)}
- Average P/L per Trade: $${avgPLPerTrade.toFixed(2)}
- Win Rate: ${winRate.toFixed(1)}%
- Risk per Trade: $${settings.riskPerTrade}
- Max Open Trades: ${settings.maxOpenTrades}

Current Goals:
${currentGoals.map(g => `- ${g.metricName}: Target $${g.goalValue}, Current $${g.actualValue}, ${g.percentAchieved}% achieved`).join('\n') || 'No goals set'}

User Request: "${userMessage}"

Please:
1. Evaluate the feasibility of the user's request based on current performance and risk parameters
2. Propose specific numeric goals that are achievable but challenging
3. Suggest specific strategy or guardrail adjustments to help achieve these goals
4. Provide a feasibility score (0-100)
5. Format your response as JSON with:
   - aiResponse: string (your explanation)
   - goalsProposed: array of { metricName, goalValue }
   - configChangesProposed: object with suggested parameter changes
   - feasibilityScore: number`;

      const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
      
      const completion = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        response_format: { type: 'json_object' },
      });

      const aiAnalysis = JSON.parse(completion.choices[0].message.content || '{}');

      const analysisRecord = {
        userId,
        userMessage,
        aiResponse: aiAnalysis.aiResponse,
        goalsProposed: aiAnalysis.goalsProposed,
        configChangesProposed: aiAnalysis.configChangesProposed,
        feasibilityScore: aiAnalysis.feasibilityScore?.toString(),
      };

      await (mode === 'live' 
        ? storage.createGoalAnalysisLive(analysisRecord)
        : storage.createGoalAnalysisPaper(analysisRecord));

      res.json({ success: true, data: aiAnalysis, mode });
    } catch (error: any) {
      console.error('Error analyzing goals:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // Apply goals and configuration changes
  app.post('/api/goals/apply', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const { goals, configChanges, analysisId, mode = 'live' } = req.body;

      const updatedGoals = [];
      
      for (const goal of goals) {
        const goalData = {
          userId,
          metricName: goal.metricName,
          goalValue: goal.goalValue,
          actualValue: '0',
          percentAchieved: '0',
          aiValidationNotes: 'AI-validated and applied',
        };

        const result = mode === 'live'
          ? await storage.upsertGoalLive(goalData)
          : await storage.upsertGoalPaper(goalData);
        
        updatedGoals.push(result);
      }

      if (configChanges && Object.keys(configChanges).length > 0) {
        await storage.updateTradingSettings(userId, configChanges);
      }

      res.json({ 
        success: true, 
        data: { 
          goals: updatedGoals, 
          configApplied: configChanges 
        }, 
        mode 
      });
    } catch (error: any) {
      console.error('Error applying goals:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // ===== TRADING ACTIVITY ROUTE =====

  app.get('/api/trading/activity', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = (req.query.mode as string) || 'live';
      const period = (req.query.period as string) || '1d';

      const periodMap: { [key: string]: number } = {
        '1d': 1,
        '1w': 7,
        '1m': 30,
        '3m': 90,
        '6m': 180,
        '1y': 365,
      };

      const days = periodMap[period] || 1;
      const fromDate = new Date();
      fromDate.setDate(fromDate.getDate() - days);

      const trades = mode === 'live'
        ? await storage.getTrades(userId, {})
        : await storage.getAllPaperTrades(userId);
      const periodTrades = trades.filter(t => 
        t.entryTime && new Date(t.entryTime) >= fromDate && t.status === 'closed'
      );

      const profitableTrades = periodTrades.filter(t => parseFloat(t.realizedPL || '0') > 0);
      const losingTrades = periodTrades.filter(t => parseFloat(t.realizedPL || '0') < 0);

      const totalProfits = profitableTrades.reduce((sum, t) => sum + parseFloat(t.realizedPL || '0'), 0);
      const totalLosses = Math.abs(losingTrades.reduce((sum, t) => sum + parseFloat(t.realizedPL || '0'), 0));
      const totalFees = periodTrades.reduce((sum, t) => 
        sum + parseFloat(t.entryFee || '0') + parseFloat(t.exitFee || '0'), 0
      );

      const avgReturnPercent = profitableTrades.length > 0
        ? profitableTrades.reduce((sum, t) => {
            const entry = parseFloat(t.entryPrice) * parseFloat(t.quantity);
            const pl = parseFloat(t.realizedPL || '0');
            return sum + (pl / entry * 100);
          }, 0) / profitableTrades.length
        : 0;

      const avgLossPercent = losingTrades.length > 0
        ? losingTrades.reduce((sum, t) => {
            const entry = parseFloat(t.entryPrice) * parseFloat(t.quantity);
            const pl = parseFloat(t.realizedPL || '0');
            return sum + (pl / entry * 100);
          }, 0) / losingTrades.length
        : 0;

      res.json({
        numberOfTrades: periodTrades.length,
        profitableTrades: profitableTrades.length,
        totalProfits,
        avgReturnPercent,
        losingTrades: losingTrades.length,
        totalLosses,
        avgLossPercent,
        totalFeesPaid: totalFees,
      });
    } catch (error: any) {
      console.error('Error fetching trading activity:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ===== TRADING AVERAGES ROUTE =====

  app.get('/api/trading/averages', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = (req.query.mode as string) || 'live';
      const period = (req.query.period as string) || '1d';

      const periodMap: { [key: string]: number } = {
        '1d': 1,
        '1w': 7,
        '1m': 30,
        '3m': 90,
        '6m': 180,
        '1y': 365,
      };

      const days = periodMap[period] || 1;
      const fromDate = new Date();
      fromDate.setDate(fromDate.getDate() - days);

      const trades = mode === 'live'
        ? await storage.getTrades(userId, {})
        : await storage.getAllPaperTrades(userId);
      const periodTrades = trades.filter(t => 
        t.entryTime && new Date(t.entryTime) >= fromDate && t.status === 'closed'
      );

      const totalEarnings = periodTrades.reduce((sum, t) => sum + parseFloat(t.realizedPL || '0'), 0);
      const avgDailyEarnings = totalEarnings / days;
      const avgTradesPerDay = periodTrades.length / days;
      const avgEarningsPerTrade = periodTrades.length > 0 ? totalEarnings / periodTrades.length : 0;
      
      const totalInvested = periodTrades.reduce((sum, t) => 
        sum + (parseFloat(t.entryPrice) * parseFloat(t.quantity)), 0
      );
      const avgAmountInvestedPerTrade = periodTrades.length > 0 ? totalInvested / periodTrades.length : 0;

      const totalFees = periodTrades.reduce((sum, t) => 
        sum + parseFloat(t.entryFee || '0') + parseFloat(t.exitFee || '0'), 0
      );
      const avgFeesPerTrade = periodTrades.length > 0 ? totalFees / periodTrades.length : 0;

      const avgReturnPercent = periodTrades.length > 0
        ? periodTrades.reduce((sum, t) => {
            const entry = parseFloat(t.entryPrice) * parseFloat(t.quantity);
            const pl = parseFloat(t.realizedPL || '0');
            return sum + (pl / entry * 100);
          }, 0) / periodTrades.length
        : 0;

      const totalCompletionTime = periodTrades.reduce((sum, t) => {
        if (t.exitTime && t.entryTime) {
          return sum + (new Date(t.exitTime).getTime() - new Date(t.entryTime).getTime());
        }
        return sum;
      }, 0);
      const avgCompletionTimeMs = periodTrades.length > 0 ? totalCompletionTime / periodTrades.length : 0;
      const hours = Math.floor(avgCompletionTimeMs / (1000 * 60 * 60));
      const minutes = Math.floor((avgCompletionTimeMs % (1000 * 60 * 60)) / (1000 * 60));
      const avgTradeCompletionTime = `${hours}h ${minutes}m`;

      res.json({
        avgDailyEarnings,
        avgTradesPerDay,
        avgEarningsPerTrade,
        avgAmountInvestedPerTrade,
        avgFeesPerTrade,
        avgReturnPercent,
        avgTradeCompletionTime,
      });
    } catch (error: any) {
      console.error('Error fetching trading averages:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ===== TRADING RESULTS ROUTE =====

  app.get('/api/trading/results', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = (req.query.mode as string) || 'live';
      const period = (req.query.period as string) || '1d';

      const periodMap: { [key: string]: number } = {
        '1d': 1,
        '1w': 7,
        '1m': 30,
        '60d': 60,
        '90d': 90,
        '1y': 365,
      };

      const days = periodMap[period] || 1;
      const fromDate = new Date();
      fromDate.setDate(fromDate.getDate() - days);

      const trades = mode === 'live'
        ? await storage.getTrades(userId, {})
        : await storage.getAllPaperTrades(userId);
      const periodTrades = trades.filter(t => 
        t.exitTime && new Date(t.exitTime) >= fromDate && t.status === 'closed'
      );

      const profitableTrades = periodTrades.filter(t => parseFloat(t.realizedPL || '0') > 0);
      const losingTrades = periodTrades.filter(t => parseFloat(t.realizedPL || '0') < 0);
      
      const totalProfits = profitableTrades.reduce((sum, t) => sum + parseFloat(t.realizedPL || '0'), 0);
      const totalLosses = losingTrades.reduce((sum, t) => sum + parseFloat(t.realizedPL || '0'), 0);
      const totalPnL = totalProfits + totalLosses;
      
      const profitFactor = Math.abs(totalLosses) > 0 ? totalProfits / Math.abs(totalLosses) : 0;

      const avgReturnPercent = periodTrades.length > 0
        ? periodTrades.reduce((sum, t) => {
            const entry = parseFloat(t.entryPrice) * parseFloat(t.quantity);
            const pl = parseFloat(t.realizedPL || '0');
            return sum + (pl / entry * 100);
          }, 0) / periodTrades.length
        : 0;

      let maxDrawdown = 0;
      if (periodTrades.length > 0) {
        const sortedTrades = [...periodTrades].sort((a, b) => 
          new Date(a.exitTime || 0).getTime() - new Date(b.exitTime || 0).getTime()
        );
        
        let runningPL = 0;
        let peak = 0;
        
        for (const trade of sortedTrades) {
          runningPL += parseFloat(trade.realizedPL || '0');
          if (runningPL > peak) {
            peak = runningPL;
          }
          const drawdown = peak - runningPL;
          if (drawdown > maxDrawdown) {
            maxDrawdown = drawdown;
          }
        }
        
        if (peak > 0) {
          maxDrawdown = (maxDrawdown / peak) * 100;
        }
      }

      res.json({
        totalPnL,
        profitFactor,
        maxDrawdown,
        avgReturnPercent,
      });
    } catch (error: any) {
      console.error('Error fetching trading results:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ===== EARNINGS SUMMARY ROUTE =====

  // Get earnings summary for Earnings widget
  app.get('/api/earnings/summary', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = (req.query.mode as string) || 'live';

      const trades = mode === 'live'
        ? await storage.getTrades(userId, {})
        : await storage.getAllPaperTrades(userId);
      const closedTrades = trades.filter(t => t.status === 'closed' && t.exitTime);

      const now = new Date();
      const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const weekStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      const yearStart = new Date(now.getFullYear(), 0, 1);

      const calculateEarnings = (fromDate: Date) => {
        return closedTrades
          .filter(t => t.exitTime && new Date(t.exitTime) >= fromDate)
          .reduce((sum, t) => sum + parseFloat(t.realizedPL || '0'), 0);
      };

      const today = calculateEarnings(todayStart);
      const thisWeek = calculateEarnings(weekStart);
      const thisMonth = calculateEarnings(monthStart);
      const thisYear = calculateEarnings(yearStart);
      const allTime = closedTrades.reduce((sum, t) => sum + parseFloat(t.realizedPL || '0'), 0);

      const firstTradeDate = closedTrades.length > 0 
        ? new Date(Math.min(...closedTrades.map(t => new Date(t.exitTime!).getTime())))
        : now;
      const daysSinceStart = Math.max(1, Math.ceil((now.getTime() - firstTradeDate.getTime()) / (24 * 60 * 60 * 1000)));
      const avgDailyEarnings = allTime / daysSinceStart;
      const avgDailyEarningsStatus = closedTrades.length < 5 ? 'insufficient_data' : 'ok';

      res.json({
        today,
        thisWeek,
        thisMonth,
        thisYear,
        allTime,
        avgDailyEarnings,
        avgDailyEarningsStatus,
      });
    } catch (error: any) {
      console.error('Error fetching earnings summary:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // Strategy Settings Routes
  
  // GET current settings for a specific strategy
  app.get('/api/strategies/settings', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = (String(req.query.mode) === 'paper' ? 'paper' : 'live') as 'live' | 'paper';
      const strategy = String(req.query.strategy);
      
      const row = await storage.getStrategySettings({ userId, mode, strategy });
      return res.json(row ?? {});
    } catch (error: any) {
      console.error('Error fetching strategy settings:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // GET all settings for a mode
  app.get('/api/strategies/settings/all', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = (String(req.query.mode) === 'paper' ? 'paper' : 'live') as 'live' | 'paper';
      
      const rows = await storage.listStrategySettings({ userId, mode });
      return res.json(rows);
    } catch (error: any) {
      console.error('Error fetching all strategy settings:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // POST validate settings (no save)
  app.post('/api/strategies/settings/validate', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const { strategy, params } = req.body || {};
      const { getValidator } = await import('./services/strategy-validators');
      
      const schema = getValidator(strategy);
      const parse = schema.safeParse(params);
      
      if (!parse.success) {
        return res.status(400).json({ ok: false, errors: parse.error.flatten() });
      }
      
      return res.json({ ok: true, normalized: parse.data });
    } catch (error: any) {
      console.error('Error validating strategy settings:', error);
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  // PUT save settings (validated) + audit + hot-reload
  app.put('/api/strategies/settings', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      const mode = (req.body?.mode === 'paper' ? 'paper' : 'live') as 'live' | 'paper';
      const strategy = String(req.body?.strategy);
      const enabled = req.body?.enabled !== undefined ? Boolean(req.body.enabled) : true;
      
      const { getValidator } = await import('./services/strategy-validators');
      const schema = getValidator(strategy);
      const parse = schema.safeParse(req.body?.params);
      
      if (!parse.success) {
        return res.status(400).json({ ok: false, errors: parse.error.flatten() });
      }

      const prev = await storage.getStrategySettings({ userId, mode, strategy });
      const saved = await storage.upsertStrategySettings({
        userId,
        mode,
        strategy: strategy as any,
        enabled,
        params: parse.data,
      });

      await storage.insertStrategySettingsAudit({
        userId,
        mode,
        strategy: strategy as any,
        prevParams: prev?.params ?? null,
        nextParams: saved.params,
        actorType: 'user',
        actorId: userId,
        reason: req.body?.reason || 'manual update',
      });

      // Hot-reload into engine
      await EngineSettingsBus.publish({ userId, mode });

      return res.json({ ok: true, saved });
    } catch (error: any) {
      console.error('Error saving strategy settings:', error);
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  // GET list of presets for a strategy
  app.get('/api/strategies/presets', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const { STRATEGY_PRESETS } = await import('./services/strategy-presets');
      const strategy = String(req.query.strategy || '');
      
      if (!STRATEGY_PRESETS[strategy as keyof typeof STRATEGY_PRESETS]) {
        return res.status(404).json({ ok: false, message: 'Strategy not found' });
      }
      
      res.json({ ok: true, presets: STRATEGY_PRESETS[strategy as keyof typeof STRATEGY_PRESETS] });
    } catch (error: any) {
      console.error('Error fetching presets:', error);
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  // GET a specific preset
  app.get('/api/strategies/presets/:strategy/:presetName', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const { STRATEGY_PRESETS } = await import('./services/strategy-presets');
      const { strategy, presetName } = req.params;
      const presets = STRATEGY_PRESETS[strategy as keyof typeof STRATEGY_PRESETS];
      
      if (!presets || !presets[presetName as keyof typeof presets]) {
        return res.status(404).json({ ok: false, message: 'Preset not found' });
      }
      
      res.json({ ok: true, preset: presets[presetName as keyof typeof presets] });
    } catch (error: any) {
      console.error('Error fetching preset:', error);
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  return httpServer;
}

// WebSocket message handler
function handleWebSocketMessage(ws: WebSocket, data: any) {
  if (ws.readyState !== WebSocket.OPEN) return;
  
  switch (data.type) {
    case 'subscribe_prices':
      // Handle price subscription
      break;
    case 'subscribe_trades':
      // Handle trade updates subscription
      break;
    case 'ping':
      ws.send(JSON.stringify({ type: 'pong' }));
      break;
  }
}

// CSV generation helper
function generateTradeCSV(trades: any[]): string {
  const headers = [
    'Trade ID',
    'Date/Time (UTC)',
    'Symbol',
    'Side',
    'Strategy',
    'Mode',
    'Entry Price',
    'Exit Price',
    'Quantity',
    'Entry Fee',
    'Exit Fee',
    'Total Fees',
    'Gross P/L',
    'Net P/L',
    'P/L %',
    'R Multiple',
    'R in $',
    'Hold Time (hours)'
  ];
  
  const rows = trades.map(trade => {
    const entryTime = new Date(trade.entryTime);
    const exitTime = trade.exitTime ? new Date(trade.exitTime) : null;
    const holdTime = exitTime ? 
      (exitTime.getTime() - entryTime.getTime()) / (1000 * 60 * 60) : 0;
    
    const entryFee = parseFloat(trade.entryFee || '0');
    const exitFee = parseFloat(trade.exitFee || '0');
    const totalFees = entryFee + exitFee;
    
    const entryValue = parseFloat(trade.entryPrice) * parseFloat(trade.quantity);
    const exitValue = trade.exitPrice ? 
      parseFloat(trade.exitPrice) * parseFloat(trade.quantity) : 0;
    const grossPL = exitValue - entryValue;
    const netPL = grossPL - totalFees;
    
    return [
      trade.id,
      entryTime.toISOString(),
      trade.symbol,
      'BUY/SELL', // Simplified
      trade.strategy,
      trade.mode,
      trade.entryPrice,
      trade.exitPrice || '',
      trade.quantity,
      entryFee.toFixed(4),
      exitFee.toFixed(4),
      totalFees.toFixed(4),
      grossPL.toFixed(2),
      netPL.toFixed(2),
      trade.realizedPLPercent || '',
      trade.realizedPLR || '',
      (parseFloat(trade.realizedPLR || '0') * parseFloat(trade.riskAmount)).toFixed(2),
      holdTime.toFixed(2)
    ].map(value => `"${value}"`).join(',');
  });
  
  return [headers.join(','), ...rows].join('\n');
}

// Tax Report Generator
function generateTaxReport(trades: any[]): string {
  const headers = [
    'Trade ID',
    'Date/Time (UTC)',
    'Date/Time (Local)',
    'Symbol',
    'Side',
    'Entry Price',
    'Exit Price',
    'Quantity',
    'Entry Fee',
    'Exit Fee',
    'Total Fees',
    'Gross P/L',
    'Net P/L',
    'P/L %',
    'Cost Basis',
    'Proceeds',
    'Holding Duration (hours)',
    'Holding Duration (days)',
    'Term Classification',
    'Realized Gains',
    'Unrealized Gains',
    'Account Type'
  ];
  
  const rows = trades.map(trade => {
    const entryTime = new Date(trade.entryTime);
    const exitTime = trade.exitTime ? new Date(trade.exitTime) : null;
    const holdHours = exitTime ? 
      (exitTime.getTime() - entryTime.getTime()) / (1000 * 60 * 60) : 0;
    const holdDays = holdHours / 24;
    
    const entryFee = parseFloat(trade.entryFee || '0');
    const exitFee = parseFloat(trade.exitFee || '0');
    const totalFees = entryFee + exitFee;
    
    const costBasis = parseFloat(trade.entryPrice) * parseFloat(trade.quantity) + entryFee;
    const proceeds = trade.exitPrice ? 
      parseFloat(trade.exitPrice) * parseFloat(trade.quantity) - exitFee : 0;
    const grossPL = proceeds - (parseFloat(trade.entryPrice) * parseFloat(trade.quantity));
    const netPL = proceeds - costBasis;
    
    // Realized gains only apply to closed trades (trades with exitPrice)
    const realizedGains = trade.exitPrice ? netPL : 0;
    
    // Unrealized gains apply to open trades (trades without exitPrice)
    const currentPrice = parseFloat(trade.currentPrice || trade.entryPrice);
    const unrealizedProceeds = !trade.exitPrice ? 
      currentPrice * parseFloat(trade.quantity) - exitFee : 0;
    const unrealizedGains = !trade.exitPrice ? 
      unrealizedProceeds - costBasis : 0;
    
    const termClassification = holdDays >= 365 ? 'Long-term' : 'Short-term';
    const accountType = trade.mode === 'live' ? 'Live' : 'Paper';
    
    return [
      trade.id,
      entryTime.toISOString(),
      entryTime.toLocaleString(),
      trade.symbol,
      'LONG', // Crypto day trading (long-only)
      trade.entryPrice,
      trade.exitPrice || '',
      trade.quantity,
      entryFee.toFixed(4),
      exitFee.toFixed(4),
      totalFees.toFixed(4),
      grossPL.toFixed(2),
      netPL.toFixed(2),
      trade.realizedPLPercent || '',
      costBasis.toFixed(2),
      proceeds.toFixed(2),
      holdHours.toFixed(2),
      holdDays.toFixed(2),
      termClassification,
      realizedGains.toFixed(2),
      unrealizedGains.toFixed(2),
      accountType
    ].map(value => `"${value}"`).join(',');
  });
  
  return [headers.join(','), ...rows].join('\n');
}

// Performance Summary Report
function generatePerformanceReport(trades: any[]): string {
  // Group by symbol and strategy
  const bySymbol: { [key: string]: any[] } = {};
  const byStrategy: { [key: string]: any[] } = {};
  
  trades.forEach(trade => {
    if (!bySymbol[trade.symbol]) bySymbol[trade.symbol] = [];
    bySymbol[trade.symbol].push(trade);
    
    if (!byStrategy[trade.strategy]) byStrategy[trade.strategy] = [];
    byStrategy[trade.strategy].push(trade);
  });
  
  const headers = [
    'Group Type',
    'Group Name',
    'Total Trades',
    'Wins',
    'Losses',
    'Win Rate %',
    'Avg R Multiple',
    'Total P/L',
    'Max Drawdown',
    'Avg Hold Time (hrs)',
    'Total Fees'
  ];
  
  const calculateMetrics = (groupTrades: any[]) => {
    const wins = groupTrades.filter(t => parseFloat(t.realizedPLR || '0') > 0).length;
    const losses = groupTrades.filter(t => parseFloat(t.realizedPLR || '0') < 0).length;
    const winRate = groupTrades.length > 0 ? (wins / groupTrades.length) * 100 : 0;
    const avgR = groupTrades.reduce((sum, t) => sum + parseFloat(t.realizedPLR || '0'), 0) / groupTrades.length || 0;
    const totalPL = groupTrades.reduce((sum, t) => {
      const entry = parseFloat(t.entryPrice) * parseFloat(t.quantity);
      const exit = t.exitPrice ? parseFloat(t.exitPrice) * parseFloat(t.quantity) : entry;
      return sum + (exit - entry);
    }, 0);
    const totalFees = groupTrades.reduce((sum, t) => 
      sum + parseFloat(t.entryFee || '0') + parseFloat(t.exitFee || '0'), 0);
    const avgHoldTime = groupTrades.reduce((sum, t) => {
      const entry = new Date(t.entryTime);
      const exit = t.exitTime ? new Date(t.exitTime) : entry;
      return sum + (exit.getTime() - entry.getTime()) / (1000 * 60 * 60);
    }, 0) / groupTrades.length || 0;
    
    return {
      total: groupTrades.length,
      wins,
      losses,
      winRate: winRate.toFixed(2),
      avgR: avgR.toFixed(2),
      totalPL: totalPL.toFixed(2),
      maxDD: '0.00', // Simplified for now
      avgHoldTime: avgHoldTime.toFixed(2),
      totalFees: totalFees.toFixed(2)
    };
  };
  
  const rows: string[] = [];
  
  // Overall summary
  const overallMetrics = calculateMetrics(trades);
  rows.push([
    'Overall',
    'All Trades',
    overallMetrics.total,
    overallMetrics.wins,
    overallMetrics.losses,
    overallMetrics.winRate,
    overallMetrics.avgR,
    overallMetrics.totalPL,
    overallMetrics.maxDD,
    overallMetrics.avgHoldTime,
    overallMetrics.totalFees
  ].map(v => `"${v}"`).join(','));
  
  // By symbol
  Object.keys(bySymbol).forEach(symbol => {
    const metrics = calculateMetrics(bySymbol[symbol]);
    rows.push([
      'Symbol',
      symbol,
      metrics.total,
      metrics.wins,
      metrics.losses,
      metrics.winRate,
      metrics.avgR,
      metrics.totalPL,
      metrics.maxDD,
      metrics.avgHoldTime,
      metrics.totalFees
    ].map(v => `"${v}"`).join(','));
  });
  
  // By strategy
  Object.keys(byStrategy).forEach(strategy => {
    const metrics = calculateMetrics(byStrategy[strategy]);
    rows.push([
      'Strategy',
      strategy,
      metrics.total,
      metrics.wins,
      metrics.losses,
      metrics.winRate,
      metrics.avgR,
      metrics.totalPL,
      metrics.maxDD,
      metrics.avgHoldTime,
      metrics.totalFees
    ].map(v => `"${v}"`).join(','));
  });
  
  return [headers.join(','), ...rows].join('\n');
}

// Trade Journal Report
function generateTradeJournalReport(trades: any[]): string {
  const headers = [
    'Trade ID',
    'Entry Date/Time',
    'Exit Date/Time',
    'Symbol',
    'Strategy',
    'Entry Price',
    'Stop Loss',
    'Target',
    'Exit Price',
    'Quantity',
    'R Amount',
    'Result (R)',
    'P/L $',
    'P/L %',
    'Hold Time',
    'Notes'
  ];
  
  const rows = trades.map(trade => {
    const entryTime = new Date(trade.entryTime);
    const exitTime = trade.exitTime ? new Date(trade.exitTime) : null;
    const holdTime = exitTime ? 
      `${((exitTime.getTime() - entryTime.getTime()) / (1000 * 60 * 60)).toFixed(1)} hrs` : '-';
    
    const entryValue = parseFloat(trade.entryPrice) * parseFloat(trade.quantity);
    const exitValue = trade.exitPrice ? parseFloat(trade.exitPrice) * parseFloat(trade.quantity) : entryValue;
    const pl = exitValue - entryValue;
    const plPercent = entryValue > 0 ? ((pl / entryValue) * 100).toFixed(2) : '0.00';
    
    return [
      trade.id,
      entryTime.toISOString(),
      exitTime ? exitTime.toISOString() : '-',
      trade.symbol,
      trade.strategy,
      trade.entryPrice,
      trade.stopPrice || '-',
      trade.targetPrice || '-',
      trade.exitPrice || '-',
      trade.quantity,
      trade.riskAmount || '-',
      trade.realizedPLR || '-',
      pl.toFixed(2),
      plPercent,
      holdTime,
      (trade.metadata?.notes || '-')
    ].map(value => `"${value}"`).join(',');
  });
  
  return [headers.join(','), ...rows].join('\n');
}

// Fees & Costs Report
function generateFeesReport(trades: any[]): string {
  // Group by month
  const byMonth: { [key: string]: any[] } = {};
  trades.forEach(trade => {
    const month = new Date(trade.entryTime).toISOString().substring(0, 7); // YYYY-MM
    if (!byMonth[month]) byMonth[month] = [];
    byMonth[month].push(trade);
  });
  
  const headers = [
    'Period',
    'Total Trades',
    'Total Entry Fees',
    'Total Exit Fees',
    'Total Fees',
    'Avg Fee Per Trade',
    'Fee % of Volume'
  ];
  
  const rows = Object.keys(byMonth).sort().map(month => {
    const monthTrades = byMonth[month];
    const totalEntryFees = monthTrades.reduce((sum, t) => sum + parseFloat(t.entryFee || '0'), 0);
    const totalExitFees = monthTrades.reduce((sum, t) => sum + parseFloat(t.exitFee || '0'), 0);
    const totalFees = totalEntryFees + totalExitFees;
    const avgFee = totalFees / monthTrades.length;
    const totalVolume = monthTrades.reduce((sum, t) => 
      sum + (parseFloat(t.entryPrice) * parseFloat(t.quantity)), 0);
    const feePercent = totalVolume > 0 ? (totalFees / totalVolume) * 100 : 0;
    
    return [
      month,
      monthTrades.length,
      totalEntryFees.toFixed(4),
      totalExitFees.toFixed(4),
      totalFees.toFixed(4),
      avgFee.toFixed(4),
      feePercent.toFixed(4)
    ].map(v => `"${v}"`).join(',');
  });
  
  // Add total row
  const totalTrades = trades.length;
  const grandTotalEntryFees = trades.reduce((sum, t) => sum + parseFloat(t.entryFee || '0'), 0);
  const grandTotalExitFees = trades.reduce((sum, t) => sum + parseFloat(t.exitFee || '0'), 0);
  const grandTotalFees = grandTotalEntryFees + grandTotalExitFees;
  const grandAvgFee = totalTrades > 0 ? grandTotalFees / totalTrades : 0;
  const grandTotalVolume = trades.reduce((sum, t) => 
    sum + (parseFloat(t.entryPrice) * parseFloat(t.quantity)), 0);
  const grandFeePercent = grandTotalVolume > 0 ? (grandTotalFees / grandTotalVolume) * 100 : 0;
  
  rows.push([
    'TOTAL',
    totalTrades,
    grandTotalEntryFees.toFixed(4),
    grandTotalExitFees.toFixed(4),
    grandTotalFees.toFixed(4),
    grandAvgFee.toFixed(4),
    grandFeePercent.toFixed(4)
  ].map(v => `"${v}"`).join(','));
  
  return [headers.join(','), ...rows].join('\n');
}

// P&L Report (Monthly, Quarterly, Annual)
function generatePnLReport(trades: any[], period: 'monthly' | 'quarterly' | 'annual'): string {
  const groupedTrades: { [key: string]: any[] } = {};
  
  trades.forEach(trade => {
    const date = new Date(trade.entryTime);
    let key = '';
    
    if (period === 'monthly') {
      key = date.toISOString().substring(0, 7); // YYYY-MM
    } else if (period === 'quarterly') {
      const quarter = Math.floor(date.getMonth() / 3) + 1;
      key = `${date.getFullYear()}-Q${quarter}`;
    } else {
      key = date.getFullYear().toString();
    }
    
    if (!groupedTrades[key]) groupedTrades[key] = [];
    groupedTrades[key].push(trade);
  });
  
  const headers = [
    'Period',
    'Total Trades',
    'Wins',
    'Losses',
    'Win Rate %',
    'Gross P/L',
    'Net P/L',
    'Total Fees',
    'Avg Hold Time (hrs)',
    'Best Trade',
    'Worst Trade'
  ];
  
  const rows = Object.keys(groupedTrades).sort().map(periodKey => {
    const periodTrades = groupedTrades[periodKey];
    const wins = periodTrades.filter(t => parseFloat(t.realizedPLR || '0') > 0).length;
    const losses = periodTrades.filter(t => parseFloat(t.realizedPLR || '0') < 0).length;
    const winRate = periodTrades.length > 0 ? (wins / periodTrades.length) * 100 : 0;
    
    const totalFees = periodTrades.reduce((sum, t) => 
      sum + parseFloat(t.entryFee || '0') + parseFloat(t.exitFee || '0'), 0);
    
    const grossPL = periodTrades.reduce((sum, t) => {
      const entry = parseFloat(t.entryPrice) * parseFloat(t.quantity);
      const exit = t.exitPrice ? parseFloat(t.exitPrice) * parseFloat(t.quantity) : entry;
      return sum + (exit - entry);
    }, 0);
    
    const netPL = grossPL - totalFees;
    
    const avgHoldTime = periodTrades.reduce((sum, t) => {
      const entry = new Date(t.entryTime);
      const exit = t.exitTime ? new Date(t.exitTime) : entry;
      return sum + (exit.getTime() - entry.getTime()) / (1000 * 60 * 60);
    }, 0) / periodTrades.length || 0;
    
    const plValues = periodTrades.map(t => {
      const entry = parseFloat(t.entryPrice) * parseFloat(t.quantity);
      const exit = t.exitPrice ? parseFloat(t.exitPrice) * parseFloat(t.quantity) : entry;
      return exit - entry;
    });
    const bestTrade = plValues.length > 0 ? Math.max(...plValues) : 0;
    const worstTrade = plValues.length > 0 ? Math.min(...plValues) : 0;
    
    return [
      periodKey,
      periodTrades.length,
      wins,
      losses,
      winRate.toFixed(2),
      grossPL.toFixed(2),
      netPL.toFixed(2),
      totalFees.toFixed(4),
      avgHoldTime.toFixed(2),
      bestTrade.toFixed(2),
      worstTrade.toFixed(2)
    ].map(v => `"${v}"`).join(',');
  });
  
  return [headers.join(','), ...rows].join('\n');
}
