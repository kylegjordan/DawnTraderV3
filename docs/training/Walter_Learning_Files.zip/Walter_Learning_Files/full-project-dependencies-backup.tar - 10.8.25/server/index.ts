import express, { type Request, Response, NextFunction } from "express";
import cors from "cors";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { databaseMonitor } from "./services/database-monitor";
import { marketDataHealthCheck } from "./services/market-data-health-check";

const app = express();

// CORS Configuration - restrict access to allowed origins only
// For Replit: automatically allow the current Replit dev/app domain + any custom ALLOWED_ORIGINS
const replitDevDomain = process.env.REPLIT_DEV_DOMAIN ? `https://${process.env.REPLIT_DEV_DOMAIN}` : null;
const customOrigins = process.env.ALLOWED_ORIGINS?.split(",") || [];
const allowedOrigins = [
  "http://localhost:3000", 
  "http://localhost:5000",
  ...(replitDevDomain ? [replitDevDomain] : []),
  ...customOrigins
].filter(Boolean);

app.use(cors({
  origin: allowedOrigins,
  credentials: true
}));

declare module 'http' {
  interface IncomingMessage {
    rawBody: unknown
  }
}
app.use(express.json({
  verify: (req, _res, buf) => {
    req.rawBody = buf;
  }
}));
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const server = await registerRoutes(app);

  // Start database monitoring
  databaseMonitor.startDailyChecks();

  // Start market data health checks (async, non-blocking)
  marketDataHealthCheck.startDailyHealthChecks().catch((error) => {
    console.error('[Server] Failed to start Market Data Health Check service:', error);
  });

  // Start AI Opportunities service (async, non-blocking)
  import('./services/ai-opportunities').then(({ aiOpportunitiesService }) => {
    aiOpportunitiesService.startHourlyOpportunityGeneration().catch((error) => {
      console.error('[Server] Failed to start AI Opportunities service:', error);
    });
  });

  // Start Daily Brief service (async, non-blocking)
  import('./services/daily-brief').then(({ dailyBriefService }) => {
    dailyBriefService.startDailyBriefScheduler().catch((error) => {
      console.error('[Server] Failed to start Daily Brief service:', error);
    });
  });

  // Start Market Analysis scheduler (async, non-blocking)
  import('./services/market-analysis-scheduler').then(({ marketAnalysisScheduler }) => {
    marketAnalysisScheduler.startDailyAnalysisScheduler().catch((error) => {
      console.error('[Server] Failed to start Market Analysis Scheduler:', error);
    });
  });

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || '5000', 10);
  
  // Check if port is already in use before listening
  server.on('error', (err: any) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`Port ${port} is already in use. Exiting...`);
      process.exit(1);
    } else {
      throw err;
    }
  });

  server.listen(port, "0.0.0.0", () => {
    log(`serving on port ${port}`);
  });
})();
