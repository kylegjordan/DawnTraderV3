# Database and Shared Schema Files

**Created**: November 12, 2025
**Purpose**: Complete database schema and repository layer for Stage 3 refactoring

## Architecture Overview

This project uses:
- **Drizzle ORM** for database schema and type-safe queries
- **PostgreSQL (Neon)** as the database engine
- **Centralized storage.ts** as the repository layer (no separate repositories/ directory)

## File Structure

### shared/schema.ts (249 KB)
**Main Database Schema** - Drizzle ORM definitions for all tables

**Key Tables**:
- `users` - User authentication and profiles
- `trades` - All trade records (paper and live)
- `portfolios` - Portfolio state snapshots
- `strategies` - Trading strategy definitions
- `strategy_executions` - Strategy execution history
- `filtered_pairs` - Eligible trading pairs from scan cycles
- `scan_cycles` - Scan cycle metadata
- `guardrails_v2` - Trading guardrails configuration
- `goals_presets` - Goals Engine presets
- `system_config` - System-wide configuration flags
- Many more...

**Usage**:
```typescript
import { trades, portfolios, strategies } from '@/shared/schema';
```

### shared/diagnostic-schema.ts (5 KB)
**Diagnostic Schema** - Schema for diagnostic and telemetry data

### server/db.ts (483 bytes)
**Database Connection** - Drizzle database instance setup

**Exports**:
```typescript
export const db: NeonDatabase
```

### server/storage.ts (141 KB)
**Repository Layer** - All database access methods

**Key Methods**:
- **Trades**: `createTrade()`, `getTrades()`, `updateTrade()`, `getTradeById()`
- **Portfolios**: `getPortfolio()`, `updatePortfolio()`, `getPortfolioSnapshot()`
- **Strategies**: `createStrategy()`, `getStrategies()`, `updateStrategy()`
- **Filtered Pairs**: `storeFilteredPairs()`, `getFilteredPairs()`
- **Scan Cycles**: `createScanCycle()`, `getScanCycle()`
- **Guardrails**: `getGuardrails()`, `updateGuardrails()`
- **System Config**: `getSystemConfig()`, `updateSystemConfig()`
- Many more...

**Usage**:
```typescript
import { storage } from '@/server/storage';
const trades = await storage.getTrades({ mode: 'paper', limit: 100 });
```

### client/src/lib/types.ts
**Frontend Types** - TypeScript interfaces for API responses and frontend models

**Key Types**:
- `Trade` - Trade object structure
- `Portfolio` - Portfolio state
- `Strategy` - Strategy definition
- `FilteredPair` - Eligible pair metadata
- API request/response types

## Data Flow Patterns

### 1. Scan Cycle → Filtered Pairs
```
MarketScanner (market-scanner.ts)
  → CycleCache (cycle-cache.ts) → storage.createScanCycle()
  → FilteredPairsService → storage.storeFilteredPairs()
  → WebSocket broadcast (scan_tick)
  → Frontend components (use-scan-tick.tsx)
```

### 2. Trade Execution
```
TradingEngine (paper-execution-engine.ts)
  → StrategyEngine → storage.createTrade()
  → storage.updatePortfolio()
  → WebSocket broadcast (trade_update)
  → Frontend components (use-trading.tsx)
```

### 3. Portfolio Updates
```
TradingEngine
  → storage.updatePortfolio()
  → storage.getPortfolio() for current state
  → WebSocket broadcast (trading_state_changed with portfolioOverview)
  → Frontend queries /api/portfolio/overview
```

## Important Notes

### No Separate Repositories Directory
Unlike traditional layered architectures, this project consolidates all database access in `server/storage.ts`. Benefits:
- Single source of truth for all queries
- Type-safe access to Drizzle schema
- Centralized transaction management
- Easier to maintain and refactor

### No DTO Directory
Data transfer objects are defined inline in:
- API route handlers (`server/routes.ts`)
- Service methods (`server/services/*`)
- Frontend types (`client/src/lib/types.ts`)

### Schema Migration
```bash
# Push schema changes to database
npm run db:push

# Force push (if needed)
npm run db:push --force
```

**CRITICAL**: Never manually write SQL migrations. Always use `npm run db:push`.

### Type Safety
All database operations are type-safe through Drizzle ORM:
```typescript
const result = await db.select().from(trades).where(eq(trades.mode, 'paper'));
// result is automatically typed as Trade[]
```

## Stage 3 Relevance

These files define the complete data layer that Stage 3 plumbing refactor must preserve:

**Keep Unchanged**:
- Table schemas in `shared/schema.ts`
- Repository method signatures in `server/storage.ts`
- Data types and interfaces

**May Refactor**:
- Query patterns and caching strategies
- Transaction boundaries
- Event emission timing
- Cache invalidation logic

**Goal**: Fix data flow timing and consistency WITHOUT changing schemas or breaking existing data.

## Test Credentials
**Username**: `testuser123`
**Password**: `SecurePass123!`

---

**End of Database and Schema Documentation**
